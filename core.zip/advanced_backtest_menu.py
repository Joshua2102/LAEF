#!/usr/bin/env python3
"""
LAEF Advanced Backtesting Menu
Integrates all advanced features into a unified interface
"""

import os
import sys
from datetime import datetime
from typing import Dict, List, Optional

# Add project root to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from trading.backtester_unified import LAEFBacktester
from core.parameter_optimizer import LAEFParameterOptimizer
from core.interactive_explorer import InteractiveResultExplorer
from core.pnl_analyzer import PnLAnalyzer
from core.smart_stock_selector import SmartStockSelector

class AdvancedBacktestMenu:
    """Main interface for advanced backtesting features"""
    
    def __init__(self):
        self.backtester = None
        self.optimizer = LAEFParameterOptimizer()
        self.explorer = InteractiveResultExplorer()
        self.pnl_analyzer = PnLAnalyzer()
        self.stock_selector = SmartStockSelector()
        
        # Store last results for quick access
        self.last_backtest_results = None
        self.last_selected_stocks = None
        self.optimized_params = None
        
    def run(self):
        """Main menu loop"""
        print("\n" + "="*70)
        print("LAEF ADVANCED BACKTESTING SYSTEM")
        print("Learning-Augmented Equity Framework - Professional Tools")
        print("="*70)
        
        while True:
            self.show_main_menu()
            choice = input("\nSelect option (0-8): ").strip()
            
            if choice == '0':
                print("\nExiting advanced backtesting system...")
                break
            elif choice == '1':
                self.run_parameter_optimization()
            elif choice == '2':
                self.run_smart_stock_selection()
            elif choice == '3':
                self.explore_results_interactive()
            elif choice == '4':
                self.run_pnl_analysis()
            elif choice == '5':
                self.run_custom_backtest()
            elif choice == '6':
                self.run_comparative_analysis()
            elif choice == '7':
                self.export_comprehensive_report()
            elif choice == '8':
                self.show_quick_stats()
            else:
                print("Invalid option")
    
    def show_main_menu(self):
        """Display main menu options"""
        print("\n" + "="*60)
        print("ADVANCED BACKTESTING MENU")
        print("="*60)
        print("1. Parameter Optimization")
        print("2. Smart Stock Selection")
        print("3. Interactive Result Explorer")
        print("4. P&L Deep Analysis")
        print("5. Custom Backtest Configuration")
        print("6. Comparative Analysis")
        print("7. Export Comprehensive Report")
        print("8. Quick Stats Summary")
        print("0. Exit")
        print("="*60)
        
        if self.last_backtest_results:
            print(f"\n[Last backtest: {len(self.last_backtest_results.get('symbols_processed', []))} symbols analyzed]")
        if self.optimized_params:
            print("[Optimized parameters loaded]")
    
    def run_parameter_optimization(self):
        """Run parameter optimization"""
        print("\n" + "="*50)
        print("PARAMETER OPTIMIZATION")
        print("="*50)
        
        # Get optimization settings
        print("\nOptimization scope:")
        print("1. Quick (key parameters only)")
        print("2. Standard (most parameters)")
        print("3. Comprehensive (all parameters)")
        
        scope = input("Select scope (1-3): ").strip()
        
        if scope == '1':
            param_subset = ['profit_target', 'stop_loss', 'q_buy', 'q_sell']
        elif scope == '2':
            param_subset = ['profit_target', 'stop_loss', 'q_buy', 'q_sell', 
                          'max_position', 'ml_profit_peak']
        else:
            param_subset = None  # All parameters
        
        # Get test symbols
        symbols_input = input("Enter test symbols (comma-separated, max 3 recommended): ").strip()
        if symbols_input:
            symbols = [s.strip().upper() for s in symbols_input.split(',')][:3]
        else:
            symbols = ["AAPL", "MSFT", "GOOGL"]
        
        # Run optimization
        print(f"\nOptimizing parameters on {symbols}...")
        print("This may take several minutes...")
        
        report = self.optimizer.optimize_parameters(
            symbols=symbols,
            param_subset=param_subset,
            days=90,  # 3 months for faster optimization
            max_workers=4
        )
        
        # Display results
        if report and 'best_params' in report:
            self.optimized_params = report['best_params']
            print("\n" + "="*50)
            print("OPTIMIZATION COMPLETE")
            print("="*50)
            print(f"Best Score: {report['best_score']:.2f}")
            print("\nOptimal Parameters:")
            for param, value in report['best_params'].items():
                if param.startswith('_'):
                    continue
                if isinstance(value, float) and value < 1:
                    print(f"  {param}: {value:.3%}")
                else:
                    print(f"  {param}: {value}")
            
            print("\nBest Performance Metrics:")
            metrics = report['best_metrics']
            print(f"  Total Return: {metrics['total_return']:.2f}%")
            print(f"  Win Rate: {metrics['win_rate']:.1f}%")
            print(f"  Sharpe Ratio: {metrics['sharpe_ratio']:.2f}")
            
            save = input("\nSave optimized parameters? (y/n): ").lower() == 'y'
            if save:
                # Parameters are already saved in the report
                print("Parameters saved!")
        
        input("\nPress Enter to continue...")
    
    def run_smart_stock_selection(self):
        """Run smart stock selection"""
        print("\n" + "="*50)
        print("SMART STOCK SELECTION")
        print("="*50)
        
        print("\nSelection modes:")
        print("1. Balanced (all factors)")
        print("2. Momentum (trending stocks)")
        print("3. Value (oversold opportunities)")
        print("4. Volatility (optimal trading range)")
        print("5. ML-Driven (AI signals)")
        
        mode_choice = input("Select mode (1-5): ").strip()
        modes = ['balanced', 'momentum', 'value', 'volatility', 'ml_driven']
        mode = modes[int(mode_choice) - 1] if mode_choice in '12345' else 'balanced'
        
        num_stocks = int(input("Number of stocks to select (default 5): ").strip() or "5")
        
        print(f"\nRunning {mode} stock selection...")
        
        selection_result = self.stock_selector.select_stocks(
            num_stocks=num_stocks,
            selection_mode=mode,
            lookback_days=30
        )
        
        self.last_selected_stocks = selection_result['selected_stocks']
        
        # Display results
        print("\n" + selection_result['report'])
        
        # Option to run backtest on selected stocks
        run_backtest = input("\nRun backtest on selected stocks? (y/n): ").lower() == 'y'
        if run_backtest:
            self.backtester = LAEFBacktester(initial_cash=100000, custom_config=self.optimized_params)
            results = self.backtester.run_backtest(
                symbols=self.last_selected_stocks,
                days=180
            )
            self.last_backtest_results = results
            if results:
                self.display_backtest_summary(results)
        
        input("\nPress Enter to continue...")
    
    def explore_results_interactive(self):
        """Launch interactive result explorer"""
        if not self.last_backtest_results:
            print("\nNo backtest results available. Run a backtest first.")
            load_previous = input("Load previous results from file? (y/n): ").lower() == 'y'
            if load_previous:
                self.explorer.explore_interactive()
            return
        
        # Load current results into explorer
        print("\nLaunching interactive explorer...")
        self.explorer.explore_interactive()
    
    def run_pnl_analysis(self):
        """Run detailed P&L analysis"""
        print("\n" + "="*50)
        print("P&L DEEP ANALYSIS")
        print("="*50)
        
        # Load data
        if not self.explorer.trade_history.empty:
            trades_df = self.explorer.trade_history
            decisions_df = self.explorer.decision_history
        else:
            print("Loading most recent backtest data...")
            if not self.explorer.load_backtest_results():
                print("No data available for analysis")
                return
            trades_df = self.explorer.trade_history
            decisions_df = self.explorer.decision_history
        
        # Run analysis
        print("\nAnalyzing P&L patterns and contributing factors...")
        analysis = self.pnl_analyzer.analyze_pnl_factors(trades_df, decisions_df)
        
        # Generate and display report
        report = self.pnl_analyzer.generate_pnl_report()
        print("\n" + report)
        
        # Save report
        save = input("\nSave P&L analysis report? (y/n): ").lower() == 'y'
        if save:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f'logs/pnl_analysis_{timestamp}.txt'
            self.pnl_analyzer.generate_pnl_report(filename)
            print(f"Report saved to {filename}")
        
        input("\nPress Enter to continue...")
    
    def run_custom_backtest(self):
        """Run backtest with custom configuration"""
        print("\n" + "="*50)
        print("CUSTOM BACKTEST CONFIGURATION")
        print("="*50)
        
        # Build custom config
        config = {}
        
        print("\nEnter custom parameters (press Enter to use defaults):")
        
        # Trading parameters
        profit_target = input("Profit target % (default 0.4%): ").strip()
        if profit_target:
            config['profit_target'] = float(profit_target) / 100
        
        stop_loss = input("Stop loss % (default 0.2%): ").strip()
        if stop_loss:
            config['stop_loss'] = float(stop_loss) / 100
        
        position_size = input("Max position size % (default 15%): ").strip()
        if position_size:
            config['max_position'] = float(position_size) / 100
        
        # ML parameters
        q_buy = input("Q-buy threshold (0-1, default 0.30): ").strip()
        if q_buy:
            config['q_buy'] = float(q_buy)
        
        q_sell = input("Q-sell threshold (0-1, default 0.20): ").strip()
        if q_sell:
            config['q_sell'] = float(q_sell)
        
        # Get symbols and period
        symbols_input = input("Enter symbols (comma-separated): ").strip()
        symbols = [s.strip().upper() for s in symbols_input.split(',')] if symbols_input else ["AAPL", "MSFT"]
        
        period = int(input("Backtest period in days (default 180): ").strip() or "180")
        
        # Run custom backtest
        print(f"\nRunning custom backtest...")
        self.backtester = LAEFBacktester(initial_cash=100000, custom_config=config)
        
        results = self.backtester.run_backtest(
            symbols=symbols,
            days=period
        )
        
        self.last_backtest_results = results
        
        if results:
            self.display_backtest_summary(results)
        
        input("\nPress Enter to continue...")
    
    def run_comparative_analysis(self):
        """Compare different strategies or parameters"""
        print("\n" + "="*50)
        print("COMPARATIVE ANALYSIS")
        print("="*50)
        
        print("\nCompare:")
        print("1. Different parameter sets")
        print("2. Different stock selections")
        print("3. Different time periods")
        
        compare_type = input("Select comparison type (1-3): ").strip()
        
        if compare_type == '1':
            self.compare_parameters()
        elif compare_type == '2':
            self.compare_stock_selections()
        elif compare_type == '3':
            self.compare_time_periods()
        else:
            print("Invalid selection")
    
    def compare_parameters(self):
        """Compare different parameter configurations"""
        configs = []
        
        # Default config
        configs.append({
            'name': 'Default',
            'config': {}
        })
        
        # Optimized config
        if self.optimized_params:
            configs.append({
                'name': 'Optimized',
                'config': self.optimized_params
            })
        
        # Conservative config
        configs.append({
            'name': 'Conservative',
            'config': {
                'profit_target': 0.006,
                'stop_loss': 0.002,
                'max_position': 0.10,
                'q_buy': 0.40,
                'q_sell': 0.15
            }
        })
        
        # Aggressive config
        configs.append({
            'name': 'Aggressive',
            'config': {
                'profit_target': 0.003,
                'stop_loss': 0.004,
                'max_position': 0.20,
                'q_buy': 0.25,
                'q_sell': 0.20
            }
        })
        
        # Test symbols
        symbols = ["AAPL", "MSFT", "GOOGL"]
        
        print(f"\nComparing {len(configs)} configurations on {symbols}...")
        
        results = []
        for cfg in configs:
            print(f"\nTesting {cfg['name']} configuration...")
            backtester = LAEFBacktester(initial_cash=100000, custom_config=cfg['config'])
            result = backtester.run_backtest(symbols=symbols, days=90)
            
            if result and 'performance' in result:
                perf = result['performance']
                results.append({
                    'name': cfg['name'],
                    'return': perf.get('total_return_pct', 0),
                    'win_rate': perf.get('win_rate', 0),
                    'trades': perf.get('total_trades', 0),
                    'final_value': perf.get('final_value', 100000)
                })
        
        # Display comparison
        print("\n" + "="*60)
        print("COMPARISON RESULTS")
        print("="*60)
        
        for res in sorted(results, key=lambda x: x['return'], reverse=True):
            print(f"\n{res['name']}:")
            print(f"  Return: {res['return']:.2f}%")
            print(f"  Win Rate: {res['win_rate']:.1f}%")
            print(f"  Total Trades: {res['trades']}")
            print(f"  Final Value: ${res['final_value']:,.2f}")
        
        input("\nPress Enter to continue...")
    
    def compare_stock_selections(self):
        """Compare different stock selection methods"""
        selections = []
        
        # Different selection modes
        modes = ['balanced', 'momentum', 'value', 'ml_driven']
        
        for mode in modes:
            print(f"\nSelecting stocks using {mode} mode...")
            result = self.stock_selector.select_stocks(
                num_stocks=5,
                selection_mode=mode,
                lookback_days=30
            )
            selections.append({
                'mode': mode,
                'stocks': result['selected_stocks']
            })
        
        # Run backtests
        print("\nRunning backtests on each selection...")
        
        comparison_results = []
        for selection in selections:
            print(f"\nTesting {selection['mode']} selection: {', '.join(selection['stocks'])}")
            
            backtester = LAEFBacktester(initial_cash=100000, custom_config=self.optimized_params)
            result = backtester.run_backtest(
                symbols=selection['stocks'],
                days=90
            )
            
            if result and 'performance' in result:
                perf = result['performance']
                comparison_results.append({
                    'mode': selection['mode'],
                    'stocks': selection['stocks'],
                    'return': perf.get('total_return_pct', 0),
                    'win_rate': perf.get('win_rate', 0),
                    'trades': perf.get('total_trades', 0)
                })
        
        # Display results
        print("\n" + "="*60)
        print("STOCK SELECTION COMPARISON")
        print("="*60)
        
        for res in sorted(comparison_results, key=lambda x: x['return'], reverse=True):
            print(f"\n{res['mode'].upper()} Selection:")
            print(f"  Stocks: {', '.join(res['stocks'])}")
            print(f"  Return: {res['return']:.2f}%")
            print(f"  Win Rate: {res['win_rate']:.1f}%")
            print(f"  Trades: {res['trades']}")
        
        input("\nPress Enter to continue...")
    
    def compare_time_periods(self):
        """Compare performance across different time periods"""
        symbols = ["AAPL", "MSFT", "GOOGL", "TSLA"]
        periods = [
            (30, "Last Month"),
            (90, "Last 3 Months"),
            (180, "Last 6 Months"),
            (365, "Last Year")
        ]
        
        print(f"\nComparing performance across time periods for {', '.join(symbols)}...")
        
        results = []
        for days, label in periods:
            print(f"\nTesting {label}...")
            backtester = LAEFBacktester(initial_cash=100000, custom_config=self.optimized_params)
            result = backtester.run_backtest(symbols=symbols, days=days)
            
            if result and 'performance' in result:
                perf = result['performance']
                results.append({
                    'period': label,
                    'days': days,
                    'return': perf.get('total_return_pct', 0),
                    'win_rate': perf.get('win_rate', 0),
                    'trades': perf.get('total_trades', 0),
                    'annualized_return': perf.get('total_return_pct', 0) * (365 / days)
                })
        
        # Display results
        print("\n" + "="*60)
        print("TIME PERIOD COMPARISON")
        print("="*60)
        
        for res in results:
            print(f"\n{res['period']}:")
            print(f"  Total Return: {res['return']:.2f}%")
            print(f"  Annualized Return: {res['annualized_return']:.2f}%")
            print(f"  Win Rate: {res['win_rate']:.1f}%")
            print(f"  Total Trades: {res['trades']}")
        
        input("\nPress Enter to continue...")
    
    def export_comprehensive_report(self):
        """Export comprehensive analysis report"""
        print("\n" + "="*50)
        print("EXPORT COMPREHENSIVE REPORT")
        print("="*50)
        
        if not self.last_backtest_results:
            print("No backtest results to export. Run a backtest first.")
            return
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        report_file = f'logs/comprehensive_report_{timestamp}.txt'
        
        with open(report_file, 'w') as f:
            f.write("="*80 + "\n")
            f.write("LAEF COMPREHENSIVE BACKTESTING REPORT\n")
            f.write(f"Generated: {datetime.now()}\n")
            f.write("="*80 + "\n\n")
            
            # Configuration section
            f.write("1. CONFIGURATION\n")
            f.write("-"*40 + "\n")
            if self.last_backtest_results.get('config'):
                config = self.last_backtest_results['config']
                for key, value in config.items():
                    if not key.startswith('_'):
                        f.write(f"{key}: {value}\n")
            
            # Performance summary
            f.write("\n2. PERFORMANCE SUMMARY\n")
            f.write("-"*40 + "\n")
            if 'performance' in self.last_backtest_results:
                perf = self.last_backtest_results['performance']
                f.write(f"Final Value: ${perf.get('final_value', 0):,.2f}\n")
                f.write(f"Total Return: {perf.get('total_return_pct', 0):.2f}%\n")
                f.write(f"Win Rate: {perf.get('win_rate', 0):.1f}%\n")
                f.write(f"Total Trades: {perf.get('total_trades', 0)}\n")
            
            # Individual symbol results
            f.write("\n3. SYMBOL PERFORMANCE\n")
            f.write("-"*40 + "\n")
            for symbol, data in self.last_backtest_results.get('symbol_results', {}).items():
                f.write(f"\n{symbol}:\n")
                f.write(f"  Return: {data['total_return']:.2%}\n")
                f.write(f"  Trades: {data['total_trades']}\n")
                f.write(f"  Win Rate: {data['win_rate']:.1%}\n")
            
            # Add P&L analysis if available
            if hasattr(self.pnl_analyzer, 'last_analysis'):
                f.write("\n4. P&L ANALYSIS\n")
                f.write("-"*40 + "\n")
                # Add P&L details
            
            print(f"Comprehensive report exported to: {report_file}")
        
        # Also export to CSV
        csv_file = f'logs/comprehensive_data_{timestamp}.csv'
        # Export trade data to CSV
        
        input("\nPress Enter to continue...")
    
    def show_quick_stats(self):
        """Show quick statistics summary"""
        print("\n" + "="*50)
        print("QUICK STATS SUMMARY")
        print("="*50)
        
        if self.last_backtest_results:
            print("\nLast Backtest:")
            perf = self.last_backtest_results.get('performance', {})
            print(f"  Return: {perf.get('total_return_pct', 0):.2f}%")
            print(f"  Win Rate: {perf.get('win_rate', 0):.1f}%")
            print(f"  Trades: {perf.get('total_trades', 0)}")
            print(f"  Symbols: {', '.join(self.last_backtest_results.get('symbols_processed', []))}")
        
        if self.optimized_params:
            print("\nOptimized Parameters:")
            print(f"  Profit Target: {self.optimized_params.get('profit_target', 0):.2%}")
            print(f"  Stop Loss: {self.optimized_params.get('stop_loss', 0):.2%}")
            print(f"  Q-Buy: {self.optimized_params.get('q_buy', 0):.2f}")
        
        if self.last_selected_stocks:
            print(f"\nLast Stock Selection: {', '.join(self.last_selected_stocks)}")
        
        # Market assessment
        print("\nMarket Assessment:")
        sector_analysis = self.stock_selector.get_sector_analysis()
        if sector_analysis:
            best_sector = max(sector_analysis.items(), key=lambda x: x[1]['average_score'])
            print(f"  Best Sector: {best_sector[0]} (score: {best_sector[1]['average_score']:.1f})")
        
        input("\nPress Enter to continue...")
    
    def get_backtest_period(self) -> int:
        """Get backtest period from user"""
        print("\nSelect backtest period:")
        print("1. 1 Month (30 days)")
        print("2. 3 Months (90 days)")
        print("3. 6 Months (180 days)")
        print("4. 1 Year (365 days)")
        print("5. Custom")
        
        choice = input("Select period (1-5): ").strip()
        
        if choice == '1':
            return 30
        elif choice == '2':
            return 90
        elif choice == '3':
            return 180
        elif choice == '4':
            return 365
        elif choice == '5':
            return int(input("Enter number of days: ").strip())
        else:
            return 180  # Default
    
    def display_backtest_summary(self, results: Dict):
        """Display formatted backtest summary"""
        print("\n" + "="*60)
        print("BACKTEST RESULTS")
        print("="*60)
        
        if 'performance' in results:
            perf = results['performance']
            print(f"\nOverall Performance:")
            print(f"  Final Portfolio Value: ${perf.get('final_value', 0):,.2f}")
            print(f"  Total Return: {perf.get('total_return_pct', 0):.2f}%")
            print(f"  Win Rate: {perf.get('win_rate', 0):.1f}%")
            print(f"  Total Trades: {perf.get('total_trades', 0)}")
        
        print(f"\nSymbols Tested: {', '.join(results.get('symbols_processed', []))}")
        
        if 'symbol_results' in results:
            print("\nIndividual Results:")
            for symbol, data in results['symbol_results'].items():
                print(f"  {symbol}: {data['total_return']:.2%} return, "
                      f"{data['total_trades']} trades, "
                      f"{data['win_rate']:.1%} win rate")

def main():
    """Main entry point"""
    menu = AdvancedBacktestMenu()
    menu.run()

if __name__ == "__main__":
    main()