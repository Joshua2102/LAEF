# === setup_integrated_workflow.py - Quick Setup for Integrated System ===

import os
import shutil

def setup_integrated_workflow():
    """Ensure all required files are in place for integrated workflow"""
    
    print("🔧 SETTING UP INTEGRATED WORKFLOW")
    print("=" * 50)
    
    required_files = {
        'integrated_workflow.py': 'Main workflow controller',
        'advanced_dynamic_tuning.py': 'Advanced analysis system',
        'apply_optimized_config.py': 'Config application tool'
    }
    
    missing_files = []
    
    # Check for required files
    for file, description in required_files.items():
        if os.path.exists(file):
            print(f"✅ {file} - {description}")
        else:
            print(f"❌ {file} - MISSING")
            missing_files.append(file)
    
    if missing_files:
        print(f"\n⚠️ Missing {len(missing_files)} required files!")
        print("Please ensure you have saved all the artifact files I created:")
        for file in missing_files:
            print(f"   - {file}")
        return False
    
    # Check if main.py needs updating
    print("\n🔍 Checking main.py integration...")
    
    try:
        with open('main.py', 'r') as f:
            main_content = f.read()
            
        if 'LAEFIntegratedWorkflow' not in main_content:
            print("⚠️ main.py needs to be updated for integrated workflow")
            print("\nTo update main.py:")
            print("1. Add the import after other imports:")
            print("   from optimization.integrated_workflow import LAEFIntegratedWorkflow")
            print("\n2. Add option 0 to the menu")
            print("\n3. Handle choice '0' in the main loop")
            print("\nRefer to 'main_py_integrated_update.py' for details")
        else:
            print("✅ main.py already has integrated workflow!")
    except:
        print("❌ Could not check main.py")
    
    # Create a simple launcher
    print("\n📝 Creating quick launcher...")
    
    launcher_content = '''#!/usr/bin/env python
# === laef_integrated.py - Quick Launcher for Integrated Workflow ===

import os
import sys

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from optimization.integrated_workflow import LAEFIntegratedWorkflow
    
    print("🚀 LAEF INTEGRATED WORKFLOW LAUNCHER")
    print("=" * 50)
    
    workflow = LAEFIntegratedWorkflow()
    workflow.run_complete_workflow()
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    print("Please run setup_integrated_workflow.py first!")
except KeyboardInterrupt:
    print("\\n👋 Workflow cancelled by user")
except Exception as e:
    print(f"❌ Error: {e}")
'''
    
    with open('laef_integrated.py', 'w') as f:
        f.write(launcher_content)
    
    print("✅ Created laef_integrated.py launcher")
    
    print("\n🎉 SETUP COMPLETE!")
    print("\n📋 You can now run the integrated workflow in 3 ways:")
    print("\n1. From updated main.py:")
    print("   python main.py")
    print("   → Select option 0")
    print("\n2. Direct workflow:")
    print("   python integrated_workflow.py")
    print("\n3. Quick launcher:")
    print("   python laef_integrated.py")
    
    return True

def test_workflow():
    """Quick test of the workflow components"""
    
    print("\n🧪 TESTING WORKFLOW COMPONENTS")
    print("=" * 50)
    
    # Test imports
    try:
        print("Testing imports...")
        from optimization.integrated_workflow import LAEFIntegratedWorkflow
        print("✅ Integrated workflow imports successfully")
        
        from advanced_dynamic_tuning import AdvancedLAEFTuner  
        print("✅ Advanced tuner imports successfully")
        
        from .apply_optimized_config from ..optimization from ..optimization import apply_optimized_config
        print("✅ Config applicator imports successfully")
        
        print("\n✅ All components ready!")
        return True
        
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False

if __name__ == "__main__":
    if setup_integrated_workflow():
        test_workflow()
