# === advanced_dynamic_tuning.py - Multi-Dimensional LAEF Analysis ===

import pandas as pd
import numpy as np
import re
import glob
import os
from datetime import datetime, time
import json
import matplotlib.pyplot as plt
import seaborn as sns
from collections import defaultdict

class AdvancedLAEFTuner:
    """
    Advanced tuning system with multi-dimensional analysis:
    - Multiple backtest comparison
    - Symbol-specific patterns
    - Time-based patterns
    - Indicator correlations
    """
    
    def __init__(self):
        self.all_decisions = pd.DataFrame()
        self.all_trades = pd.DataFrame()
        self.backtest_summaries = []
        self.symbol_performance = defaultdict(dict)
        self.time_patterns = defaultdict(list)
        self.indicator_correlations = {}
        self.recommendations = {}
        
    def load_all_backtests(self, limit=5):
        """Load multiple recent backtest files for comparison"""
        print(f"🔍 Loading up to {limit} recent backtests...")
        
        # Find all decision and trade files
        decision_files = sorted(glob.glob('logs/backtest_decisions_*.csv'), 
                               key=os.path.getctime, reverse=True)[:limit]
        trade_files = sorted(glob.glob('logs/backtest_trades_*.csv'), 
                            key=os.path.getctime, reverse=True)[:limit]
        summary_files = sorted(glob.glob('logs/backtest_summary_*.txt'), 
                              key=os.path.getctime, reverse=True)[:limit]
        
        if not decision_files:
            print("❌ No backtest files found")
            return False
            
        # Load and combine all data
        all_decisions = []
        all_trades = []
        
        for i, (dec_file, trade_file) in enumerate(zip(decision_files, trade_files)):
            try:
                # Load decisions
                df_dec = pd.read_csv(dec_file)
                df_dec['backtest_id'] = i
                df_dec['backtest_date'] = dec_file.split('_')[-1].replace('.csv', '')
                all_decisions.append(df_dec)
                
                # Load trades
                if os.path.exists(trade_file):
                    df_trade = pd.read_csv(trade_file)
                    df_trade['backtest_id'] = i
                    df_trade['backtest_date'] = trade_file.split('_')[-1].replace('.csv', '')
                    all_trades.append(df_trade)
                    
                print(f"   ✅ Loaded backtest {i+1}: {len(df_dec)} decisions, {len(df_trade) if os.path.exists(trade_file) else 0} trades")
                
            except Exception as e:
                print(f"   ⚠️ Failed to load backtest {i+1}: {e}")
                
        # Combine all data
        self.all_decisions = pd.concat(all_decisions, ignore_index=True) if all_decisions else pd.DataFrame()
        self.all_trades = pd.concat(all_trades, ignore_index=True) if all_trades else pd.DataFrame()
        
        # Parse timestamps
        if not self.all_decisions.empty:
            self.all_decisions['timestamp'] = pd.to_datetime(self.all_decisions['timestamp'])
            self.all_decisions['hour'] = self.all_decisions['timestamp'].dt.hour
            self.all_decisions['day_of_week'] = self.all_decisions['timestamp'].dt.dayofweek
            
        if not self.all_trades.empty:
            self.all_trades['timestamp'] = pd.to_datetime(self.all_trades['timestamp'])
            
        # Load summaries
        for sum_file in summary_files:
            try:
                with open(sum_file, 'r') as f:
                    content = f.read()
                    summary = self._parse_summary(content)
                    summary['file'] = sum_file
                    self.backtest_summaries.append(summary)
            except:
                pass
                
        print(f"\n✅ Total data loaded:")
        print(f"   • {len(self.all_decisions)} decisions across {len(decision_files)} backtests")
        print(f"   • {len(self.all_trades)} trades executed")
        print(f"   • {len(self.backtest_summaries)} summaries parsed")
        
        return True
    
    def _parse_summary(self, content):
        """Parse summary file content"""
        summary = {}
        
        # Extract metrics using regex
        patterns = {
            'total_return': r'Total Return: ([-+]?\d+\.?\d*)%',
            'win_rate': r'Win Rate: (\d+\.?\d*)%',
            'execution_rate': r'Execution Rate: (\d+\.?\d*)%',
            'total_trades': r'Total Trades: (\d+)',
            'realized_pnl': r'Realized P&L: \$([+-]?\d+\.?\d*)'
        }
        
        for key, pattern in patterns.items():
            match = re.search(pattern, content)
            if match:
                summary[key] = float(match.group(1))
                
        return summary
    
    def analyze_symbol_patterns(self):
        """Analyze performance patterns by symbol"""
        print("\n🎯 SYMBOL-SPECIFIC PATTERN ANALYSIS")
        print("=" * 50)
        
        if self.all_decisions.empty:
            return
            
        symbols = self.all_decisions['symbol'].unique()
        
        for symbol in symbols:
            symbol_decisions = self.all_decisions[self.all_decisions['symbol'] == symbol]
            symbol_trades = self.all_trades[self.all_trades['symbol'] == symbol] if not self.all_trades.empty else pd.DataFrame()
            
            # Calculate metrics
            total_decisions = len(symbol_decisions)
            buy_signals = len(symbol_decisions[symbol_decisions['decision'] == 'buy'])
            sell_signals = len(symbol_decisions[symbol_decisions['decision'] == 'sell'])
            executed_trades = len(symbol_trades) if not symbol_trades.empty else 0
            
            # Calculate average indicators
            avg_q_value = symbol_decisions['q_value'].mean()
            avg_rsi = symbol_decisions['rsi'].mean()
            
            # Calculate profitability
            if not symbol_trades.empty and 'pnl' in symbol_trades.columns:
                profitable_trades = symbol_trades[symbol_trades['pnl'] > 0]
                total_pnl = symbol_trades['pnl'].sum()
                win_rate = len(profitable_trades) / len(symbol_trades) * 100 if len(symbol_trades) > 0 else 0
            else:
                total_pnl = 0
                win_rate = 0
                
            # Store analysis
            self.symbol_performance[symbol] = {
                'total_decisions': total_decisions,
                'buy_signals': buy_signals,
                'sell_signals': sell_signals,
                'executed_trades': executed_trades,
                'execution_rate': executed_trades / buy_signals * 100 if buy_signals > 0 else 0,
                'avg_q_value': avg_q_value,
                'avg_rsi': avg_rsi,
                'total_pnl': total_pnl,
                'win_rate': win_rate
            }
            
        # Print symbol analysis
        print("\n📊 Symbol Performance Summary:")
        print(f"{'Symbol':<8} {'Decisions':<10} {'Exec Rate':<10} {'Avg Q':<8} {'Total P&L':<10} {'Win Rate':<10}")
        print("-" * 60)
        
        for symbol, metrics in sorted(self.symbol_performance.items(), 
                                     key=lambda x: x[1]['total_pnl'], reverse=True):
            print(f"{symbol:<8} {metrics['total_decisions']:<10} "
                  f"{metrics['execution_rate']:<10.1f} {metrics['avg_q_value']:<8.3f} "
                  f"${metrics['total_pnl']:<10.2f} {metrics['win_rate']:<10.1f}%")
            
        # Generate recommendations
        best_symbol = max(self.symbol_performance.items(), key=lambda x: x[1]['total_pnl'])[0]
        worst_symbol = min(self.symbol_performance.items(), key=lambda x: x[1]['total_pnl'])[0]
        
        print(f"\n💡 Symbol Recommendations:")
        print(f"   • Best performer: {best_symbol} (${self.symbol_performance[best_symbol]['total_pnl']:.2f})")
        print(f"   • Worst performer: {worst_symbol} (${self.symbol_performance[worst_symbol]['total_pnl']:.2f})")
        print(f"   • Consider focusing on symbols with high win rates and positive P&L")
    
    def analyze_time_patterns(self):
        """Analyze patterns by time of day and day of week"""
        print("\n⏰ TIME-BASED PATTERN ANALYSIS")
        print("=" * 50)
        
        if self.all_decisions.empty:
            return
            
        # Analyze by hour of day
        hourly_execution = self.all_decisions.groupby('hour').agg({
            'executed': 'mean',
            'q_value': 'mean',
            'decision': lambda x: (x == 'buy').sum()
        }).rename(columns={'executed': 'execution_rate', 'decision': 'buy_signals'})
        
        print("\n📊 Hourly Pattern Analysis:")
        print(f"{'Hour':<6} {'Exec Rate':<12} {'Avg Q-Value':<12} {'Buy Signals':<12}")
        print("-" * 45)
        
        for hour in range(9, 17):  # Market hours
            if hour in hourly_execution.index:
                row = hourly_execution.loc[hour]
                print(f"{hour:02d}:00  {row['execution_rate']*100:<12.1f} "
                      f"{row['q_value']:<12.3f} {int(row['buy_signals']):<12}")
                      
        # Find best trading hours
        best_hour = hourly_execution['execution_rate'].idxmax()
        print(f"\n💡 Best execution hour: {best_hour:02d}:00 ({hourly_execution.loc[best_hour]['execution_rate']*100:.1f}% execution)")
        
        # Analyze by day of week
        daily_performance = self.all_decisions.groupby('day_of_week').agg({
            'executed': 'mean',
            'q_value': 'mean'
        })
        
        days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
        print("\n📊 Day of Week Analysis:")
        for day_num, day_name in enumerate(days):
            if day_num in daily_performance.index:
                row = daily_performance.loc[day_num]
                print(f"   {day_name}: {row['executed']*100:.1f}% execution, Q-avg: {row['q_value']:.3f}")
    
    def analyze_indicator_correlations(self):
        """Analyze correlations between indicators and successful trades"""
        print("\n🔗 INDICATOR CORRELATION ANALYSIS")
        print("=" * 50)
        
        if self.all_decisions.empty:
            return
            
        # Focus on executed trades
        executed_decisions = self.all_decisions[self.all_decisions['executed'] == True].copy()
        
        if len(executed_decisions) < 10:
            print("⚠️ Not enough executed trades for correlation analysis")
            return
            
        # Prepare data for correlation
        indicators = ['q_value', 'rsi', 'macd', 'signal']
        
        # Calculate correlations between indicators
        correlation_matrix = executed_decisions[indicators].corr()
        
        print("\n📊 Indicator Correlations (for executed trades):")
        print(correlation_matrix.round(3))
        
        # Analyze successful patterns
        print("\n🎯 Successful Trade Patterns:")
        
        # Find common indicator combinations
        buy_decisions = executed_decisions[executed_decisions['decision'] == 'buy']
        if len(buy_decisions) > 0:
            print(f"\n   Successful BUY patterns (n={len(buy_decisions)}):")
            print(f"   • Average Q-value: {buy_decisions['q_value'].mean():.3f}")
            print(f"   • Average RSI: {buy_decisions['rsi'].mean():.1f}")
            print(f"   • Q > 0.6 AND RSI < 40: {len(buy_decisions[(buy_decisions['q_value'] > 0.6) & (buy_decisions['rsi'] < 40)])} trades")
            
        # Analyze indicator ranges for successful trades
        print("\n📈 Optimal Indicator Ranges (based on executed trades):")
        
        percentiles = [25, 50, 75]
        for indicator in indicators:
            values = executed_decisions[indicator].dropna()
            if len(values) > 0:
                print(f"\n   {indicator.upper()}:")
                for p in percentiles:
                    val = np.percentile(values, p)
                    print(f"     {p}th percentile: {val:.3f}")
                    
        # Generate correlation-based recommendations
        self._generate_correlation_recommendations(executed_decisions)
    
    def _generate_correlation_recommendations(self, executed_decisions):
        """Generate recommendations based on correlations"""
        
        # Find the most successful indicator combinations
        if len(executed_decisions) > 20:
            # High Q + Low RSI pattern
            high_q_low_rsi = executed_decisions[(executed_decisions['q_value'] > 0.65) & 
                                               (executed_decisions['rsi'] < 40)]
            if len(high_q_low_rsi) > 5:
                success_rate = len(high_q_low_rsi) / len(executed_decisions) * 100
                print(f"\n💡 Pattern: High Q (>0.65) + Low RSI (<40) = {success_rate:.1f}% of successful trades")
                
            # MACD crossover pattern
            macd_cross = executed_decisions[executed_decisions['macd'] > executed_decisions['signal']]
            if len(macd_cross) > 5:
                success_rate = len(macd_cross) / len(executed_decisions) * 100
                print(f"💡 Pattern: MACD > Signal = {success_rate:.1f}% of successful trades")
    
    def analyze_backtest_progression(self):
        """Analyze how performance changed across multiple backtests"""
        print("\n📈 BACKTEST PROGRESSION ANALYSIS")
        print("=" * 50)
        
        if not self.backtest_summaries:
            return
            
        # Sort by date
        sorted_summaries = sorted(self.backtest_summaries, 
                                 key=lambda x: x['file'].split('_')[-1])
        
        print("\n📊 Performance Over Time:")
        print(f"{'Date':<15} {'Return':<10} {'Win Rate':<10} {'Exec Rate':<10} {'Trades':<10}")
        print("-" * 55)
        
        returns = []
        for summary in sorted_summaries:
            date = summary['file'].split('_')[-1].replace('.txt', '')
            total_return = summary.get('total_return', 0)
            win_rate = summary.get('win_rate', 0)
            exec_rate = summary.get('execution_rate', 0)
            trades = summary.get('total_trades', 0)
            
            returns.append(total_return)
            
            print(f"{date:<15} {total_return:<10.2f}% {win_rate:<10.1f}% "
                  f"{exec_rate:<10.1f}% {int(trades):<10}")
            
        # Analyze trend
        if len(returns) > 2:
            trend = "improving" if returns[-1] > returns[0] else "declining"
            avg_return = np.mean(returns)
            
            print(f"\n💡 Performance Trend: {trend.upper()}")
            print(f"   • First backtest: {returns[0]:.2f}%")
            print(f"   • Latest backtest: {returns[-1]:.2f}%")
            print(f"   • Average return: {avg_return:.2f}%")
            
            if trend == "declining":
                print("   ⚠️ Consider reverting recent changes or trying new approaches")
    
    def generate_advanced_recommendations(self):
        """Generate comprehensive recommendations based on all analyses"""
        print("\n🎯 ADVANCED RECOMMENDATIONS")
        print("=" * 60)
        
        recommendations = []
        
        # Symbol-based recommendations
        if self.symbol_performance:
            # Find consistently profitable symbols
            profitable_symbols = [s for s, m in self.symbol_performance.items() 
                                if m['total_pnl'] > 0 and m['win_rate'] > 60]
            if profitable_symbols:
                recommendations.append(f"Focus on profitable symbols: {', '.join(profitable_symbols)}")
                
            # Find problem symbols
            problem_symbols = [s for s, m in self.symbol_performance.items() 
                             if m['total_pnl'] < -500 or m['win_rate'] < 40]
            if problem_symbols:
                recommendations.append(f"Consider excluding: {', '.join(problem_symbols)}")
        
        # Time-based recommendations
        if not self.all_decisions.empty:
            # Check if certain hours are better
            hourly_exec = self.all_decisions.groupby('hour')['executed'].mean()
            best_hours = hourly_exec[hourly_exec > hourly_exec.mean()].index.tolist()
            if best_hours:
                recommendations.append(f"Best trading hours: {best_hours}")
        
        # Indicator-based recommendations
        if len(self.all_decisions) > 100:
            avg_q = self.all_decisions['q_value'].mean()
            if avg_q > 0.7:
                recommendations.append("ML model is very bullish - consider lowering Q thresholds")
            elif avg_q < 0.3:
                recommendations.append("ML model is very bearish - consider retraining")
                
        # Print all recommendations
        print("\n📋 Action Items:")
        for i, rec in enumerate(recommendations, 1):
            print(f"{i}. {rec}")
            
        # Generate optimized config based on multi-dimensional analysis
        self._generate_optimized_config()
    
    def _generate_optimized_config(self):
        """Generate config based on comprehensive analysis"""
        print("\n🔧 GENERATING MULTI-DIMENSIONAL OPTIMIZED CONFIG")
        print("=" * 50)
        
        # Start with baseline
        optimized = {
            'q_buy': 0.58,
            'q_sell': 0.42,
            'rsi_oversold': 35,
            'rsi_overbought': 65,
            'sell_profit_pct': 0.05,
            'stop_loss_pct': 0.97
        }
        
        # Adjust based on symbol performance
        if self.symbol_performance:
            avg_exec_rate = np.mean([m['execution_rate'] for m in self.symbol_performance.values()])
            if avg_exec_rate < 10:
                optimized['q_buy'] = 0.55  # Lower threshold for more trades
                print("   • Lowered Q-buy to 0.55 (low execution rate across symbols)")
                
        # Adjust based on time patterns
        if hasattr(self, 'hourly_execution') and not self.all_decisions.empty:
            # If most trades happen in narrow time window, be more aggressive
            hourly_variance = self.all_decisions.groupby('hour')['executed'].mean().var()
            if hourly_variance > 0.01:
                optimized['rsi_oversold'] = 40
                optimized['rsi_overbought'] = 60
                print("   • Widened RSI range (high time variance)")
                
        # Save optimized config
        config_str = f'''TRADING_THRESHOLDS = {{
    "q_buy": {optimized['q_buy']:.2f},
    "q_sell": {optimized['q_sell']:.2f},
    "rsi_oversold": {optimized['rsi_oversold']:.0f},
    "rsi_overbought": {optimized['rsi_overbought']:.0f},
    "macd_buy": -0.05,
    "macd_sell": 0.05,
    "buy_drop_pct": 0.025,
    "sell_profit_pct": {optimized['sell_profit_pct']:.3f},
    "stop_loss_pct": {optimized['stop_loss_pct']:.3f}
}}'''
        
        with open('config_profiles/advanced_optimized_config.txt', 'w') as f:
            f.write(config_str)
            
        print(f"\n✅ Advanced optimized config saved to: config_profiles/advanced_optimized_config.txt")
    
    def create_visual_report(self):
        """Create visual analysis report"""
        print("\n📊 Creating visual analysis report...")
        
        try:
            fig, axes = plt.subplots(2, 2, figsize=(12, 10))
            fig.suptitle('LAEF Trading System Analysis', fontsize=16)
            
            # 1. Symbol Performance
            if self.symbol_performance:
                ax = axes[0, 0]
                symbols = list(self.symbol_performance.keys())
                pnls = [self.symbol_performance[s]['total_pnl'] for s in symbols]
                colors = ['green' if p > 0 else 'red' for p in pnls]
                ax.bar(symbols, pnls, color=colors)
                ax.set_title('P&L by Symbol')
                ax.set_ylabel('Total P&L ($)')
                ax.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
                
            # 2. Hourly Distribution
            if not self.all_decisions.empty:
                ax = axes[0, 1]
                hourly_counts = self.all_decisions['hour'].value_counts().sort_index()
                ax.plot(hourly_counts.index, hourly_counts.values, marker='o')
                ax.set_title('Trading Activity by Hour')
                ax.set_xlabel('Hour of Day')
                ax.set_ylabel('Number of Decisions')
                ax.set_xlim(9, 16)
                
            # 3. Q-Value Distribution
            if not self.all_decisions.empty:
                ax = axes[1, 0]
                ax.hist(self.all_decisions['q_value'].dropna(), bins=30, alpha=0.7, color='blue')
                ax.axvline(x=0.6, color='red', linestyle='--', label='Current Buy Threshold')
                ax.set_title('Q-Value Distribution')
                ax.set_xlabel('Q-Value')
                ax.set_ylabel('Frequency')
                ax.legend()
                
            # 4. RSI Distribution
            if not self.all_decisions.empty:
                ax = axes[1, 1]
                ax.hist(self.all_decisions['rsi'].dropna(), bins=30, alpha=0.7, color='orange')
                ax.axvline(x=30, color='red', linestyle='--', label='Oversold')
                ax.axvline(x=70, color='red', linestyle='--', label='Overbought')
                ax.set_title('RSI Distribution')
                ax.set_xlabel('RSI')
                ax.set_ylabel('Frequency')
                ax.legend()
                
            plt.tight_layout()
            plt.savefig('laef_analysis_report.png', dpi=150)
            print("   ✅ Visual report saved to: laef_analysis_report.png")
            plt.close()
            
        except Exception as e:
            print(f"   ⚠️ Could not create visual report: {e}")
    
    def run_complete_analysis(self):
        """Run all analyses"""
        print("🤖 ADVANCED MULTI-DIMENSIONAL LAEF ANALYSIS")
        print("=" * 60)
        
        # Load all available data
        if not self.load_all_backtests():
            return
            
        # Run all analyses
        self.analyze_backtest_progression()
        self.analyze_symbol_patterns()
        self.analyze_time_patterns()
        self.analyze_indicator_correlations()
        
        # Generate recommendations
        self.generate_advanced_recommendations()
        
        # Create visual report
        self.create_visual_report()
        
        print("\n✅ Complete analysis finished!")
        print("📋 Files generated:")
        print("   • advanced_optimized_config.txt - Optimized parameters")
        print("   • laef_analysis_report.png - Visual analysis")

def main():
    tuner = AdvancedLAEFTuner()
    tuner.run_complete_analysis()

if __name__ == "__main__":
    main()
