# === integrated_workflow.py - Complete Analysis to Application Workflow ===

import os
import subprocess
import sys
from datetime import datetime

class LAEFIntegratedWorkflow:
    """Seamless workflow from analysis to application"""
    
    def __init__(self):
        self.workflow_steps = [
            "Validate ML model behavior",
            "Run profit-focused optimization",
            "Generate optimized configuration profile",
            "Save to configuration manager"
        ]
        
    def check_prerequisites(self):
        """Check if all required files exist"""
        required_files = [
            'optimization/profit_focused_optimizer.py',
            'testing/check_ML_Learning.py',
            'config.py',
            'core/config_manager.py'
        ]
        
        print("🔍 Checking prerequisites...")
        all_present = True
        
        for file in required_files:
            if os.path.exists(file):
                print(f"   ✅ {file}")
            else:
                print(f"   ❌ {file} - MISSING")
                all_present = False
                
        # Check for backtest logs
        log_count = len([f for f in os.listdir('logs') if f.startswith('backtest_decisions_')])
        print(f"\n   📊 Found {log_count} backtest logs")
        
        if log_count == 0:
            print("   ⚠️ No backtest logs found - need to run backtests first")
            all_present = False
            
        return all_present
    
    def run_ml_validation(self):
        """Run ML learning check"""
        print("\n🧠 STEP 1: Validating ML Model Behavior")
        print("=" * 50)
        
        try:
            result = subprocess.run([sys.executable, 'testing/check_ML_Learning.py'], 
                                  capture_output=True, text=True)
            
            # Show key results
            output = result.stdout
            if "EXCELLENT: Your backtests appear to be valid!" in output:
                print("✅ ML model validation PASSED - backtests are valid")
                return True
            else:
                print("⚠️ ML model validation has warnings")
                print("Review the full output above")
                return False
                
        except Exception as e:
            print(f"❌ Failed to run ML validation: {e}")
            return False
    
    def run_analysis(self):
        """Run profit-focused optimization analysis"""
        print("\n📊 STEP 2: Running Profit-Focused Optimization")
        print("=" * 50)
        
        try:
            print("Analyzing your backtest results for maximum profit...")
            # Import and run the profit focused optimizer
            from optimization.profit_focused_optimizer import ProfitFocusedOptimizer
            
            optimizer = ProfitFocusedOptimizer()
            success = optimizer.run_complete_optimization()
            
            if success:
                print("\n✅ Optimization complete!")
                print("   • Configuration saved to profile manager")
                print("   • Original config.py remains untouched")
                return True
            else:
                print("\n⚠️ Optimization did not complete successfully")
                return False
                
        except Exception as e:
            print(f"❌ Failed to run optimization: {e}")
            return False
    
    def show_recommendations(self):
        """Display the available configuration profiles"""
        print("\n💡 STEP 3: Review Available Configurations")
        print("=" * 50)
        
        try:
            from core.config_manager import config_manager
            config_manager.list_profiles()
            return True
        except Exception as e:
            print(f"❌ Could not display configuration profiles: {e}")
            return False
    
    def apply_recommendations(self):
        """Explain how to use the optimized configuration"""
        print("\n🔧 STEP 4: Using Your Optimized Configuration")
        print("=" * 50)
        
        print("✅ Your optimized configuration has been saved!")
        print("")
        print("📋 How to use the optimized settings:")
        print("   1. When running backtests, paper trading, or live trading")
        print("   2. You'll be prompted to select a configuration profile")
        print("   3. Choose 'OPTIMIZED' to use the profit-maximized settings")
        print("   4. The original config.py remains unchanged for safety")
        print("")
        print("🔄 To test the optimized configuration:")
        print("   • Go back to main menu → option 3 (Backtesting)")
        print("   • Select 'OPTIMIZED' configuration when prompted")
        print("   • Compare results with previous backtests")
        print("")
        
        return True
    
    def suggest_next_steps(self):
        """Suggest what to do next"""
        print("\n🚀 NEXT STEPS")
        print("=" * 50)
        print("1. Test the optimized configuration:")
        print("   • Return to main menu → option 3 (Backtesting)")
        print("   • Select 'OPTIMIZED' configuration when prompted")
        print("   • Compare results with previous runs")
        print("")
        print("2. If results improve, gradually move to live trading:")
        print("   • Test with paper trading first (option 2)")
        print("   • Monitor performance over several days")
        print("   • Only then consider live trading (option 1)")
        print("")
        print("3. Re-optimize periodically:")
        print("   • Run new backtests with different symbols/periods")
        print("   • Re-run this optimization workflow (option 0)")
        print("   • Keep refining your strategy")
    
    def run_complete_workflow(self):
        """Execute the complete workflow"""
        print("🚀 LAEF INTEGRATED OPTIMIZATION WORKFLOW")
        print("=" * 60)
        print("This workflow will:")
        print("1. Validate your ML model behavior")
        print("2. Analyze your backtest results")
        print("3. Generate optimized configuration")
        print("4. Apply the improvements")
        print("")
        
        # Check prerequisites
        if not self.check_prerequisites():
            print("\n❌ Prerequisites check failed")
            print("Please ensure all required files are present and you have backtest logs")
            return
        
        # Get user confirmation
        confirm = input("\nProceed with optimization workflow? (y/n): ").strip().lower()
        if confirm != 'y':
            print("❌ Workflow cancelled")
            return
        
        # Run workflow steps
        steps_completed = []
        
        # Step 1: ML Validation
        if self.run_ml_validation():
            steps_completed.append("ML Validation")
        
        # Step 2: Analysis
        if self.run_analysis():
            steps_completed.append("Analysis")
            
            # Step 3: Review
            if self.show_recommendations():
                steps_completed.append("Review")
                
                # Ask before applying
                apply = input("\nApply these recommendations? (y/n): ").strip().lower()
                if apply == 'y':
                    # Step 4: Apply
                    if self.apply_recommendations():
                        steps_completed.append("Application")
                else:
                    print("⏸️ Skipping application step")
        
        # Summary
        print("\n📊 WORKFLOW SUMMARY")
        print("=" * 50)
        print(f"Steps completed: {len(steps_completed)}/4")
        for step in steps_completed:
            print(f"   ✅ {step}")
        
        if len(steps_completed) == 4:
            print("\n🎉 OPTIMIZATION COMPLETE!")
            self.suggest_next_steps()
        else:
            print("\n⚠️ Workflow partially completed")
            print("Review any errors above and try again")

def main():
    """Run the integrated workflow"""
    workflow = LAEFIntegratedWorkflow()
    
    try:
        workflow.run_complete_workflow()
    except KeyboardInterrupt:
        print("\n\n❌ Workflow interrupted by user")
    except Exception as e:
        print(f"\n❌ Workflow error: {e}")

if __name__ == "__main__":
    main()
