# === profit_focused_optimizer.py - TRUE Profit-Maximizing Optimizer ===

import pandas as pd
import numpy as np
import glob
import os
import json
from datetime import datetime
from itertools import product
import logging

class ProfitFocusedOptimizer:
    """
    A TRUE optimizer that focuses solely on maximizing total portfolio profit.
    
    This optimizer:
    1. Analyzes EVERY decision and trade from backtests
    2. Calculates what the TOTAL P&L would have been with different settings
    3. Runs counterfactual analysis ("what if we had different thresholds?")
    4. Optimizes configuration based on ONLY profit maximization
    """
    
    def __init__(self):
        self.all_decisions = pd.DataFrame()
        self.all_trades = pd.DataFrame()
        self.total_pnl_by_config = {}
        self.best_config = None
        self.analysis_results = {}
        self.best_pnl = 0
        self.actual_pnl = {'total': 0}
        self.total_configs_tested = 0
        
    def load_latest_backtest(self):
        """Load the most recent backtest data"""
        print("Loading latest backtest data...")
        
        # Find most recent files
        decision_files = sorted(glob.glob('logs/backtest_decisions_*.csv'), 
                               key=os.path.getctime, reverse=True)
        trade_files = sorted(glob.glob('logs/backtest_trades_*.csv'), 
                            key=os.path.getctime, reverse=True)
        
        if not decision_files:
            print("❌ No backtest files found!")
            return False
            
        latest_decision_file = decision_files[0]
        latest_trade_file = trade_files[0] if trade_files else None
        
        # Load decisions
        self.all_decisions = pd.read_csv(latest_decision_file)
        self.all_decisions['timestamp'] = pd.to_datetime(self.all_decisions['timestamp'])
        
        # Load trades if available
        if latest_trade_file and os.path.exists(latest_trade_file):
            self.all_trades = pd.read_csv(latest_trade_file)
            self.all_trades['timestamp'] = pd.to_datetime(self.all_trades['timestamp'])
        
        print(f"Loaded {len(self.all_decisions)} decisions and {len(self.all_trades)} trades")
        return True
    
    def calculate_actual_total_pnl(self):
        """Calculate the REAL total P&L using actual trades and remaining positions"""
        print("\nCALCULATING TRUE TOTAL P&L...")
        print("=" * 50)
        
        # Get realized P&L from actual trades
        if self.all_trades.empty:
            realized_pnl = 0
        else:
            realized_pnl = self.all_trades['pnl'].sum() if 'pnl' in self.all_trades.columns else 0
        
        # Track open positions using actual trade data
        open_positions = {}
        
        # Process all trades to determine current open positions
        for _, trade in self.all_trades.iterrows():
            symbol = trade['symbol']
            action = trade['action']
            quantity = trade['quantity']
            price = trade['price']
            timestamp = trade['timestamp']
            
            if action == 'BUY':
                if symbol not in open_positions:
                    open_positions[symbol] = []
                open_positions[symbol].append({
                    'buy_price': price,
                    'shares': quantity,
                    'timestamp': timestamp
                })
            elif action == 'SELL' and symbol in open_positions:
                # Remove shares (FIFO)
                remaining_to_sell = quantity
                while remaining_to_sell > 0 and open_positions[symbol]:
                    position = open_positions[symbol][0]
                    if position['shares'] <= remaining_to_sell:
                        # Sell entire position
                        remaining_to_sell -= position['shares']
                        open_positions[symbol].pop(0)
                    else:
                        # Partial sell
                        position['shares'] -= remaining_to_sell
                        remaining_to_sell = 0
                
                if not open_positions[symbol]:
                    del open_positions[symbol]
        
        # Calculate unrealized P&L for remaining open positions
        unrealized_pnl = 0
        total_open_positions = 0
        
        for symbol, positions in open_positions.items():
            # Get latest price for this symbol from decisions
            latest_price_data = self.all_decisions[self.all_decisions['symbol'] == symbol]
            if not latest_price_data.empty:
                latest_price = latest_price_data.iloc[-1]['price']
                
                for position in positions:
                    unrealized_pnl += (latest_price - position['buy_price']) * position['shares']
                    total_open_positions += position['shares']
        
        total_pnl = realized_pnl + unrealized_pnl
        
        print(f"Realized P&L: ${realized_pnl:,.2f}")
        print(f"Unrealized P&L: ${unrealized_pnl:,.2f}")
        print(f"TOTAL P&L: ${total_pnl:,.2f}")
        print(f"Open positions: {len(sum(open_positions.values(), []))} positions, {total_open_positions} total shares")
        
        return {
            'realized': realized_pnl,
            'unrealized': unrealized_pnl,
            'total': total_pnl,
            'open_positions': len(sum(open_positions.values(), [])),
            'open_shares': total_open_positions
        }
    
    def run_counterfactual_analysis(self):
        """Run 'what-if' analysis with different configuration settings"""
        print("\nRUNNING COUNTERFACTUAL ANALYSIS...")
        print("=" * 50)
        print("Testing different configurations to see what would have made more money...")
        
        # Define parameter ranges for dual-model optimization
        q_buy_range = [0.55, 0.58, 0.60, 0.65]        # Q-value for entry conviction
        q_sell_range = [0.35, 0.40, 0.42, 0.45]       # Q-value for exit conviction  
        ml_profit_peak_range = [0.55, 0.58, 0.60, 0.65] # ML confidence for profit timing
        rsi_oversold_range = [30, 35, 40]
        rsi_overbought_range = [60, 65, 70]
        profit_target_range = [0.04, 0.05, 0.06, 0.07]
        stop_loss_range = [0.96, 0.97, 0.98]  # 4%, 3%, 2%
        
        best_pnl = float('-inf')
        best_config = None
        test_count = 0
        
        total_configs = len(q_buy_range) * len(q_sell_range) * len(ml_profit_peak_range) * len(rsi_oversold_range) * len(rsi_overbought_range) * len(profit_target_range) * len(stop_loss_range)
        print(f"Testing {total_configs} dual-model configurations...")
        
        for q_buy in q_buy_range:
            for q_sell in q_sell_range:
                for ml_profit_peak in ml_profit_peak_range:
                    for rsi_oversold in rsi_oversold_range:
                        for rsi_overbought in rsi_overbought_range:
                            for profit_target in profit_target_range:
                                for stop_loss in stop_loss_range:
                                    test_count += 1
                                    
                                    # Skip invalid combinations
                                    if q_buy <= q_sell or rsi_oversold >= rsi_overbought:
                                        continue
                                    
                                    config = {
                                        'q_buy': q_buy,
                                        'q_sell': q_sell,
                                        'ml_profit_peak': ml_profit_peak,
                                        'rsi_oversold': rsi_oversold,
                                        'rsi_overbought': rsi_overbought,
                                        'profit_target': profit_target,
                                        'stop_loss': stop_loss
                                    }
                                    
                                    # Simulate what would have happened with this config
                                    simulated_pnl = self._simulate_config(config)
                                    
                                    if simulated_pnl > best_pnl:
                                        best_pnl = simulated_pnl
                                        best_config = config.copy()
                                        print(f"   New best config found! P&L: ${best_pnl:,.2f}")
                                        print(f"      Q: {q_buy}/{q_sell}, ML: {ml_profit_peak}, RSI: {rsi_oversold}/{rsi_overbought}, "
                                              f"Profit: {profit_target*100:.1f}%, Stop: {(1-stop_loss)*100:.1f}%")
                                    
                                    if test_count % 1000 == 0:
                                        print(f"   Tested {test_count} configurations...")
        
        self.best_config = best_config
        self.best_pnl = best_pnl
        self.total_configs_tested = test_count
        
        print(f"\nBEST CONFIGURATION FOUND:")
        print(f"   Total P&L: ${best_pnl:,.2f}")
        print(f"   Configuration: {best_config}")
        print(f"   Tested {test_count} configurations")
        
        return best_config, best_pnl
    
    def _simulate_config(self, config):
        """Simulate what the P&L would have been with different config settings"""
        total_pnl = 0
        portfolio_cash = 100000
        open_positions = {}
        
        for _, decision in self.all_decisions.iterrows():
            symbol = decision['symbol']
            q_value = decision.get('q_value', 0.5)
            ml_confidence = decision.get('confidence', 0.5)  # ML confidence score
            rsi = decision.get('rsi', 50)
            current_price = decision['price']
            
            # Simulate buy decision using dual-model logic
            if self._would_buy(q_value, ml_confidence, rsi, config):
                # Use realistic position sizing based on actual trade data
                # Average position size from actual trades is around $2400-2500
                target_position_value = 2500  # Based on actual trade data
                if portfolio_cash >= target_position_value:
                    shares = int(target_position_value / current_price)
                    actual_cost = shares * current_price
                    if shares > 0 and actual_cost <= portfolio_cash:
                        if symbol not in open_positions:
                            open_positions[symbol] = []
                        open_positions[symbol].append({
                            'buy_price': current_price,
                            'shares': shares,
                            'timestamp': decision['timestamp']
                        })
                        portfolio_cash -= actual_cost
            
            # Simulate sell decision using dual-model logic
            elif self._would_sell(q_value, ml_confidence, rsi, symbol, current_price, open_positions, config):
                if symbol in open_positions and open_positions[symbol]:
                    # Sell oldest position (FIFO)
                    position = open_positions[symbol].pop(0)
                    sell_value = position['shares'] * current_price
                    buy_value = position['shares'] * position['buy_price']
                    trade_pnl = sell_value - buy_value
                    
                    total_pnl += trade_pnl
                    portfolio_cash += sell_value
                    
                    if not open_positions[symbol]:
                        del open_positions[symbol]
        
        # Add unrealized P&L for remaining positions
        for symbol, positions in open_positions.items():
            # Get final price for this symbol
            final_price_row = self.all_decisions[self.all_decisions['symbol'] == symbol].iloc[-1]
            final_price = final_price_row['price']
            
            for position in positions:
                unrealized_pnl = (final_price - position['buy_price']) * position['shares']
                total_pnl += unrealized_pnl
        
        return total_pnl
    
    def _would_buy(self, q_value, ml_confidence, rsi, config):
        """Determine if we would buy with dual-model config (Option 4)"""
        # Entry decision based on Q-value conviction
        return q_value >= config['q_buy']
    
    def _would_sell(self, q_value, ml_confidence, rsi, symbol, current_price, open_positions, config):
        """Determine if we would sell with dual-model config (Option 4)"""
        if symbol not in open_positions or not open_positions[symbol]:
            return False
        
        # Get position details
        oldest_position = open_positions[symbol][0]
        buy_price = oldest_position['buy_price']
        profit_pct = (current_price - buy_price) / buy_price
        
        # PRIMARY: ML Profit Peak Detection
        if ml_confidence >= config['ml_profit_peak']:
            return True
        
        # SECONDARY: Q-Value Conviction Deteriorated 
        if q_value <= config['q_sell']:
            return True
        
        # TERTIARY: Traditional profit target (safety net)
        if profit_pct >= config['profit_target']:
            return True
        
        # QUATERNARY: Stop loss (risk management)
        if current_price / buy_price <= config['stop_loss']:
            return True
        
        return False
    
    def generate_profit_optimized_config(self):
        """Generate the final optimized configuration and save to config manager"""
        if not self.best_config:
            print("❌ No optimization run yet!")
            return
        
        print("\nGENERATING PROFIT-OPTIMIZED CONFIGURATION")
        print("=" * 60)
        
        config = self.best_config
        
        # Calculate performance data for storage
        performance_data = {
            'expected_improvement': f"${self.best_pnl - self.actual_pnl['total']:,.2f}",
            'optimization_date': datetime.now().isoformat(),
            'tested_configurations': self.total_configs_tested,
            'optimization_method': 'dual_model_counterfactual'
        }
        
        # Save to configuration manager instead of overwriting config.py
        try:
            from core.config_manager import config_manager
            
            optimized_config_data = {
                'q_buy': config['q_buy'],
                'q_sell': config['q_sell'], 
                'ml_profit_peak': config['ml_profit_peak'],
                'rsi_oversold': config['rsi_oversold'],
                'rsi_overbought': config['rsi_overbought'],
                'profit_target': config['profit_target'],
                'stop_loss': config['stop_loss']
            }
            
            config_manager.add_optimized_profile(optimized_config_data, performance_data)
            print("✅ Profit-optimized configuration saved to profile manager")
            print("   Original config.py remains untouched")
            print("   Access optimized settings through configuration selection menu")
            
        except Exception as e:
            print(f"⚠️ Could not save to config manager: {e}")
            print("   Falling back to text file...")
            
            # Fallback: save to text file
            config_str = f'''# DUAL-MODEL PROFIT-OPTIMIZED CONFIGURATION  
# Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
# Optimized using Option 4: Q-Value for Entry/Exit + ML Confidence for Profit Timing

TRADING_THRESHOLDS = {{
    # Q-Value thresholds for market entry/exit decisions
    "q_buy": {config['q_buy']:.2f},                      # Enter position when Q-value shows strong conviction
    "q_sell": {config['q_sell']:.2f},                     # Exit position when Q-value conviction deteriorates
    
    # ML Confidence thresholds for profit timing
    "ml_profit_peak": {config['ml_profit_peak']:.2f},     # Sell when ML detects profit peak opportunity
    
    # Technical analysis support
    "rsi_oversold": {config['rsi_oversold']:.0f},
    "rsi_overbought": {config['rsi_overbought']:.0f},
    "macd_buy": -0.05,
    "macd_sell": 0.05,
    
    # Risk management
    "buy_drop_pct": 0.025,
    "sell_profit_pct": {config['profit_target']:.3f},
    "stop_loss_pct": {config['stop_loss']:.3f}
}}

# DUAL-MODEL OPTIMIZATION SUMMARY:
# - Q-Value determines entry conviction (>= {config['q_buy']:.2f}) and exit necessity (<= {config['q_sell']:.2f})
# - ML Confidence identifies profit peaks (>= {config['ml_profit_peak']:.2f})
# - Selected configuration maximizes TOTAL P&L
# - Tested thousands of dual-model combinations
'''
            
            with open('config_profiles/profit_optimized_config.txt', 'w') as f:
                f.write(config_str)
            
            print("Profit-optimized configuration saved to: config_profiles/profit_optimized_config.txt")
        
        print("\nKey changes from current config:")
        
        # Compare with current config
        current_config = {
            'q_buy': 0.55,
            'q_sell': 0.35,
            'ml_profit_peak': 0.55,
            'rsi_oversold': 30,
            'rsi_overbought': 60,
            'profit_target': 0.04,
            'stop_loss': 0.96
        }
        
        for key, new_val in config.items():
            current_val = current_config.get(key, 0)
            if abs(new_val - current_val) > 0.001:
                direction = "↑" if new_val > current_val else "↓"
                print(f"   {key}: {current_val} → {new_val} {direction}")
    
    def run_complete_optimization(self):
        """Run the complete profit-focused optimization workflow"""
        print("STARTING PROFIT-FOCUSED OPTIMIZATION")
        print("=" * 60)
        
        if not self.load_latest_backtest():
            return False
        
        # Calculate actual performance
        self.actual_pnl = self.calculate_actual_total_pnl()
        
        # Run optimization
        best_config, best_pnl = self.run_counterfactual_analysis()
        
        # Analyze patterns in the decision data
        self._analyze_decision_patterns()
        
        # Generate insights about the findings
        self._generate_insights(best_config, best_pnl, self.actual_pnl['total'])
        
        # Show improvement potential
        improvement = best_pnl - self.actual_pnl['total']
        improvement_pct = (improvement / abs(self.actual_pnl['total'])) * 100 if self.actual_pnl['total'] != 0 else 0
        
        print(f"\nOPTIMIZATION RESULTS:")
        print(f"   Current Total P&L: ${self.actual_pnl['total']:,.2f}")
        print(f"   Optimized P&L: ${best_pnl:,.2f}")
        print(f"   Potential Improvement: ${improvement:,.2f} ({improvement_pct:+.1f}%)")
        
        # Generate final config
        self.generate_profit_optimized_config()
        
        return True
    
    def _analyze_decision_patterns(self):
        """Analyze patterns in the decision data to understand what drives profits/losses"""
        print("\nPATTERN ANALYSIS:")
        print("=" * 50)
        
        if self.all_decisions.empty:
            print("No decision data available for analysis")
            return
        
        # Analyze Q-value patterns
        self._analyze_q_value_patterns()
        
        # Analyze ML confidence patterns  
        self._analyze_ml_confidence_patterns()
        
        # Analyze technical indicator patterns
        self._analyze_technical_patterns()
        
        # Analyze execution patterns
        self._analyze_execution_patterns()
    
    def _analyze_q_value_patterns(self):
        """Analyze Q-value decision patterns"""
        print("\nQ-Value Decision Patterns:")
        
        # Get executed decisions
        executed = self.all_decisions[self.all_decisions['executed'] == True]
        held = self.all_decisions[self.all_decisions['executed'] == False]
        
        if len(executed) > 0:
            avg_q_executed = executed['q_value'].mean()
            avg_q_held = held['q_value'].mean() if len(held) > 0 else 0
            
            print(f"   • Average Q-value for executed trades: {avg_q_executed:.3f}")
            print(f"   • Average Q-value for held positions: {avg_q_held:.3f}")
            
            # Analyze Q-value distribution for executed trades
            high_q_executed = executed[executed['q_value'] >= 0.6]
            med_q_executed = executed[(executed['q_value'] >= 0.4) & (executed['q_value'] < 0.6)]
            low_q_executed = executed[executed['q_value'] < 0.4]
            
            print(f"   • High Q-value executions (≥0.6): {len(high_q_executed)} ({len(high_q_executed)/len(executed)*100:.1f}%)")
            print(f"   • Medium Q-value executions (0.4-0.6): {len(med_q_executed)} ({len(med_q_executed)/len(executed)*100:.1f}%)")
            print(f"   • Low Q-value executions (<0.4): {len(low_q_executed)} ({len(low_q_executed)/len(executed)*100:.1f}%)")
    
    def _analyze_ml_confidence_patterns(self):
        """Analyze ML confidence patterns"""
        print("\nML Confidence Patterns:")
        
        executed = self.all_decisions[self.all_decisions['executed'] == True]
        
        if len(executed) > 0:
            avg_conf_executed = executed['confidence'].mean()
            print(f"   • Average ML confidence for executed trades: {avg_conf_executed:.3f}")
            
            # Analyze confidence distribution
            high_conf = executed[executed['confidence'] >= 0.6]
            med_conf = executed[(executed['confidence'] >= 0.4) & (executed['confidence'] < 0.6)]
            low_conf = executed[executed['confidence'] < 0.4]
            
            print(f"   • High confidence executions (≥0.6): {len(high_conf)} ({len(high_conf)/len(executed)*100:.1f}%)")
            print(f"   • Medium confidence executions (0.4-0.6): {len(med_conf)} ({len(med_conf)/len(executed)*100:.1f}%)")
            print(f"   • Low confidence executions (<0.4): {len(low_conf)} ({len(low_conf)/len(executed)*100:.1f}%)")
    
    def _analyze_technical_patterns(self):
        """Analyze technical indicator patterns"""
        print("\nTechnical Indicator Patterns:")
        
        executed = self.all_decisions[self.all_decisions['executed'] == True]
        
        if len(executed) > 0:
            avg_rsi = executed['rsi'].mean()
            print(f"   • Average RSI for executed trades: {avg_rsi:.1f}")
            
            # RSI ranges for executed trades
            oversold = executed[executed['rsi'] < 35]
            neutral = executed[(executed['rsi'] >= 35) & (executed['rsi'] <= 65)]
            overbought = executed[executed['rsi'] > 65]
            
            print(f"   • Executions in oversold RSI (<35): {len(oversold)} ({len(oversold)/len(executed)*100:.1f}%)")
            print(f"   • Executions in neutral RSI (35-65): {len(neutral)} ({len(neutral)/len(executed)*100:.1f}%)")
            print(f"   • Executions in overbought RSI (>65): {len(overbought)} ({len(overbought)/len(executed)*100:.1f}%)")
    
    def _analyze_execution_patterns(self):
        """Analyze execution vs hold patterns"""
        print("\nExecution Patterns:")
        
        total_decisions = len(self.all_decisions)
        executed_decisions = len(self.all_decisions[self.all_decisions['executed'] == True])
        execution_rate = (executed_decisions / total_decisions) * 100 if total_decisions > 0 else 0
        
        print(f"   • Total decisions made: {total_decisions}")
        print(f"   • Decisions executed: {executed_decisions}")
        print(f"   • Overall execution rate: {execution_rate:.1f}%")
        
        # Analyze by decision type
        buy_decisions = self.all_decisions[self.all_decisions['decision'] == 'buy']
        sell_decisions = self.all_decisions[self.all_decisions['decision'] == 'sell']
        hold_decisions = self.all_decisions[self.all_decisions['decision'] == 'hold']
        
        if len(buy_decisions) > 0:
            buy_exec_rate = (len(buy_decisions[buy_decisions['executed'] == True]) / len(buy_decisions)) * 100
            print(f"   • Buy execution rate: {buy_exec_rate:.1f}% ({len(buy_decisions[buy_decisions['executed'] == True])}/{len(buy_decisions)})")
        
        if len(sell_decisions) > 0:
            sell_exec_rate = (len(sell_decisions[sell_decisions['executed'] == True]) / len(sell_decisions)) * 100
            print(f"   • Sell execution rate: {sell_exec_rate:.1f}% ({len(sell_decisions[sell_decisions['executed'] == True])}/{len(sell_decisions)})")
    
    def _generate_insights(self, best_config, best_pnl, current_pnl):
        """Generate insights about why the optimized config should work better"""
        print("\nSTRATEGIC INSIGHTS & RECOMMENDATIONS:")
        print("=" * 60)
        
        improvement = best_pnl - current_pnl
        improvement_pct = (improvement / abs(current_pnl)) * 100 if current_pnl != 0 else 0
        
        print(f"Expected Improvement: ${improvement:,.2f} ({improvement_pct:+.1f}%)")
        print("\nKey Insights:")
        
        # Compare current vs optimized thresholds
        current_config = {
            'q_buy': 0.58, 'q_sell': 0.42, 'ml_profit_peak': 0.58,
            'rsi_oversold': 35, 'rsi_overbought': 65,
            'profit_target': 0.05, 'stop_loss': 0.97
        }
        
        insights = []
        
        # Q-value insights
        if best_config['q_buy'] != current_config['q_buy']:
            if best_config['q_buy'] > current_config['q_buy']:
                insights.append(f"🔹 ENTRY CONVICTION: Raising Q-buy threshold to {best_config['q_buy']:.2f} means we'll only enter positions with stronger market conviction. This should reduce losing trades from weak signals.")
            else:
                insights.append(f"🔹 ENTRY OPPORTUNITY: Lowering Q-buy threshold to {best_config['q_buy']:.2f} means we'll capture more profitable opportunities that the current strict threshold is missing.")
        
        if best_config['q_sell'] != current_config['q_sell']:
            if best_config['q_sell'] > current_config['q_sell']:
                insights.append(f"🔹 EXIT TIMING: Raising Q-sell threshold to {best_config['q_sell']:.2f} means we'll hold positions longer when conviction is moderate, potentially capturing more upside.")
            else:
                insights.append(f"🔹 LOSS PREVENTION: Lowering Q-sell threshold to {best_config['q_sell']:.2f} means we'll exit faster when conviction weakens, cutting losses earlier.")
        
        # ML confidence insights
        if best_config['ml_profit_peak'] != current_config['ml_profit_peak']:
            if best_config['ml_profit_peak'] > current_config['ml_profit_peak']:
                insights.append(f"🔹 PROFIT TIMING: Raising ML profit peak to {best_config['ml_profit_peak']:.2f} means we'll wait for stronger profit signals before selling, potentially capturing larger gains.")
            else:
                insights.append(f"🔹 PROFIT TAKING: Lowering ML profit peak to {best_config['ml_profit_peak']:.2f} means we'll take profits earlier when ML detects peaks, securing gains before reversals.")
        
        # RSI insights
        if best_config['rsi_oversold'] != current_config['rsi_oversold']:
            if best_config['rsi_oversold'] < current_config['rsi_oversold']:
                insights.append(f"🔹 OVERSOLD ENTRY: Lowering RSI oversold to {best_config['rsi_oversold']:.0f} means we'll buy into more extreme oversold conditions, catching better bounce opportunities.")
            else:
                insights.append(f"🔹 QUALITY ENTRY: Raising RSI oversold to {best_config['rsi_oversold']:.0f} means we'll avoid extremely oversold conditions that might indicate fundamental problems.")
        
        # Risk management insights
        if best_config['profit_target'] != current_config['profit_target']:
            target_pct = best_config['profit_target'] * 100
            current_target_pct = current_config['profit_target'] * 100
            if best_config['profit_target'] > current_config['profit_target']:
                insights.append(f"🔹 PROFIT MAXIMIZATION: Raising profit target to {target_pct:.1f}% means we'll let winners run longer, capturing more upside from strong positions.")
            else:
                insights.append(f"🔹 PROFIT SECURITY: Lowering profit target to {target_pct:.1f}% means we'll lock in gains faster, reducing risk of giving back profits.")
        
        if best_config['stop_loss'] != current_config['stop_loss']:
            loss_pct = (1 - best_config['stop_loss']) * 100
            current_loss_pct = (1 - current_config['stop_loss']) * 100
            if best_config['stop_loss'] < current_config['stop_loss']:
                insights.append(f"🔹 RISK CONTROL: Tightening stop loss to {loss_pct:.1f}% means we'll cut losses faster, preserving capital for better opportunities.")
            else:
                insights.append(f"🔹 VOLATILITY TOLERANCE: Loosening stop loss to {loss_pct:.1f}% means we'll give positions more room to work, avoiding premature exits from normal volatility.")
        
        # Print insights
        for insight in insights[:6]:  # Limit to top 6 insights
            print(f"\n{insight}")
        
        # Summary recommendation
        print(f"\nSUMMARY:")
        print(f"The optimized configuration focuses on improving the balance between")
        print(f"opportunity capture and risk management. Based on your backtest data,")
        print(f"these changes should increase total P&L by ${improvement:,.2f} through")
        print(f"better entry timing, improved exit decisions, and optimized risk controls.")

if __name__ == "__main__":
    optimizer = ProfitFocusedOptimizer()
    optimizer.run_complete_optimization()