# === dual_model_trading_logic.py - UPDATED TO USE AI MOMENTUM SCALPING ===

import logging
from core.fifo_portfolio import FIFOPortfolio
from core.ai_momentum_scalping_engine import AIMomentumScalpingEngine, create_ai_momentum_scalping_engine

# Redirect to AI Momentum Scalping Engine for backward compatibility
class DualModelTradingEngine(AIMomentumScalpingEngine):
    """
    UPDATED: Now using AI-Powered Momentum Scalping Engine
    
    This maintains LAEF's AI systems (Q-Learning + ML) while adding
    momentum-based micro-scalping for ultra-fast trades.
    """
    
    def __init__(self, portfolio: FIFOPortfolio, thresholds: dict = None, custom_config: dict = None):
        # Initialize with AI momentum scalping engine
        super().__init__(portfolio, thresholds, custom_config)
        logging.info("[DUAL MODEL] Redirecting to AI Momentum Scalping Engine")

# Compatibility function
def create_dual_model_trading_engine(portfolio: FIFOPortfolio, custom_config: dict = None):
    """Create dual model trading engine (now AI momentum scalping) for compatibility"""
    return DualModelTradingEngine(portfolio, custom_config=custom_config)