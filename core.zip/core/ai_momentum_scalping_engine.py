# === ai_momentum_scalping_engine.py - AI-Powered Momentum Scalping ===

import logging
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, Tuple, Optional
from config import TRADING_THRESHOLDS
from core.fifo_portfolio import FIFOPortfolio

class AIMomentumScalpingEngine:
    """
    AI-Powered Momentum Scalping Engine
    
    Combines LAEF's AI systems with micro-scalping strategy:
    - Uses Q-Learning values for market conviction assessment
    - Uses ML confidence for optimal entry/exit timing
    - Adds momentum analysis for scalping opportunities
    - Maintains micro profit targets and fast exits
    
    Decision Logic:
    1. AI Conviction: Q-Value + ML confidence determine base signal strength
    2. Momentum Filter: Only trade when momentum confirms AI signal
    3. Volume Confirmation: Requires volume spike for entry
    4. Micro Targets: Small profits (0.1-0.5%) with tight stops
    5. Time Limits: Maximum hold time for scalping discipline
    """
    
    def __init__(self, portfolio: FIFOPortfolio, thresholds: dict = None, custom_config: dict = None):
        self.portfolio = portfolio
        self.thresholds = thresholds or self._get_default_ai_scalping_thresholds()
        
        # Apply custom config overrides if provided
        if custom_config:
            for key, value in custom_config.items():
                if key in self.thresholds:
                    self.thresholds[key] = value
        
        # AI-based thresholds (from original LAEF)
        self.Q_BUY_THRESHOLD = self.thresholds.get('q_buy', 0.30)
        self.Q_SELL_THRESHOLD = self.thresholds.get('q_sell', 0.20)
        self.ML_CONFIDENCE_THRESHOLD = self.thresholds.get('ml_profit_peak', 0.30)
        
        # Momentum scalping parameters
        self.MOMENTUM_MULTIPLIER = self.thresholds['momentum_multiplier']
        self.MICRO_PROFIT_TARGET = self.thresholds['micro_profit_target']
        self.MICRO_STOP_LOSS = self.thresholds['micro_stop_loss']
        self.MAX_HOLD_MINUTES = self.thresholds['max_hold_minutes']
        self.VOLUME_CONFIRMATION_MIN = self.thresholds['volume_confirmation_min']
        
        # AI decision tracking
        self.ai_momentum_history = {}  # symbol -> list of AI + momentum scores
        self.last_trade_time = {}      # symbol -> datetime of last trade
        
        logging.info("[AI MOMENTUM SCALPING] Engine initialized")
        logging.info(f"[AI MOMENTUM SCALPING] Q-buy: {self.Q_BUY_THRESHOLD}, ML: {self.ML_CONFIDENCE_THRESHOLD}")
        logging.info(f"[AI MOMENTUM SCALPING] Micro profit: {self.MICRO_PROFIT_TARGET:.3f}%, stop: {self.MICRO_STOP_LOSS:.3f}%")
    
    def _get_default_ai_scalping_thresholds(self) -> dict:
        """Default thresholds for AI-powered momentum scalping"""
        return {
            # AI thresholds (from LAEF)
            'q_buy': 0.25,                      # Lower threshold for scalping opportunities
            'q_sell': 0.15,                     # Quick exit threshold
            'ml_profit_peak': 0.25,             # ML confidence for profit timing
            
            # Momentum scalping parameters
            'momentum_multiplier': 1.5,         # Boost AI signal when momentum aligns
            'momentum_threshold': 1.0,          # Minimum momentum for scalping
            'momentum_acceleration_min': 0.3,   # Minimum acceleration required
            
            # Micro profit/loss targets
            'micro_profit_target': 0.12,        # 0.12% profit target (12 basis points)
            'micro_stop_loss': 0.06,            # 0.06% stop loss (6 basis points)
            'trailing_micro_stop': 0.04,        # 0.04% trailing stop
            
            # Volume and timing
            'volume_confirmation_min': 1.3,     # Minimum volume multiplier
            'volume_spike_bonus': 0.1,          # Bonus confidence for volume spikes
            'max_hold_minutes': 45,             # Maximum hold time
            'cooldown_seconds': 30,             # Shorter cooldown for AI scalping
            
            # Position sizing (optimized for frequent trading)
            'ai_scalp_position_pct': 0.025,     # 2.5% of portfolio per scalp
            'max_concurrent_scalps': 4,         # More positions due to AI confidence
            
            # Technical confirmation
            'rsi_oversold': 25,
            'rsi_overbought': 75,
        }
    
    def evaluate_trade_decision(self, symbol: str, q_value: float, ml_confidence: float,
                              indicators: dict, current_price: float, timestamp: datetime = None) -> tuple:
        """
        AI-powered momentum scalping decision function
        
        Combines:
        - Q-Learning conviction
        - ML confidence timing
        - Momentum analysis
        - Volume confirmation
        """
        try:
            timestamp = timestamp or datetime.now()
            
            # Check cooldown period
            if not self._check_cooldown(symbol, timestamp):
                return 'hold', 0.0, f"HOLD: {symbol} in cooldown period", {}
            
            # Check if we currently hold this position
            has_position = self.portfolio.has_position(symbol)
            
            if not has_position:
                return self._evaluate_ai_scalp_entry(symbol, q_value, ml_confidence, 
                                                   indicators, current_price, timestamp)
            else:
                return self._evaluate_ai_scalp_exit(symbol, q_value, ml_confidence, 
                                                  indicators, current_price, timestamp)
                
        except Exception as e:
            logging.error(f"[AI MOMENTUM SCALPING] Decision evaluation failed for {symbol}: {e}")
            return 'hold', 0.0, f"Error in AI scalping evaluation: {e}", {}
    
    def _evaluate_ai_scalp_entry(self, symbol: str, q_value: float, ml_confidence: float,
                                indicators: dict, current_price: float, timestamp: datetime) -> tuple:
        """Evaluate AI-powered scalping entry"""
        
        # Calculate momentum score
        momentum_data = self._calculate_enhanced_momentum(symbol, indicators)
        momentum_score = momentum_data['momentum_score']
        volume_confirmation = momentum_data['volume_ratio']
        acceleration = momentum_data['acceleration']
        
        # Check maximum concurrent positions
        current_positions = len([s for s in self.portfolio.positions.keys()])
        if current_positions >= self.thresholds['max_concurrent_scalps']:
            return 'hold', 0.2, f"HOLD: Max AI scalp positions ({current_positions})", {}
        
        # Check if Q-values seem untrained
        q_values_untrained = abs(q_value - 0.33) < 0.01
        
        # PRIMARY: Strong AI + Momentum Alignment
        if not q_values_untrained and q_value >= self.Q_BUY_THRESHOLD:
            # AI shows conviction - check momentum alignment
            if (momentum_score >= self.thresholds['momentum_threshold'] and 
                volume_confirmation >= self.VOLUME_CONFIRMATION_MIN and
                acceleration >= self.thresholds['momentum_acceleration_min']):
                
                # Calculate AI + Momentum confidence
                ai_base_confidence = (q_value * 0.6) + (ml_confidence * 0.4)
                momentum_boost = min(0.3, momentum_score / 10.0)  # Cap momentum boost
                volume_boost = min(0.1, (volume_confirmation - 1.0) * 0.2)
                
                total_confidence = min(0.95, ai_base_confidence + momentum_boost + volume_boost)
                
                position_data = self._calculate_ai_scalp_position(symbol, current_price)
                
                if position_data['can_buy']:
                    reason = (f"BUY: AI conviction (Q:{q_value:.3f}, ML:{ml_confidence:.3f}) + "
                             f"momentum ({momentum_score:.2f}) + volume ({volume_confirmation:.1f}x)")
                    
                    self.last_trade_time[symbol] = timestamp
                    return 'buy', total_confidence, reason, position_data
                else:
                    return 'hold', 0.3, f"HOLD: AI+momentum signal but {position_data['block_reason']}", {}
        
        # SECONDARY: ML-Based Entry (when Q-values weak but ML strong)
        elif ml_confidence >= self.ML_CONFIDENCE_THRESHOLD:
            if (momentum_score >= self.thresholds['momentum_threshold'] * 0.7 and 
                volume_confirmation >= self.VOLUME_CONFIRMATION_MIN):
                
                ml_confidence_adj = ml_confidence * 0.8  # Slightly lower confidence
                momentum_boost = min(0.2, momentum_score / 15.0)
                total_confidence = min(0.85, ml_confidence_adj + momentum_boost)
                
                position_data = self._calculate_ai_scalp_position(symbol, current_price)
                
                if position_data['can_buy']:
                    if q_values_untrained:
                        reason = f"BUY: Q-model untrained, ML signal ({ml_confidence:.3f}) + momentum ({momentum_score:.2f})"
                    else:
                        reason = f"BUY: ML timing signal ({ml_confidence:.3f}) + momentum ({momentum_score:.2f}), Q weak ({q_value:.3f})"
                    
                    self.last_trade_time[symbol] = timestamp
                    return 'buy', total_confidence, reason, position_data
                else:
                    return 'hold', 0.3, f"HOLD: ML+momentum signal but {position_data['block_reason']}", {}
        
        # TERTIARY: Pure Momentum Play (when AI signals are weak)
        elif momentum_score >= self.thresholds['momentum_threshold'] * 1.5:  # Higher threshold
            if volume_confirmation >= self.VOLUME_CONFIRMATION_MIN * 1.5:  # Require stronger volume
                position_data = self._calculate_ai_scalp_position(symbol, current_price)
                
                if position_data['can_buy']:
                    confidence = min(0.7, 0.4 + (momentum_score / 20.0))
                    reason = f"BUY: Strong momentum ({momentum_score:.2f}) + volume ({volume_confirmation:.1f}x), AI neutral"
                    
                    self.last_trade_time[symbol] = timestamp
                    return 'buy', confidence, reason, position_data
                else:
                    return 'hold', 0.3, f"HOLD: Momentum signal but {position_data['block_reason']}", {}
        
        # DEFAULT: HOLD
        reason = (f"HOLD: Insufficient signal - Q:{q_value:.3f}, ML:{ml_confidence:.3f}, "
                 f"momentum:{momentum_score:.2f}, volume:{volume_confirmation:.1f}x")
        confidence = (q_value + ml_confidence + momentum_score/10.0) / 3.0
        return 'hold', min(confidence, 0.4), reason, {}
    
    def _evaluate_ai_scalp_exit(self, symbol: str, q_value: float, ml_confidence: float,
                              indicators: dict, current_price: float, timestamp: datetime) -> tuple:
        """Evaluate AI-powered scalping exit"""
        
        # Get position details
        position_info = self.portfolio.get_position_details(symbol, current_price)
        if not position_info:
            return 'hold', 0.0, "No position found", {}
        
        current_pnl_pct = position_info['unrealized_pnl_pct']
        entry_time = self._get_position_entry_time(symbol)
        hold_time_minutes = (timestamp - entry_time).total_seconds() / 60 if entry_time else 0
        
        # Calculate current momentum and AI signals
        momentum_data = self._calculate_enhanced_momentum(symbol, indicators)
        momentum_score = momentum_data['momentum_score']
        
        # PRIMARY: Micro profit target hit
        if current_pnl_pct >= self.MICRO_PROFIT_TARGET:
            sell_data = self._calculate_sell_position(symbol, current_price, position_info)
            reason = f"SELL: Micro profit target ({current_pnl_pct:.3f}% >= {self.MICRO_PROFIT_TARGET:.3f}%)"
            return 'sell', 0.95, reason, sell_data
        
        # SECONDARY: ML signals profit peak
        if ml_confidence >= self.ML_CONFIDENCE_THRESHOLD and current_pnl_pct > 0:
            sell_data = self._calculate_sell_position(symbol, current_price, position_info)
            reason = f"SELL: ML profit peak detected ({ml_confidence:.3f}), P&L: {current_pnl_pct:.3f}%"
            return 'sell', 0.9, reason, sell_data
        
        # TERTIARY: AI conviction deteriorated
        if q_value <= self.Q_SELL_THRESHOLD:
            sell_data = self._calculate_sell_position(symbol, current_price, position_info)
            if current_pnl_pct > 0:
                reason = f"SELL: Q-value conviction lost ({q_value:.3f}), take profit {current_pnl_pct:.3f}%"
                confidence = 0.85
            else:
                reason = f"SELL: Q-value conviction lost ({q_value:.3f}), cut loss {current_pnl_pct:.3f}%"
                confidence = 0.9
            return 'sell', confidence, reason, sell_data
        
        # QUATERNARY: Momentum reversal
        if momentum_score <= -self.thresholds['momentum_threshold']:
            sell_data = self._calculate_sell_position(symbol, current_price, position_info)
            reason = f"SELL: Momentum reversal ({momentum_score:.2f}), P&L: {current_pnl_pct:.3f}%"
            return 'sell', 0.85, reason, sell_data
        
        # QUINARY: Micro stop loss
        if current_pnl_pct <= -self.MICRO_STOP_LOSS:
            sell_data = self._calculate_sell_position(symbol, current_price, position_info)
            reason = f"SELL: Micro stop loss ({current_pnl_pct:.3f}% <= -{self.MICRO_STOP_LOSS:.3f}%)"
            return 'sell', 0.95, reason, sell_data
        
        # SENARY: Time-based exit
        if hold_time_minutes >= self.MAX_HOLD_MINUTES:
            sell_data = self._calculate_sell_position(symbol, current_price, position_info)
            reason = f"SELL: Max hold time ({hold_time_minutes:.1f} >= {self.MAX_HOLD_MINUTES} min)"
            return 'sell', 0.8, reason, sell_data
        
        # TRAILING MICRO STOP (for profitable positions)
        if current_pnl_pct > 0.05:  # Only activate trailing stop after 5 basis points profit
            peak_profit = position_info.get('peak_unrealized_pct', current_pnl_pct)
            trailing_stop = self.thresholds['trailing_micro_stop']
            
            if current_pnl_pct < peak_profit - trailing_stop:
                sell_data = self._calculate_sell_position(symbol, current_price, position_info)
                reason = f"SELL: Trailing micro stop (peak: {peak_profit:.3f}% - {trailing_stop:.3f}%)"
                return 'sell', 0.85, reason, sell_data
        
        # DEFAULT: HOLD
        ai_confidence = (q_value + ml_confidence) / 2.0
        momentum_factor = max(0.1, min(0.3, momentum_score / 10.0))
        hold_confidence = min(0.8, ai_confidence + momentum_factor)
        
        reason = (f"HOLD: P&L {current_pnl_pct:.3f}%, Q:{q_value:.3f}, ML:{ml_confidence:.3f}, "
                 f"momentum:{momentum_score:.2f}, hold:{hold_time_minutes:.1f}min")
        return 'hold', hold_confidence, reason, {}
    
    def _calculate_enhanced_momentum(self, symbol: str, indicators: dict) -> dict:
        """Calculate enhanced momentum with AI weighting"""
        try:
            # Get recent price data
            recent_closes = indicators.get('recent_closes', [])
            if len(recent_closes) < 10:
                return {'momentum_score': 0.0, 'volume_ratio': 1.0, 'acceleration': 0.0}
            
            # Rate of Change (ROC)
            roc_5 = ((recent_closes[-1] / recent_closes[-5]) - 1) * 100 if len(recent_closes) >= 5 else 0
            roc_3 = ((recent_closes[-1] / recent_closes[-3]) - 1) * 100 if len(recent_closes) >= 3 else 0
            
            # Price velocity (weighted recent changes)
            velocity = 0.0
            if len(recent_closes) >= 4:
                weights = [0.4, 0.3, 0.2, 0.1]  # More weight on recent changes
                velocity_sum = 0
                for i, weight in enumerate(weights):
                    if len(recent_closes) > i + 1:
                        change = ((recent_closes[-(i+1)] - recent_closes[-(i+2)]) / recent_closes[-(i+2)]) * 100
                        velocity_sum += change * weight
                velocity = velocity_sum
            
            # Price acceleration
            acceleration = 0.0
            if len(recent_closes) >= 6:
                v1 = ((recent_closes[-3] - recent_closes[-5]) / recent_closes[-5]) * 100
                v2 = ((recent_closes[-1] - recent_closes[-3]) / recent_closes[-3]) * 100
                acceleration = v2 - v1
            
            # AI-weighted momentum score
            momentum_score = (roc_5 * 0.4) + (roc_3 * 0.3) + (velocity * 0.2) + (acceleration * 0.1)
            
            # Volume analysis
            volume_ratio = 1.0
            current_volume = indicators.get('volume', 0)
            volume_sma = indicators.get('volume_sma', 0)
            if volume_sma > 0:
                volume_ratio = current_volume / volume_sma
            
            # Update AI momentum history
            if symbol not in self.ai_momentum_history:
                self.ai_momentum_history[symbol] = []
            
            self.ai_momentum_history[symbol].append(momentum_score)
            if len(self.ai_momentum_history[symbol]) > 15:  # Keep last 15 readings
                self.ai_momentum_history[symbol] = self.ai_momentum_history[symbol][-15:]
            
            return {
                'momentum_score': momentum_score,
                'volume_ratio': volume_ratio,
                'acceleration': acceleration,
                'roc_5': roc_5,
                'roc_3': roc_3,
                'velocity': velocity
            }
            
        except Exception as e:
            logging.error(f"[AI MOMENTUM SCALPING] Enhanced momentum calculation failed for {symbol}: {e}")
            return {'momentum_score': 0.0, 'volume_ratio': 1.0, 'acceleration': 0.0}
    
    def _check_cooldown(self, symbol: str, timestamp: datetime) -> bool:
        """Check if symbol is in cooldown period"""
        if symbol not in self.last_trade_time:
            return True
        
        last_trade = self.last_trade_time[symbol]
        cooldown_seconds = self.thresholds['cooldown_seconds']
        time_since_last = (timestamp - last_trade).total_seconds()
        
        return time_since_last >= cooldown_seconds
    
    def _get_position_entry_time(self, symbol: str) -> Optional[datetime]:
        """Get the entry time of the current position"""
        if not self.portfolio.has_position(symbol):
            return None
        
        if symbol in self.portfolio.positions:
            oldest_position = self.portfolio.positions[symbol][0]
            return oldest_position.entry_time
        
        return None
    
    def _calculate_ai_scalp_position(self, symbol: str, current_price: float) -> dict:
        """Calculate AI-optimized scalp position size"""
        try:
            portfolio_value = self.portfolio.get_available_cash()
            scalp_amount = portfolio_value * self.thresholds['ai_scalp_position_pct']
            
            shares = int(scalp_amount / current_price)
            cost = shares * current_price
            
            if shares <= 0 or cost > self.portfolio.get_available_cash():
                return {
                    'can_buy': False,
                    'block_reason': f"Insufficient funds for AI scalp (need ${cost:.2f})",
                    'shares': 0,
                    'cost': 0
                }
            
            return {
                'can_buy': True,
                'shares': shares,
                'cost': cost,
                'price': current_price
            }
            
        except Exception as e:
            logging.error(f"[AI MOMENTUM SCALPING] Position size calculation failed: {e}")
            return {'can_buy': False, 'block_reason': f"Calculation error: {e}", 'shares': 0, 'cost': 0}
    
    def _calculate_sell_position(self, symbol: str, current_price: float, position_info: dict) -> dict:
        """Calculate sell position data"""
        shares_to_sell = position_info.get('total_shares', position_info.get('quantity', 0))
        proceeds = shares_to_sell * current_price
        
        return {
            'shares': shares_to_sell,
            'price': current_price,
            'proceeds': proceeds,
            'expected_pnl': position_info['unrealized_pnl']
        }


# Compatibility function
def create_ai_momentum_scalping_engine(portfolio: FIFOPortfolio, custom_config: dict = None):
    """Create AI momentum scalping engine instance"""
    return AIMomentumScalpingEngine(portfolio, custom_config=custom_config)