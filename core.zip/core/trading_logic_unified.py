# === trading_logic_unified.py - Redirect to dual model trading logic ===

# This file exists for backward compatibility
# The actual implementation is in dual_model_trading_logic.py

from core.dual_model_trading_logic import DualModelTradingEngine, create_dual_model_trading_engine

# Alias for backward compatibility
TradingDecisionEngine = DualModelTradingEngine

__all__ = ['TradingDecisionEngine', 'DualModelTradingEngine', 'create_dual_model_trading_engine']