import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from enum import Enum
import logging
from datetime import datetime, time
import asyncio
from abc import ABC, abstractmethod

# Assuming these imports exist in your codebase
# from core.dual_model_trading_logic import DualModelTradingEngine
# from core.hybrid_trading_engine import HybridTradingEngine  
# from core.momentum_scalping_engine import MomentumScalpingEngine
# from core.agent_unified import UnifiedAgent
# from core.indicators_unified import TechnicalIndicators

class StrategyType(Enum):
    MOMENTUM_SCALPING = "momentum_scalping"
    MEAN_REVERSION = "mean_reversion"
    STATISTICAL_ARBITRAGE = "statistical_arbitrage"
    AI_MOMENTUM = "ai_momentum"
    HYBRID = "hybrid"
    VOLATILITY_BREAKOUT = "volatility_breakout"

@dataclass
class StrategySignal:
    """Container for strategy signals with confidence and metadata"""
    strategy_type: StrategyType
    action: str  # 'BUY', 'SELL', 'HOLD'
    confidence: float  # 0.0 to 1.0
    expected_profit: float
    risk_score: float  # 0.0 to 1.0
    time_horizon: int  # minutes
    entry_price: float
    stop_loss: float
    take_profit: float
    ml_q_value: Optional[float] = None
    strategy_score: Optional[float] = None
    metadata: Dict[str, Any] = None

@dataclass
class MarketContext:
    """Current market conditions for strategy weighting"""
    vix_level: float
    time_of_day: datetime
    volume_profile: str  # 'high', 'medium', 'low'
    trend_direction: str  # 'bullish', 'bearish', 'sideways'
    volatility_regime: str  # 'high', 'medium', 'low'
    news_sentiment: float  # -1.0 to 1.0
    sector_performance: Dict[str, float]

class BaseStrategy(ABC):
    """Abstract base class for all trading strategies"""
    
    def __init__(self, name: str, config: Dict):
        self.name = name
        self.config = config
        self.is_enabled = config.get('enabled', True)
        
    @abstractmethod
    async def generate_signal(self, symbol: str, market_data: pd.DataFrame, 
                            market_context: MarketContext) -> Optional[StrategySignal]:
        """Generate trading signal for given symbol and market conditions"""
        pass
    
    @abstractmethod
    def get_strategy_score(self, symbol: str, market_context: MarketContext) -> float:
        """Calculate strategy suitability score for current conditions"""
        pass

class StrategyOrchestrator:
    """
    Advanced multi-strategy orchestrator that uses AI and ML to dynamically
    select and combine trading strategies based on real-time market conditions.
    """
    
    def __init__(self, config: Dict, ml_agent=None):
        self.config = config
        self.ml_agent = ml_agent
        self.strategies: Dict[StrategyType, BaseStrategy] = {}
        self.strategy_weights = config.get('strategy_weights', {})
        self.min_strategy_score = config.get('min_strategy_score', 0.6)
        self.max_concurrent_strategies = config.get('max_concurrent_strategies', 3)
        
        # Market context weights from config
        self.market_context_weights = config.get('market_context_weights', {
            'time_of_day': 0.15,
            'vix_level': 0.25,
            'volume_profile': 0.20,
            'trend_direction': 0.20,
            'volatility_regime': 0.20
        })
        
        # Strategy performance tracking
        self.strategy_performance = {}
        self.hybrid_combinations = {}
        
        self.logger = logging.getLogger(__name__)
        
    def register_strategy(self, strategy: BaseStrategy):
        """Register a strategy with the orchestrator"""
        strategy_type = StrategyType(strategy.name.lower().replace(' ', '_'))
        self.strategies[strategy_type] = strategy
        self.strategy_performance[strategy_type] = {
            'total_trades': 0,
            'winning_trades': 0,
            'total_profit': 0.0,
            'avg_confidence': 0.0,
            'recent_performance': []
        }
        
    async def analyze_market_context(self, symbol: str, market_data: pd.DataFrame) -> MarketContext:
        """Analyze current market conditions to inform strategy selection"""
        try:
            current_time = datetime.now()
            
            # Calculate VIX level (if available, otherwise use volatility proxy)
            volatility = market_data['close'].pct_change().rolling(20).std() * np.sqrt(252)
            vix_proxy = volatility.iloc[-1] * 100
            
            # Determine volume profile
            avg_volume = market_data['volume'].rolling(20).mean().iloc[-1]
            current_volume = market_data['volume'].iloc[-1]
            volume_ratio = current_volume / avg_volume
            
            if volume_ratio > 1.5:
                volume_profile = 'high'
            elif volume_ratio > 0.8:
                volume_profile = 'medium'
            else:
                volume_profile = 'low'
                
            # Determine trend direction using multiple timeframes
            short_ema = market_data['close'].ewm(span=9).mean()
            long_ema = market_data['close'].ewm(span=21).mean()
            
            if short_ema.iloc[-1] > long_ema.iloc[-1] and short_ema.iloc[-2] > long_ema.iloc[-2]:
                trend_direction = 'bullish'
            elif short_ema.iloc[-1] < long_ema.iloc[-1] and short_ema.iloc[-2] < long_ema.iloc[-2]:
                trend_direction = 'bearish'
            else:
                trend_direction = 'sideways'
                
            # Volatility regime classification
            if vix_proxy > 25:
                volatility_regime = 'high'
            elif vix_proxy > 15:
                volatility_regime = 'medium'
            else:
                volatility_regime = 'low'
                
            # Get news sentiment (placeholder - integrate with your news analysis)
            news_sentiment = await self._get_news_sentiment(symbol)
            
            return MarketContext(
                vix_level=vix_proxy,
                time_of_day=current_time,
                volume_profile=volume_profile,
                trend_direction=trend_direction,
                volatility_regime=volatility_regime,
                news_sentiment=news_sentiment,
                sector_performance={}  # Implement sector analysis
            )
            
        except Exception as e:
            self.logger.error(f"Error analyzing market context: {e}")
            return self._default_market_context()
    
    async def _get_news_sentiment(self, symbol: str) -> float:
        """Get news sentiment for symbol (integrate with your news analysis)"""
        # Placeholder - implement your news sentiment analysis
        return 0.0
    
    def _default_market_context(self) -> MarketContext:
        """Return default market context in case of analysis failure"""
        return MarketContext(
            vix_level=20.0,
            time_of_day=datetime.now(),
            volume_profile='medium',
            trend_direction='sideways',
            volatility_regime='medium',
            news_sentiment=0.0,
            sector_performance={}
        )
    
    async def evaluate_all_strategies(self, symbol: str, market_data: pd.DataFrame) -> List[StrategySignal]:
        """Evaluate all enabled strategies and return ranked signals"""
        try:
            market_context = await self.analyze_market_context(symbol, market_data)
            signals = []
            
            # Generate signals from all enabled strategies
            for strategy_type, strategy in self.strategies.items():
                if not strategy.is_enabled:
                    continue
                    
                try:
                    signal = await strategy.generate_signal(symbol, market_data, market_context)
                    if signal and signal.confidence >= self.min_strategy_score:
                        # Enhance signal with ML Q-values if available
                        if self.ml_agent:
                            signal.ml_q_value = await self._get_ml_q_value(signal, market_context)
                        
                        # Calculate context-weighted strategy score
                        signal.strategy_score = self._calculate_weighted_strategy_score(
                            signal, market_context, strategy_type
                        )
                        
                        signals.append(signal)
                        
                except Exception as e:
                    self.logger.error(f"Error generating signal for {strategy_type}: {e}")
                    continue
            
            # Rank signals by weighted score
            signals.sort(key=lambda x: x.strategy_score, reverse=True)
            
            # Consider hybrid combinations for top signals
            hybrid_signals = await self._generate_hybrid_signals(signals[:3], market_context)
            signals.extend(hybrid_signals)
            
            # Re-rank including hybrid signals
            signals.sort(key=lambda x: x.strategy_score, reverse=True)
            
            return signals[:self.max_concurrent_strategies]
            
        except Exception as e:
            self.logger.error(f"Error evaluating strategies: {e}")
            return []
    
    async def _get_ml_q_value(self, signal: StrategySignal, market_context: MarketContext) -> float:
        """Get ML Q-value for the signal using the unified agent"""
        try:
            if not self.ml_agent:
                return 0.5
                
            # Create state vector for ML agent
            state_vector = self._create_state_vector(signal, market_context)
            
            # Get Q-value from ML agent
            q_values = await self.ml_agent.predict_q_values(state_vector)
            
            # Return Q-value for the signal's action
            action_map = {'BUY': 0, 'SELL': 1, 'HOLD': 2}
            action_idx = action_map.get(signal.action, 2)
            
            return q_values[action_idx] if len(q_values) > action_idx else 0.5
            
        except Exception as e:
            self.logger.error(f"Error getting ML Q-value: {e}")
            return 0.5
    
    def _create_state_vector(self, signal: StrategySignal, market_context: MarketContext) -> np.ndarray:
        """Create state vector for ML agent"""
        # Implement state vector creation based on your ML agent's requirements
        features = [
            signal.confidence,
            signal.expected_profit,
            signal.risk_score,
            market_context.vix_level / 100.0,  # Normalize
            1.0 if market_context.trend_direction == 'bullish' else 0.0,
            1.0 if market_context.volatility_regime == 'high' else 0.0,
            market_context.news_sentiment,
            # Add more features as needed
        ]
        
        return np.array(features, dtype=np.float32)
    
    def _calculate_weighted_strategy_score(self, signal: StrategySignal, 
                                         market_context: MarketContext,
                                         strategy_type: StrategyType) -> float:
        """Calculate weighted strategy score based on market context"""
        try:
            base_score = signal.confidence
            
            # Apply time-of-day weighting
            time_weight = self._get_time_weight(strategy_type, market_context.time_of_day)
            
            # Apply VIX-based weighting
            vix_weight = self._get_vix_weight(strategy_type, market_context.vix_level)
            
            # Apply volume profile weighting
            volume_weight = self._get_volume_weight(strategy_type, market_context.volume_profile)
            
            # Apply trend direction weighting
            trend_weight = self._get_trend_weight(strategy_type, market_context.trend_direction)
            
            # Apply volatility regime weighting
            volatility_weight = self._get_volatility_weight(strategy_type, market_context.volatility_regime)
            
            # Combine weights
            context_weights = self.market_context_weights
            weighted_score = (
                base_score * 0.4 +  # Base confidence
                time_weight * context_weights['time_of_day'] +
                vix_weight * context_weights['vix_level'] +
                volume_weight * context_weights['volume_profile'] +
                trend_weight * context_weights['trend_direction'] +
                volatility_weight * context_weights['volatility_regime']
            )
            
            # Apply historical performance adjustment
            performance_multiplier = self._get_performance_multiplier(strategy_type)
            weighted_score *= performance_multiplier
            
            # Apply ML Q-value if available
            if signal.ml_q_value is not None:
                weighted_score = (weighted_score * 0.7) + (signal.ml_q_value * 0.3)
            
            return min(weighted_score, 1.0)  # Cap at 1.0
            
        except Exception as e:
            self.logger.error(f"Error calculating weighted score: {e}")
            return signal.confidence
    
    def _get_time_weight(self, strategy_type: StrategyType, current_time: datetime) -> float:
        """Get time-based weight for strategy"""
        hour = current_time.hour
        
        # Define optimal hours for each strategy type
        optimal_hours = {
            StrategyType.MOMENTUM_SCALPING: [9, 10, 15, 16],  # Market open/close
            StrategyType.MEAN_REVERSION: [11, 12, 13, 14],    # Mid-day
            StrategyType.STATISTICAL_ARBITRAGE: list(range(9, 16)),  # All trading hours
            StrategyType.AI_MOMENTUM: [9, 10, 14, 15],        # High activity periods
            StrategyType.VOLATILITY_BREAKOUT: [9, 15, 16]     # Open and close
        }
        
        if hour in optimal_hours.get(strategy_type, []):
            return 1.0
        elif 9 <= hour <= 16:  # Trading hours
            return 0.8
        else:
            return 0.3  # After hours
    
    def _get_vix_weight(self, strategy_type: StrategyType, vix_level: float) -> float:
        """Get VIX-based weight for strategy"""
        if vix_level > 30:  # High volatility
            weights = {
                StrategyType.MOMENTUM_SCALPING: 1.0,
                StrategyType.VOLATILITY_BREAKOUT: 1.0,
                StrategyType.MEAN_REVERSION: 0.3,
                StrategyType.STATISTICAL_ARBITRAGE: 0.5,
                StrategyType.AI_MOMENTUM: 0.8
            }
        elif vix_level > 20:  # Medium volatility
            weights = {
                StrategyType.MOMENTUM_SCALPING: 0.8,
                StrategyType.VOLATILITY_BREAKOUT: 0.7,
                StrategyType.MEAN_REVERSION: 0.7,
                StrategyType.STATISTICAL_ARBITRAGE: 0.9,
                StrategyType.AI_MOMENTUM: 0.8
            }
        else:  # Low volatility
            weights = {
                StrategyType.MOMENTUM_SCALPING: 0.4,
                StrategyType.VOLATILITY_BREAKOUT: 0.3,
                StrategyType.MEAN_REVERSION: 1.0,
                StrategyType.STATISTICAL_ARBITRAGE: 1.0,
                StrategyType.AI_MOMENTUM: 0.6
            }
            
        return weights.get(strategy_type, 0.7)
    
    def _get_volume_weight(self, strategy_type: StrategyType, volume_profile: str) -> float:
        """Get volume-based weight for strategy"""
        volume_weights = {
            'high': {
                StrategyType.MOMENTUM_SCALPING: 1.0,
                StrategyType.VOLATILITY_BREAKOUT: 1.0,
                StrategyType.MEAN_REVERSION: 0.6,
                StrategyType.STATISTICAL_ARBITRAGE: 0.8,
                StrategyType.AI_MOMENTUM: 0.9
            },
            'medium': {
                StrategyType.MOMENTUM_SCALPING: 0.7,
                StrategyType.VOLATILITY_BREAKOUT: 0.7,
                StrategyType.MEAN_REVERSION: 0.8,
                StrategyType.STATISTICAL_ARBITRAGE: 0.9,
                StrategyType.AI_MOMENTUM: 0.8
            },
            'low': {
                StrategyType.MOMENTUM_SCALPING: 0.3,
                StrategyType.VOLATILITY_BREAKOUT: 0.4,
                StrategyType.MEAN_REVERSION: 1.0,
                StrategyType.STATISTICAL_ARBITRAGE: 0.7,
                StrategyType.AI_MOMENTUM: 0.5
            }
        }
        
        return volume_weights.get(volume_profile, {}).get(strategy_type, 0.7)
    
    def _get_trend_weight(self, strategy_type: StrategyType, trend_direction: str) -> float:
        """Get trend-based weight for strategy"""
        trend_weights = {
            'bullish': {
                StrategyType.MOMENTUM_SCALPING: 1.0,
                StrategyType.VOLATILITY_BREAKOUT: 0.9,
                StrategyType.MEAN_REVERSION: 0.4,
                StrategyType.STATISTICAL_ARBITRAGE: 0.7,
                StrategyType.AI_MOMENTUM: 1.0
            },
            'bearish': {
                StrategyType.MOMENTUM_SCALPING: 0.6,
                StrategyType.VOLATILITY_BREAKOUT: 0.8,
                StrategyType.MEAN_REVERSION: 0.8,
                StrategyType.STATISTICAL_ARBITRAGE: 0.8,
                StrategyType.AI_MOMENTUM: 0.7
            },
            'sideways': {
                StrategyType.MOMENTUM_SCALPING: 0.3,
                StrategyType.VOLATILITY_BREAKOUT: 0.5,
                StrategyType.MEAN_REVERSION: 1.0,
                StrategyType.STATISTICAL_ARBITRAGE: 1.0,
                StrategyType.AI_MOMENTUM: 0.5
            }
        }
        
        return trend_weights.get(trend_direction, {}).get(strategy_type, 0.7)
    
    def _get_volatility_weight(self, strategy_type: StrategyType, volatility_regime: str) -> float:
        """Get volatility regime-based weight for strategy"""
        volatility_weights = {
            'high': {
                StrategyType.MOMENTUM_SCALPING: 1.0,
                StrategyType.VOLATILITY_BREAKOUT: 1.0,
                StrategyType.MEAN_REVERSION: 0.5,
                StrategyType.STATISTICAL_ARBITRAGE: 0.6,
                StrategyType.AI_MOMENTUM: 0.9
            },
            'medium': {
                StrategyType.MOMENTUM_SCALPING: 0.8,
                StrategyType.VOLATILITY_BREAKOUT: 0.7,
                StrategyType.MEAN_REVERSION: 0.8,
                StrategyType.STATISTICAL_ARBITRAGE: 0.9,
                StrategyType.AI_MOMENTUM: 0.8
            },
            'low': {
                StrategyType.MOMENTUM_SCALPING: 0.4,
                StrategyType.VOLATILITY_BREAKOUT: 0.3,
                StrategyType.MEAN_REVERSION: 1.0,
                StrategyType.STATISTICAL_ARBITRAGE: 1.0,
                StrategyType.AI_MOMENTUM: 0.6
            }
        }
        
        return volatility_weights.get(volatility_regime, {}).get(strategy_type, 0.7)
    
    def _get_performance_multiplier(self, strategy_type: StrategyType) -> float:
        """Get performance-based multiplier for strategy"""
        perf = self.strategy_performance.get(strategy_type, {})
        
        if perf.get('total_trades', 0) < 10:
            return 1.0  # Not enough data
            
        win_rate = perf.get('winning_trades', 0) / perf.get('total_trades', 1)
        avg_profit = perf.get('total_profit', 0) / perf.get('total_trades', 1)
        
        # Calculate performance multiplier (0.5 to 1.5 range)
        performance_score = (win_rate * 0.6) + (min(avg_profit / 0.02, 1.0) * 0.4)  # Normalize profit
        
        return 0.5 + (performance_score * 1.0)
    
    async def _generate_hybrid_signals(self, top_signals: List[StrategySignal], 
                                     market_context: MarketContext) -> List[StrategySignal]:
        """Generate hybrid signals by combining compatible strategies"""
        hybrid_signals = []
        
        if len(top_signals) < 2:
            return hybrid_signals
            
        # Define compatible strategy combinations
        compatible_combinations = [
            (StrategyType.MOMENTUM_SCALPING, StrategyType.AI_MOMENTUM),
            (StrategyType.MEAN_REVERSION, StrategyType.STATISTICAL_ARBITRAGE),
            (StrategyType.VOLATILITY_BREAKOUT, StrategyType.MOMENTUM_SCALPING)
        ]
        
        for i, signal1 in enumerate(top_signals):
            for j, signal2 in enumerate(top_signals[i+1:], i+1):
                combination = (signal1.strategy_type, signal2.strategy_type)
                
                if combination in compatible_combinations or combination[::-1] in compatible_combinations:
                    # Create hybrid signal
                    hybrid_signal = self._create_hybrid_signal(signal1, signal2, market_context)
                    
                    if hybrid_signal and hybrid_signal.confidence >= self.min_strategy_score:
                        hybrid_signals.append(hybrid_signal)
        
        return hybrid_signals
    
    def _create_hybrid_signal(self, signal1: StrategySignal, signal2: StrategySignal, 
                            