# === Equal Weight Strategy Configuration ===

# 1. Fix unified_trading_engine.py - Equal base weights
def _register_strategies(self):
    """Register all available strategies with EQUAL weights"""
    
    # Equal weight strategies (all get 1.0)
    strategies = [
        ('ai_momentum_scalping', 1.0),  # Equal weight ✅
        ('momentum_scalping', 1.0),     # Equal weight ✅
        ('hybrid_trading', 1.0),        # Equal weight ✅
        ('dual_model', 1.0)            # Equal weight ✅
    ]
    
    for strategy_name, weight in strategies:
        try:
            config = self.strategy_config_manager.get_strategy_config(
                strategy_name, 
                self.custom_config
            )
            
            strategy = create_strategy_adapter(strategy_name, self.portfolio, config)
            self.strategy_manager.register_strategy(strategy_name, strategy, weight)
            
            logging.info(f"[UNIFIED ENGINE] Registered {strategy_name} (equal weight: {weight})")
            
        except Exception as e:
            logging.error(f"[UNIFIED ENGINE] Failed to register {strategy_name}: {e}")

# 2. Fix strategy_orchestrator.py - Equal market context weights
class EqualWeightStrategyOrchestrator(StrategyOrchestrator):
    """Strategy orchestrator with equal weighting for all strategies"""
    
    def _get_time_weight(self, strategy_type: StrategyType, current_time: datetime) -> float:
        """Equal time-based weight for all strategies"""
        hour = current_time.hour
        
        # All strategies get equal treatment during trading hours
        if 9 <= hour <= 16:  # Trading hours
            return 1.0
        else:
            return 0.3  # All equally reduced after hours
    
    def _get_vix_weight(self, strategy_type: StrategyType, vix_level: float) -> float:
        """Equal VIX-based weight for all strategies"""
        # Instead of strategy-specific weights, use universal scaling
        if vix_level > 30:  # High volatility - all strategies get same boost
            return 0.9
        elif vix_level > 20:  # Medium volatility
            return 1.0
        else:  # Low volatility
            return 0.8
    
    def _get_volume_weight(self, strategy_type: StrategyType, volume_profile: str) -> float:
        """Equal volume-based weight for all strategies"""
        volume_multipliers = {
            'high': 1.1,    # All strategies get same boost
            'medium': 1.0,  # All strategies neutral
            'low': 0.9      # All strategies equally reduced
        }
        return volume_multipliers.get(volume_profile, 1.0)
    
    def _get_trend_weight(self, strategy_type: StrategyType, trend_direction: str) -> float:
        """Equal trend-based weight for all strategies"""
        # Equal treatment regardless of trend
        return 1.0
    
    def _get_volatility_weight(self, strategy_type: StrategyType, volatility_regime: str) -> float:
        """Equal volatility regime-based weight for all strategies"""
        volatility_multipliers = {
            'high': 1.0,    # All strategies equal
            'medium': 1.0,  # All strategies equal  
            'low': 1.0      # All strategies equal
        }
        return volatility_multipliers.get(volatility_regime, 1.0)

# 3. Configuration for equal weighting
EQUAL_WEIGHT_CONFIG = {
    'strategy_mode': 'ensemble',  # Use ensemble voting for fairness
    'strategy_weights': {
        'ai_momentum_scalping': 1.0,
        'momentum_scalping': 1.0,
        'hybrid_trading': 1.0,
        'dual_model': 1.0
    },
    'market_context_weights': {
        'time_of_day': 0.0,        # Disable time bias
        'vix_level': 0.2,          # Reduced market condition bias
        'volume_profile': 0.2,     # Reduced volume bias
        'trend_direction': 0.0,    # Disable trend bias
        'volatility_regime': 0.1   # Minimal volatility bias
    },
    'min_strategy_score': 0.4,     # Lower threshold for equal opportunity
    'max_concurrent_strategies': 4  # Allow all strategies to participate
}

# 4. Equal weight strategy selection logic
def select_strategy_equal_weight(available_strategies: List[str], 
                                market_data: Dict[str, Any]) -> Tuple[str, float, Dict[str, Any]]:
    """Select strategy with equal weighting approach"""
    
    strategy_scores = {}
    
    for strategy in available_strategies:
        # Base score from strategy performance only
        base_score = 0.5  # Neutral starting point
        
        # Add performance-based adjustment (equal opportunity)
        performance_multiplier = get_performance_multiplier(strategy)
        base_score *= performance_multiplier
        
        # Add small random factor to prevent always selecting the same strategy
        random_factor = np.random.uniform(0.95, 1.05)
        final_score = base_score * random_factor
        
        strategy_scores[strategy] = final_score
    
    # Select highest scoring strategy
    best_strategy = max(strategy_scores, key=strategy_scores.get)
    confidence = strategy_scores[best_strategy]
    
    metadata = {
        'selection_method': 'equal_weight',
        'all_scores': strategy_scores,
        'reasoning': f'Selected {best_strategy} with equal opportunity weighting'
    }
    
    return best_strategy, confidence, metadata

# 5. Ensemble voting with equal weights
def ensemble_vote_equal_weight(strategy_decisions: List[Dict]) -> Dict:
    """Ensemble voting with equal weights for all strategies"""
    
    if not strategy_decisions:
        return {'action': 'hold', 'confidence': 0.0, 'reason': 'No strategies voted'}
    
    # Equal weight for each strategy vote
    votes = {'buy': 0, 'sell': 0, 'hold': 0}
    total_confidence = 0
    
    for decision in strategy_decisions:
        action = decision['action'].lower()
        confidence = decision['confidence']
        
        # Each strategy gets exactly 1 vote, weighted by confidence
        votes[action] += confidence
        total_confidence += confidence
    
    # Determine winning action
    winning_action = max(votes, key=votes.get)
    winning_confidence = votes[winning_action] / len(strategy_decisions)
    
    # Build reasoning
    strategy_names = [d['strategy'] for d in strategy_decisions]
    reason = f"Ensemble equal-weight vote: {winning_action} from {', '.join(strategy_names)}"
    
    return {
        'action': winning_action,
        'confidence': winning_confidence,
        'reason': reason,
        'vote_breakdown': votes,
        'participating_strategies': strategy_names
    }

# 6. Usage example - How to implement equal weighting
def create_equal_weight_trading_engine(portfolio, custom_config=None):
    """Create trading engine with equal strategy weights"""
    
    # Merge with equal weight configuration
    config = EQUAL_WEIGHT_CONFIG.copy()
    if custom_config:
        config.update(custom_config)
    
    # Create engine in ensemble mode for equal treatment
    engine = UnifiedTradingEngine(portfolio, mode='ensemble', custom_config=config)
    
    # Override the strategy registration to ensure equal weights
    engine._register_strategies = lambda: register_strategies_equal_weight(engine)
    
    return engine

def register_strategies_equal_weight(engine):
    """Register strategies with guaranteed equal weights"""
    
    strategies = [
        'ai_momentum_scalping',
        'momentum_scalping', 
        'hybrid_trading',
        'dual_model'
    ]
    
    for strategy_name in strategies:
        config = engine.strategy_config_manager.get_strategy_config(
            strategy_name, 
            engine.custom_config
        )
        
        strategy = create_strategy_adapter(strategy_name, engine.portfolio, config)
        
        # Guaranteed equal weight of 1.0 for all
        engine.strategy_manager.register_strategy(strategy_name, strategy, weight=1.0)
        
        print(f"✅ Registered {strategy_name} with equal weight: 1.0")

# 7. Performance monitoring with equal opportunity
class EqualOpportunityPerformanceTracker:
    """Track performance ensuring each strategy gets equal opportunities"""
    
    def __init__(self):
        self.strategy_usage_count = {}
        self.min_usage_threshold = 10  # Minimum uses before performance weighting
    
    def should_boost_underused_strategy(self, strategy_name: str) -> float:
        """Boost strategies that haven't been used enough"""
        usage_count = self.strategy_usage_count.get(strategy_name, 0)
        
        if usage_count < self.min_usage_threshold:
            # Boost underused strategies
            boost = 1.2 - (usage_count / self.min_usage_threshold * 0.2)
            return boost
        
        return 1.0  # No boost needed
    
    def record_usage(self, strategy_name: str):
        """Record that a strategy was used"""
        self.strategy_usage_count[strategy_name] = \
            self.strategy_usage_count.get(strategy_name, 0) + 1
    
    def get_usage_stats(self) -> Dict[str, int]:
        """Get usage statistics for all strategies"""
        return self.strategy_usage_count.copy()

print("🎯 Equal Weight Strategy Configuration Ready!")
print("All strategies now have equal weight and opportunity to execute trades.")
