# === alpaca_integration.py - Modern Alpaca Integration with alpaca-py ===

# Fix for websockets.sync import error
import sys
try:
    import websockets.sync
except ImportError:
    import websockets
    import types
    # Create dummy sync module to prevent alpaca-py from failing
    websockets.sync = types.ModuleType('sync')
    sys.modules['websockets.sync'] = websockets.sync

try:
    from alpaca.trading.client import TradingClient
    from alpaca.trading.requests import MarketOrderRequest, GetOrdersRequest
    from alpaca.trading.enums import OrderSide, TimeInForce, OrderType
    from alpaca.data.historical import StockHistoricalDataClient
    from alpaca.data.requests import StockLatestTradeRequest
    ALPACA_AVAILABLE = True
except ImportError as e:
    print(f"Alpaca import error: {e}")
    ALPACA_AVAILABLE = False
    TradingClient = None

import logging
from typing import Optional, Tuple, Dict, List, Callable, Any
from config import ALPACA_API_KEY, ALPACA_SECRET_KEY
import time

class AlpacaTrader:
    """
    Modern Alpaca API integration using alpaca-py SDK.
    Supports both live and paper trading.
    """
    
    def __init__(self, paper_trading: bool = True):
        self.paper_trading = paper_trading
        self.trading_client = None
        self.data_client = None
        self._initialize_api()
        
    def _initialize_api(self):
        """Initialize Alpaca API connections."""
        if not ALPACA_AVAILABLE:
            logging.warning("[ALPACA] alpaca-py not available, trading disabled")
            return
            
        try:
            # Check if API keys are provided
            if not ALPACA_API_KEY or not ALPACA_SECRET_KEY:
                raise ValueError("Alpaca API keys not found. Please set ALPACA_API_KEY and ALPACA_SECRET_KEY in your .env file")
            
            # Initialize trading client
            self.trading_client = TradingClient(
                api_key=ALPACA_API_KEY,
                secret_key=ALPACA_SECRET_KEY,
                paper=self.paper_trading
            )
            
            # Initialize data client
            self.data_client = StockHistoricalDataClient(
                api_key=ALPACA_API_KEY,
                secret_key=ALPACA_SECRET_KEY
            )
            
            # Test connection
            account = self.trading_client.get_account()
            
            logging.info(f"[ALPACA] Connected successfully to {'PAPER' if self.paper_trading else 'LIVE'} account")
            logging.info(f"[ALPACA] Account Status: {account.status}")
            logging.info(f"[ALPACA] Buying Power: ${float(account.buying_power):,.2f}")
            logging.info(f"[ALPACA] Cash: ${float(account.cash):,.2f}")
            
            # Check if account can trade
            if account.trading_blocked:
                raise ValueError("Account is blocked from trading")
                
        except Exception as e:
            logging.error(f"[ALPACA] Failed to initialize API: {e}")
            self.trading_client = None
            self.data_client = None
            raise
    
    def is_available(self) -> bool:
        """Check if Alpaca API is available and initialized."""
        return ALPACA_AVAILABLE and self.trading_client is not None
    
    def _retry_on_connection_error(self, func: Callable, *args, max_retries: int = 3, **kwargs) -> Any:
        """Helper method to retry API calls on connection errors."""
        for attempt in range(max_retries):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                error_msg = str(e).lower()
                
                # Check for connection issues that should be retried
                if any(conn_error in error_msg for conn_error in [
                    'connection aborted', 'remote end closed connection', 
                    'connection reset', 'timeout', 'network is unreachable',
                    'read timeout', 'connection timeout'
                ]):
                    if attempt < max_retries - 1:
                        wait_time = (attempt + 1) * 2  # Exponential backoff
                        logging.warning(f"[ALPACA] Connection issue (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {wait_time}s...")
                        time.sleep(wait_time)
                        continue
                    else:
                        logging.error(f"[ALPACA] Failed after {max_retries} attempts: {e}")
                        raise e
                else:
                    # Non-connection errors should not be retried
                    raise e
        
        return None
    
    def get_account_info(self) -> Dict:
        """Get current account information with retry logic."""
        if not self.is_available():
            return {}
            
        try:
            account = self._retry_on_connection_error(self.trading_client.get_account)
            
            return {
                'cash': float(account.cash),
                'buying_power': float(account.buying_power),
                'portfolio_value': float(account.portfolio_value),
                'equity': float(account.equity),
                'status': str(account.status),
                'trading_blocked': account.trading_blocked,
                'day_trade_count': getattr(account, 'day_trade_count', 0),
                'pattern_day_trader': getattr(account, 'pattern_day_trader', False)
            }
        except Exception as e:
            logging.error(f"[ALPACA] Failed to get account info: {e}")
            return {}
    
    def get_current_price(self, symbol: str, max_retries: int = 3) -> Optional[float]:
        """Get current market price for a symbol with retry logic."""
        if not self.is_available():
            return None
        
        for attempt in range(max_retries):
            try:
                # Get latest trade
                request_params = StockLatestTradeRequest(symbol_or_symbols=[symbol])
                latest_trade = self.data_client.get_stock_latest_trade(request_params)
                
                if symbol in latest_trade:
                    return float(latest_trade[symbol].price)
                return None
                
            except Exception as e:
                error_msg = str(e).lower()
                
                # Check for connection issues that should be retried
                if any(conn_error in error_msg for conn_error in [
                    'connection aborted', 'remote end closed connection', 
                    'connection reset', 'timeout', 'network is unreachable'
                ]):
                    if attempt < max_retries - 1:
                        wait_time = (attempt + 1) * 2  # Exponential backoff: 2s, 4s, 6s
                        logging.warning(f"[ALPACA] Connection issue getting price for {symbol} (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {wait_time}s...")
                        time.sleep(wait_time)
                        continue
                    else:
                        logging.error(f"[ALPACA] Failed to get price for {symbol} after {max_retries} attempts: {e}")
                        return None
                else:
                    # Non-connection errors (invalid symbol, API limits, etc.)
                    logging.error(f"[ALPACA] Failed to get price for {symbol}: {e}")
                    return None
        
        return None
    
    def get_position(self, symbol: str) -> Optional[Dict]:
        """Get current position for a symbol."""
        if not self.is_available():
            return None
            
        try:
            position = self.trading_client.get_open_position(symbol)
            return {
                'symbol': position.symbol,
                'qty': int(position.qty),
                'side': str(position.side),
                'market_value': float(position.market_value),
                'avg_entry_price': float(position.avg_entry_price),
                'unrealized_pl': float(position.unrealized_pl),
                'unrealized_plpc': float(position.unrealized_plpc)
            }
        except Exception as e:
            # Position not found is expected for new symbols
            if "position does not exist" in str(e).lower() or "404" in str(e):
                return None
            logging.error(f"[ALPACA] Failed to get position for {symbol}: {e}")
            return None
    
    def submit_buy_order(self, symbol: str, quantity: int, order_type: str = 'market') -> Tuple[bool, str, Optional[str]]:
        """
        Submit a buy order.
        
        Returns:
            Tuple[bool, str, Optional[str]]: (success, message, order_id)
        """
        if not self.is_available():
            return False, "Alpaca API not available", None
            
        try:
            logging.info(f"[ALPACA] Submitting BUY order: {quantity} shares of {symbol}")
            
            # Create market order request
            market_order_data = MarketOrderRequest(
                symbol=symbol,
                qty=quantity,
                side=OrderSide.BUY,
                time_in_force=TimeInForce.GTC
            )
            
            # Submit order
            order = self.trading_client.submit_order(order_data=market_order_data)
            
            order_id = str(order.id)
            logging.info(f"[ALPACA] BUY order submitted successfully: {order_id}")
            
            # Wait a moment and check order status
            time.sleep(1)
            order_status = self.trading_client.get_order_by_id(order_id)
            
            if order_status.status.value == 'filled':
                filled_price = float(order_status.filled_avg_price or 0)
                message = f"BUY order filled: {quantity} shares @ ${filled_price:.2f}"
                logging.info(f"[ALPACA] {message}")
                return True, message, order_id
            elif order_status.status.value in ['new', 'accepted', 'pending_new']:
                message = f"BUY order submitted, status: {order_status.status.value}"
                logging.info(f"[ALPACA] {message}")
                return True, message, order_id
            else:
                message = f"BUY order failed with status: {order_status.status.value}"
                logging.warning(f"[ALPACA] {message}")
                return False, message, order_id
                
        except Exception as e:
            error_msg = f"Failed to submit BUY order for {symbol}: {e}"
            logging.error(f"[ALPACA] {error_msg}")
            return False, error_msg, None
    
    def submit_sell_order(self, symbol: str, quantity: int = None, order_type: str = 'market') -> Tuple[bool, str, Optional[str]]:
        """
        Submit a sell order.
        
        Args:
            symbol: Stock symbol
            quantity: Number of shares (if None, sell all)
            order_type: Order type ('market', 'limit')
            
        Returns:
            Tuple[bool, str, Optional[str]]: (success, message, order_id)
        """
        if not self.is_available():
            return False, "Alpaca API not available", None
            
        try:
            # If quantity not specified, sell entire position
            if quantity is None:
                position = self.get_position(symbol)
                if position is None:
                    return False, f"No position found for {symbol}", None
                quantity = position['qty']
            
            if quantity <= 0:
                return False, f"Invalid quantity: {quantity}", None
            
            logging.info(f"[ALPACA] Submitting SELL order: {quantity} shares of {symbol}")
            
            # Create market order request
            market_order_data = MarketOrderRequest(
                symbol=symbol,
                qty=quantity,
                side=OrderSide.SELL,
                time_in_force=TimeInForce.GTC
            )
            
            # Submit order
            order = self.trading_client.submit_order(order_data=market_order_data)
            
            order_id = str(order.id)
            logging.info(f"[ALPACA] SELL order submitted successfully: {order_id}")
            
            # Wait a moment and check order status
            time.sleep(1)
            order_status = self.trading_client.get_order_by_id(order_id)
            
            if order_status.status.value == 'filled':
                filled_price = float(order_status.filled_avg_price or 0)
                message = f"SELL order filled: {quantity} shares @ ${filled_price:.2f}"
                logging.info(f"[ALPACA] {message}")
                return True, message, order_id
            elif order_status.status.value in ['new', 'accepted', 'pending_new']:
                message = f"SELL order submitted, status: {order_status.status.value}"
                logging.info(f"[ALPACA] {message}")
                return True, message, order_id
            else:
                message = f"SELL order failed with status: {order_status.status.value}"
                logging.warning(f"[ALPACA] {message}")
                return False, message, order_id
                
        except Exception as e:
            error_msg = f"Failed to submit SELL order for {symbol}: {e}"
            logging.error(f"[ALPACA] {error_msg}")
            return False, error_msg, None
    
    def get_order_status(self, order_id: str) -> Optional[Dict]:
        """Get status of a specific order."""
        if not self.is_available():
            return None
            
        try:
            order = self.trading_client.get_order_by_id(order_id)
            return {
                'id': str(order.id),
                'symbol': order.symbol,
                'qty': int(order.qty),
                'side': str(order.side),
                'order_type': str(order.order_type),
                'status': str(order.status),
                'filled_qty': int(order.filled_qty or 0),
                'filled_avg_price': float(order.filled_avg_price or 0),
                'submitted_at': order.submitted_at,
                'filled_at': order.filled_at
            }
        except Exception as e:
            logging.error(f"[ALPACA] Failed to get order status for {order_id}: {e}")
            return None
    
    def cancel_order(self, order_id: str) -> bool:
        """Cancel a pending order."""
        if not self.is_available():
            return False
            
        try:
            self.trading_client.cancel_order_by_id(order_id)
            logging.info(f"[ALPACA] Order {order_id} cancelled successfully")
            return True
        except Exception as e:
            logging.error(f"[ALPACA] Failed to cancel order {order_id}: {e}")
            return False
    
    def get_all_positions(self) -> List[Dict]:
        """Get all current positions."""
        if not self.is_available():
            return []
            
        try:
            positions = self.trading_client.get_all_positions()
            return [
                {
                    'symbol': pos.symbol,
                    'qty': int(pos.qty),
                    'side': str(pos.side),
                    'market_value': float(pos.market_value),
                    'avg_entry_price': float(pos.avg_entry_price),
                    'unrealized_pl': float(pos.unrealized_pl),
                    'unrealized_plpc': float(pos.unrealized_plpc)
                }
                for pos in positions
            ]
        except Exception as e:
            logging.error(f"[ALPACA] Failed to get positions: {e}")
            return []
    
    def close_all_positions(self) -> bool:
        """Close all open positions."""
        if not self.is_available():
            return False
            
        try:
            self.trading_client.close_all_positions(cancel_orders=True)
            logging.info("[ALPACA] All positions closed")
            return True
        except Exception as e:
            logging.error(f"[ALPACA] Failed to close all positions: {e}")
            return False
    
    def is_market_open(self) -> bool:
        """Check if market is currently open."""
        if not self.is_available():
            return False
            
        try:
            clock = self.trading_client.get_clock()
            return clock.is_open
        except Exception as e:
            logging.error(f"[ALPACA] Failed to check market status: {e}")
            return False
    
    def get_portfolio_history(self, period: str = '1D') -> Optional[Dict]:
        """Get portfolio performance history."""
        if not self.is_available():
            return None
            
        try:
            # Note: Portfolio history may require different parameters in alpaca-py
            # This is a simplified version
            account = self.trading_client.get_account()
            return {
                'current_equity': float(account.equity),
                'current_cash': float(account.cash),
                'buying_power': float(account.buying_power),
                'portfolio_value': float(account.portfolio_value)
            }
        except Exception as e:
            logging.error(f"[ALPACA] Failed to get portfolio history: {e}")
            return None