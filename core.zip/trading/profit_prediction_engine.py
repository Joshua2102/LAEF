# === Profit-Prediction Strategy Selection Engine ===

import numpy as np
import pandas as pd
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, asdict
from collections import defaultdict
import logging
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error
import pickle
import os

@dataclass
class MarketScenario:
    """Captures the complete market scenario for pattern matching"""
    timestamp: datetime
    symbol: str
    
    # Price action
    current_price: float
    price_change_1h: float
    price_change_24h: float
    volatility_1h: float
    volatility_24h: float
    
    # Technical indicators
    rsi: float
    macd: float
    macd_signal: float
    sma_20: float
    sma_50: float
    ema_20: float
    volume_ratio: float  # current vs average
    
    # Market context
    time_of_day: int  # hour 0-23
    day_of_week: int  # 0-6
    vix_level: float
    market_trend: str  # 'bullish', 'bearish', 'sideways'
    volume_profile: str  # 'high', 'medium', 'low'
    
    # ML signals
    q_value: float
    ml_confidence: float
    
    def to_feature_vector(self) -> np.ndarray:
        """Convert to ML feature vector for prediction"""
        features = [
            self.current_price,
            self.price_change_1h,
            self.price_change_24h,
            self.volatility_1h,
            self.volatility_24h,
            self.rsi,
            self.macd,
            self.macd_signal,
            self.volume_ratio,
            self.time_of_day / 24.0,  # Normalize
            self.day_of_week / 7.0,   # Normalize
            self.vix_level / 100.0,   # Normalize
            self.q_value,
            self.ml_confidence,
            # One-hot encode categorical
            1.0 if self.market_trend == 'bullish' else 0.0,
            1.0 if self.market_trend == 'bearish' else 0.0,
            1.0 if self.volume_profile == 'high' else 0.0,
            1.0 if self.volume_profile == 'low' else 0.0,
        ]
        return np.array(features, dtype=np.float32)

@dataclass
class StrategyPrediction:
    """Prediction for a specific strategy in a scenario"""
    strategy_name: str
    scenario_id: str
    predicted_profit: float
    confidence: float
    reasoning: str
    timestamp: datetime
    
    # Actual outcome (filled later)
    actual_profit: Optional[float] = None
    prediction_error: Optional[float] = None
    was_accurate: Optional[bool] = None

class ProfitPredictionEngine:
    """
    Meta-learning engine that predicts which strategy will be most profitable
    for each market scenario, then learns from the outcomes.
    """
    
    def __init__(self, db_path: str = "strategy_learning.db"):
        self.db_path = db_path
        self.setup_database()
        
        # Strategy performance predictors (one per strategy)
        self.strategy_predictors = {}
        self.available_strategies = [
            'ai_momentum_scalping',
            'momentum_scalping', 
            'hybrid_trading',
            'dual_model'
        ]
        
        # Learning memory
        self.prediction_memory = {}  # scenario_id -> predictions
        self.pattern_library = defaultdict(list)  # pattern_type -> [scenarios]
        
        # Performance tracking
        self.strategy_success_rates = {}
        self.prediction_accuracy_history = []
        
        # Load existing models if available
        self.load_trained_models()
        
        logging.info("[PROFIT ENGINE] Initialized profit-prediction strategy selector")
    
    def setup_database(self):
        """Setup SQLite database for persistent learning"""
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        
        # Create tables for learning data
        self.conn.execute('''
        CREATE TABLE IF NOT EXISTS scenarios (
            id TEXT PRIMARY KEY,
            timestamp TEXT,
            symbol TEXT,
            scenario_data TEXT,  -- JSON blob of MarketScenario
            selected_strategy TEXT,
            predicted_profit REAL,
            actual_profit REAL,
            prediction_error REAL
        )
        ''')
        
        self.conn.execute('''
        CREATE TABLE IF NOT EXISTS strategy_predictions (
            id TEXT PRIMARY KEY,
            scenario_id TEXT,
            strategy_name TEXT,
            predicted_profit REAL,
            confidence REAL,
            actual_profit REAL,
            was_accurate BOOLEAN,
            timestamp TEXT,
            FOREIGN KEY (scenario_id) REFERENCES scenarios (id)
        )
        ''')
        
        self.conn.execute('''
        CREATE TABLE IF NOT EXISTS learning_patterns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern_type TEXT,
            conditions TEXT,  -- JSON blob
            best_strategy TEXT,
            success_rate REAL,
            avg_profit REAL,
            sample_count INTEGER,
            last_updated TEXT
        )
        ''')
        
        self.conn.commit()
    
    def create_scenario(self, symbol: str, market_data: Dict[str, Any]) -> MarketScenario:
        """Create a comprehensive market scenario for analysis"""
        try:
            current_time = datetime.now()
            
            # Extract market data
            current_price = market_data.get('current_price', 0)
            indicators = market_data.get('indicators', {})
            
            # Calculate price changes (mock if historical data not available)
            price_change_1h = market_data.get('price_change_1h', 0.0)
            price_change_24h = market_data.get('price_change_24h', 0.0)
            
            # Calculate volatilities
            volatility_1h = abs(price_change_1h) if price_change_1h else 0.01
            volatility_24h = abs(price_change_24h) if price_change_24h else 0.02
            
            # Extract technical indicators
            rsi = indicators.get('rsi', 50.0)
            macd = indicators.get('macd', 0.0)
            macd_signal = indicators.get('signal', 0.0)
            sma_20 = indicators.get('sma20', current_price)
            sma_50 = indicators.get('sma50', current_price)
            ema_20 = indicators.get('ema20', current_price)
            volume_ratio = indicators.get('volume_ratio', 1.0)
            
            # Determine market context
            market_trend = self._determine_trend(current_price, sma_20, sma_50)
            volume_profile = self._determine_volume_profile(volume_ratio)
            vix_level = market_data.get('vix_level', 20.0)  # Default VIX
            
            # ML signals
            q_value = market_data.get('q_value', 0.5)
            ml_confidence = market_data.get('ml_confidence', 0.5)
            
            return MarketScenario(
                timestamp=current_time,
                symbol=symbol,
                current_price=current_price,
                price_change_1h=price_change_1h,
                price_change_24h=price_change_24h,
                volatility_1h=volatility_1h,
                volatility_24h=volatility_24h,
                rsi=rsi,
                macd=macd,
                macd_signal=macd_signal,
                sma_20=sma_20,
                sma_50=sma_50,
                ema_20=ema_20,
                volume_ratio=volume_ratio,
                time_of_day=current_time.hour,
                day_of_week=current_time.weekday(),
                vix_level=vix_level,
                market_trend=market_trend,
                volume_profile=volume_profile,
                q_value=q_value,
                ml_confidence=ml_confidence
            )
            
        except Exception as e:
            logging.error(f"[PROFIT ENGINE] Error creating scenario: {e}")
            return self._default_scenario(symbol, market_data)
    
    def predict_strategy_profits(self, scenario: MarketScenario) -> Dict[str, StrategyPrediction]:
        """Predict expected profit for each strategy in this scenario"""
        scenario_id = f"{scenario.symbol}_{scenario.timestamp.strftime('%Y%m%d_%H%M%S')}"
        predictions = {}
        
        for strategy_name in self.available_strategies:
            try:
                # Get prediction from trained model or pattern matching
                predicted_profit = self._predict_strategy_profit(strategy_name, scenario)
                confidence = self._calculate_prediction_confidence(strategy_name, scenario)
                reasoning = self._generate_reasoning(strategy_name, scenario, predicted_profit)
                
                prediction = StrategyPrediction(
                    strategy_name=strategy_name,
                    scenario_id=scenario_id,
                    predicted_profit=predicted_profit,
                    confidence=confidence,
                    reasoning=reasoning,
                    timestamp=datetime.now()
                )
                
                predictions[strategy_name] = prediction
                
            except Exception as e:
                logging.error(f"[PROFIT ENGINE] Error predicting {strategy_name}: {e}")
                continue
        
        # Store predictions for later verification
        self.prediction_memory[scenario_id] = predictions
        
        return predictions
    
    def select_best_strategy(self, scenario: MarketScenario) -> Tuple[str, float, str]:
        """Select the strategy predicted to be most profitable"""
        
        # Get profit predictions for all strategies
        predictions = self.predict_strategy_profits(scenario)
        
        if not predictions:
            return 'ai_momentum_scalping', 0.5, "No predictions available, defaulting"
        
        # Find strategy with highest predicted profit
        best_strategy = max(predictions.keys(), key=lambda s: predictions[s].predicted_profit)
        best_prediction = predictions[best_strategy]
        
        # Calculate selection confidence based on profit spread
        profit_values = [p.predicted_profit for p in predictions.values()]
        profit_spread = max(profit_values) - min(profit_values)
        
        # Higher spread = more confident in selection
        selection_confidence = min(0.95, 0.5 + (profit_spread * 2))
        
        # Generate detailed reasoning
        reasoning = self._generate_selection_reasoning(best_strategy, predictions, scenario)
        
        logging.info(f"[PROFIT ENGINE] Selected {best_strategy} with {selection_confidence:.2f} confidence")
        logging.info(f"[PROFIT ENGINE] Expected profit: {best_prediction.predicted_profit:.4f}")
        
        return best_strategy, selection_confidence, reasoning
    
    def _predict_strategy_profit(self, strategy_name: str, scenario: MarketScenario) -> float:
        """Predict profit for a specific strategy using learned patterns"""
        
        # Try ML model first if trained
        if strategy_name in self.strategy_predictors:
            try:
                feature_vector = scenario.to_feature_vector().reshape(1, -1)
                predicted_profit = self.strategy_predictors[strategy_name].predict(feature_vector)[0]
                return float(predicted_profit)
            except Exception as e:
                logging.debug(f"ML prediction failed for {strategy_name}: {e}")
        
        # Fallback to pattern matching
        return self._pattern_based_prediction(strategy_name, scenario)
    
    def _pattern_based_prediction(self, strategy_name: str, scenario: MarketScenario) -> float:
        """Use historical patterns to predict profit"""
        
        # Find similar historical scenarios
        similar_scenarios = self._find_similar_scenarios(scenario, limit=10)
        
        if not similar_scenarios:
            # No history, use strategy-specific baseline
            baselines = {
                'ai_momentum_scalping': 0.0012,  # 0.12% typical
                'momentum_scalping': 0.0015,     # 0.15% typical
                'hybrid_trading': 0.008,         # 0.8% typical  
                'dual_model': 0.005              # 0.5% typical
            }
            return baselines.get(strategy_name, 0.003)
        
        # Calculate weighted average based on scenario similarity
        total_weight = 0
        weighted_profit = 0
        
        for similar_scenario, similarity_score in similar_scenarios:
            if strategy_name in similar_scenario.get('strategy_results', {}):
                profit = similar_scenario['strategy_results'][strategy_name]['profit']
                weight = similarity_score
                
                weighted_profit += profit * weight
                total_weight += weight
        
        if total_weight > 0:
            return weighted_profit / total_weight
        else:
            return 0.003  # Default modest expectation
    
    def _calculate_prediction_confidence(self, strategy_name: str, scenario: MarketScenario) -> float:
        """Calculate confidence in the profit prediction"""
        
        # Base confidence from model training (if available)
        base_confidence = 0.5
        
        # Boost confidence if we have good historical data
        similar_count = len(self._find_similar_scenarios(scenario, limit=5))
        history_boost = min(0.3, similar_count * 0.1)
        
        # Boost confidence based on strategy's recent success rate
        success_rate = self.strategy_success_rates.get(strategy_name, {}).get('accuracy', 0.5)
        success_boost = (success_rate - 0.5) * 0.4  # Can be negative
        
        # Market clarity boost (strong signals = higher confidence)
        signal_strength = abs(scenario.q_value - 0.5) + abs(scenario.ml_confidence - 0.5)
        clarity_boost = signal_strength * 0.2
        
        final_confidence = base_confidence + history_boost + success_boost + clarity_boost
        return max(0.1, min(0.95, final_confidence))
    
    def record_actual_outcome(self, scenario_id: str, strategy_used: str, actual_profit: float):
        """Record the actual outcome to learn from prediction accuracy"""
        
        if scenario_id not in self.prediction_memory:
            logging.warning(f"[PROFIT ENGINE] No predictions found for scenario {scenario_id}")
            return
        
        predictions = self.prediction_memory[scenario_id]
        
        # Update the prediction that was actually used
        if strategy_used in predictions:
            prediction = predictions[strategy_used]
            prediction.actual_profit = actual_profit
            prediction.prediction_error = abs(actual_profit - prediction.predicted_profit)
            prediction.was_accurate = abs(prediction.prediction_error) < 0.001  # Within 0.1%
            
            # Store in database for persistent learning
            self._store_outcome_in_db(scenario_id, prediction)
            
            # Update success rates
            self._update_success_rates(strategy_used, prediction.was_accurate, prediction.prediction_error)
            
            # Retrain models if enough new data
            self._retrain_if_needed()
            
            logging.info(f"[PROFIT ENGINE] Recorded outcome: {strategy_used} "
                        f"predicted {prediction.predicted_profit:.4f}, "
                        f"actual {actual_profit:.4f}, "
                        f"error {prediction.prediction_error:.4f}")
    
    def _store_outcome_in_db(self, scenario_id: str, prediction: StrategyPrediction):
        """Store learning data in database"""
        try:
            self.conn.execute('''
            INSERT OR REPLACE INTO strategy_predictions 
            (id, scenario_id, strategy_name, predicted_profit, confidence, 
             actual_profit, was_accurate, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                f"{scenario_id}_{prediction.strategy_name}",
                scenario_id,
                prediction.strategy_name,
                prediction.predicted_profit,
                prediction.confidence,
                prediction.actual_profit,
                prediction.was_accurate,
                prediction.timestamp.isoformat()
            ))
            self.conn.commit()
            
        except Exception as e:
            logging.error(f"[PROFIT ENGINE] Error storing outcome: {e}")
    
    def _update_success_rates(self, strategy_name: str, was_accurate: bool, error: float):
        """Update running success rates for strategy predictions"""
        
        if strategy_name not in self.strategy_success_rates:
            self.strategy_success_rates[strategy_name] = {
                'total_predictions': 0,
                'accurate_predictions': 0,
                'accuracy': 0.0,
                'avg_error': 0.0,
                'error_sum': 0.0
            }
        
        stats = self.strategy_success_rates[strategy_name]
        stats['total_predictions'] += 1
        stats['error_sum'] += error
        stats['avg_error'] = stats['error_sum'] / stats['total_predictions']
        
        if was_accurate:
            stats['accurate_predictions'] += 1
        
        stats['accuracy'] = stats['accurate_predictions'] / stats['total_predictions']
    
    def _retrain_if_needed(self):
        """Retrain prediction models if we have enough new data"""
        
        # Check if we have enough new data (retrain every 50 outcomes)
        total_outcomes = sum(stats['total_predictions'] 
                           for stats in self.strategy_success_rates.values())
        
        if total_outcomes % 50 == 0 and total_outcomes > 100:
            logging.info("[PROFIT ENGINE] Retraining models with new data...")
            self._train_prediction_models()
    
    def _train_prediction_models(self):
        """Train ML models to predict strategy profits"""
        
        try:
            # Load training data from database
            training_data = self._load_training_data()
            
            if len(training_data) < 20:
                logging.info("[PROFIT ENGINE] Not enough data for training yet")
                return
            
            for strategy_name in self.available_strategies:
                strategy_data = [row for row in training_data if row['strategy_name'] == strategy_name]
                
                if len(strategy_data) < 10:
                    continue  # Need at least 10 samples
                
                # Prepare training data
                X = np.array([row['features'] for row in strategy_data])
                y = np.array([row['actual_profit'] for row in strategy_data])
                
                # Train Random Forest model
                model = RandomForestRegressor(
                    n_estimators=50,
                    max_depth=10,
                    random_state=42
                )
                
                model.fit(X, y)
                
                # Test accuracy
                y_pred = model.predict(X)
                mae = mean_absolute_error(y, y_pred)
                
                # Store model if accuracy is reasonable
                if mae < 0.01:  # Error less than 1%
                    self.strategy_predictors[strategy_name] = model
                    self._save_model(strategy_name, model)
                    
                    logging.info(f"[PROFIT ENGINE] Trained {strategy_name} model (MAE: {mae:.4f})")
                
        except Exception as e:
            logging.error(f"[PROFIT ENGINE] Error training models: {e}")
    
    def _load_training_data(self) -> List[Dict]:
        """Load training data from database"""
        cursor = self.conn.execute('''
        SELECT sp.*, s.scenario_data 
        FROM strategy_predictions sp
        JOIN scenarios s ON sp.scenario_id = s.id
        WHERE sp.actual_profit IS NOT NULL
        ORDER BY sp.timestamp DESC
        LIMIT 1000
        ''')
        
        training_data = []
        for row in cursor.fetchall():
            scenario_data = json.loads(row[8])  # scenario_data column
            scenario = MarketScenario(**scenario_data)
            
            training_data.append({
                'strategy_name': row[2],
                'features': scenario.to_feature_vector(),
                'predicted_profit': row[3],
                'actual_profit': row[5],
                'was_accurate': row[6]
            })
        
        return training_data
    
    def _save_model(self, strategy_name: str, model):
        """Save trained model to disk"""
        model_dir = "models"
        os.makedirs(model_dir, exist_ok=True)
        
        model_path = f"{model_dir}/{strategy_name}_profit_predictor.pkl"
        with open(model_path, 'wb') as f:
            pickle.dump(model, f)
    
    def load_trained_models(self):
        """Load previously trained models"""
        model_dir = "models"
        if not os.path.exists(model_dir):
            return
        
        for strategy_name in self.available_strategies:
            model_path = f"{model_dir}/{strategy_name}_profit_predictor.pkl"
            
            if os.path.exists(model_path):
                try:
                    with open(model_path, 'rb') as f:
                        model = pickle.load(f)
                    
                    self.strategy_predictors[strategy_name] = model
                    logging.info(f"[PROFIT ENGINE] Loaded trained model for {strategy_name}")
                    
                except Exception as e:
                    logging.error(f"[PROFIT ENGINE] Error loading model for {strategy_name}: {e}")
    
    def get_learning_stats(self) -> Dict[str, Any]:
        """Get comprehensive learning statistics"""
        return {
            'strategy_success_rates': self.strategy_success_rates,
            'trained_models': list(self.strategy_predictors.keys()),
            'total_scenarios_remembered': len(self.prediction_memory),
            'database_records': self._count_db_records(),
            'pattern_library_size': {k: len(v) for k, v in self.pattern_library.items()}
        }
    
    def _count_db_records(self) -> Dict[str, int]:
        """Count records in database"""
        cursor = self.conn.execute('SELECT COUNT(*) FROM scenarios')
        scenarios_count = cursor.fetchone()[0]
        
        cursor = self.conn.execute('SELECT COUNT(*) FROM strategy_predictions')
        predictions_count = cursor.fetchone()[0]
        
        return {
            'scenarios': scenarios_count,
            'predictions': predictions_count
        }
    
    # Helper methods for market analysis
    def _determine_trend(self, price: float, sma20: float, sma50: float) -> str:
        """Determine market trend"""
        if price > sma20 > sma50:
            return 'bullish'
        elif price < sma20 < sma50:
            return 'bearish'
        else:
            return 'sideways'
    
    def _determine_volume_profile(self, volume_ratio: float) -> str:
        """Determine volume profile"""
        if volume_ratio > 1.5:
            return 'high'
        elif volume_ratio > 0.8:
            return 'medium'
        else:
            return 'low'
    
    def _find_similar_scenarios(self, scenario: MarketScenario, limit: int = 10) -> List[Tuple[Dict, float]]:
        """Find historically similar scenarios"""
        # Simplified similarity matching - in production you'd use more sophisticated methods
        # This is a placeholder that would query the database for similar conditions
        return []
    
    def _default_scenario(self, symbol: str, market_data: Dict) -> MarketScenario:
        """Create default scenario if analysis fails"""
        return MarketScenario(
            timestamp=datetime.now(),
            symbol=symbol,
            current_price=market_data.get('current_price', 100),
            price_change_1h=0.0,
            price_change_24h=0.0,
            volatility_1h=0.01,
            volatility_24h=0.02,
            rsi=50.0,
            macd=0.0,
            macd_signal=0.0,
            sma_20=100.0,
            sma_50=100.0,
            ema_20=100.0,
            volume_ratio=1.0,
            time_of_day=12,
            day_of_week=2,
            vix_level=20.0,
            market_trend='sideways',
            volume_profile='medium',
            q_value=0.5,
            ml_confidence=0.5
        )
    
    def _generate_reasoning(self, strategy_name: str, scenario: MarketScenario, predicted_profit: float) -> str:
        """Generate human-readable reasoning for prediction"""
        reasons = []
        
        reasons.append(f"Predicted profit: {predicted_profit:.4f} ({predicted_profit*100:.2f}%)")
        
        # Add market context
        reasons.append(f"Market: {scenario.market_trend} trend, {scenario.volume_profile} volume")
        reasons.append(f"RSI: {scenario.rsi:.1f}, MACD: {scenario.macd:.3f}")
        reasons.append(f"Time: {scenario.time_of_day:02d}:00 on weekday {scenario.day_of_week}")
        
        # Add strategy-specific reasoning
        if 'momentum' in strategy_name.lower():
            if abs(scenario.price_change_1h) > 0.01:
                reasons.append("Strong price momentum detected")
            if scenario.volume_ratio > 1.2:
                reasons.append("Volume confirmation present")
        
        return " | ".join(reasons)
    
    def _generate_selection_reasoning(self, best_strategy: str, predictions: Dict, scenario: MarketScenario) -> str:
        """Generate reasoning for strategy selection"""
        best_pred = predictions[best_strategy]
        
        reason_parts = [
            f"Selected {best_strategy} for highest expected profit: {best_pred.predicted_profit:.4f}",
            f"Market conditions: {scenario.market_trend} trend, {scenario.volume_profile} volume, RSI {scenario.rsi:.1f}",
        ]
        
        # Compare with other strategies
        other_profits = [p.predicted_profit for k, p in predictions.items() if k != best_strategy]
        if other_profits:
            avg_other = np.mean(other_profits)
            advantage = best_pred.predicted_profit - avg_other
            reason_parts.append(f"Advantage over alternatives: +{advantage:.4f}")
        
        return " | ".join(reason_parts)

# Integration with existing trading system
class ProfitPredictionTradingEngine:
    """Integration wrapper for the existing trading system"""
    
    def __init__(self, portfolio, custom_config=None):
        self.portfolio = portfolio
        self.config = custom_config or {}
        
        # Initialize the profit prediction engine
        self.profit_engine = ProfitPredictionEngine()
        
        # Initialize individual strategy engines
        from core.ai_momentum_scalping_engine import AIMomentumScalpingEngine
        from core.momentum_scalping_engine import MomentumScalpingEngine
        from core.hybrid_trading_engine import HybridTradingEngine
        from core.dual_model_trading_logic import DualModelTradingEngine
        
        self.strategy_engines = {
            'ai_momentum_scalping': AIMomentumScalpingEngine(portfolio, custom_config),
            'momentum_scalping': MomentumScalpingEngine(portfolio, custom_config),
            'hybrid_trading': HybridTradingEngine(portfolio, custom_config),
            'dual_model': DualModelTradingEngine(portfolio, custom_config)
        }
        
        # Track active trades for outcome recording
        self.active_trades = {}  # scenario_id -> trade_info
        
        logging.info("[PROFIT TRADING ENGINE] Initialized with profit-prediction strategy selection")
    
    def evaluate_trade_decision(self, symbol: str, q_value: float, ml_confidence: float,
                              indicators: Dict[str, Any], current_price: float,
                              timestamp: datetime = None) -> Tuple[str, float, str, Dict[str, Any]]:
        """Main trading decision using profit prediction"""
        
        # Create market scenario
        market_data = {
            'current_price': current_price,
            'indicators': indicators,
            'q_value': q_value,
            'ml_confidence': ml_confidence,
            'timestamp': timestamp or datetime.now()
        }
        
        scenario = self.profit_engine.create_scenario(symbol, market_data)
        
        # Get the most profitable strategy prediction
        best_strategy, selection_confidence, reasoning = self.profit_engine.select_best_strategy(scenario)
        
        # Execute the selected strategy
        strategy_engine = self.strategy_engines[best_strategy]
        action, confidence, strategy_reason, action_data = strategy_engine.evaluate_trade_decision(
            symbol, q_value, ml_confidence, indicators, current_price, timestamp
        )
        
        # Enhanced reasoning combining prediction and strategy logic
        full_reasoning = f"PROFIT-PREDICTED: {reasoning} | STRATEGY: {strategy_reason}"
        
        # Store trade info for later outcome recording
        scenario_id = f"{scenario.symbol}_{scenario.timestamp.strftime('%Y%m%d_%H%M%S')}"
        
        if action in ['buy', 'sell']:
            self.active_trades[scenario_id] = {
                'strategy': best_strategy,
                'action': action,
                'price': current_price,
                'timestamp': timestamp or datetime.now(),
                'predicted_profit': self.profit_engine.prediction_memory[scenario_id][best_strategy].predicted_profit
            }
        
        # Add profit prediction metadata
        action_data['selected_strategy'] = best_strategy
        action_data['selection_confidence'] = selection_confidence
        action_data['predicted_profit'] = self.profit_engine.prediction_memory[scenario_id][best_strategy].predicted_profit
        
        return action, confidence, full_reasoning, action_data
    
    def record_trade_outcome(self, symbol: str, entry_price: float, exit_price: float, 
                           quantity: int, entry_time: datetime):
        """Record actual trade outcome for learning"""
        
        # Find matching scenario
        scenario_id = None
        for sid, trade_info in self.active_trades.items():
            if (symbol in sid and 
                abs((trade_info['timestamp'] - entry_time).total_seconds()) < 300):  # Within 5 minutes
                scenario_id = sid
                break
        
        if not scenario_id:
            logging.warning(f"[PROFIT ENGINE] Could not find matching scenario for {symbol} trade")
            return
        
        # Calculate actual profit
        if self.active_trades[scenario_id]['action'] == 'buy':
            actual_profit = (exit_price - entry_price) / entry_price
        else:  # sell
            actual_profit = (entry_price - exit_price) / entry_price
        
        # Record in profit engine for learning
        strategy_used = self.active_trades[scenario_id]['strategy']
        self.profit_engine.record_actual_outcome(scenario_id, strategy_used, actual_profit)
        
        # Clean up
        del self.active_trades[scenario_id]
        
        logging.info(f"[PROFIT ENGINE] Recorded {symbol} outcome: {actual_profit:.4f} profit using {strategy_used}")

print("🧠 Profit-Prediction Strategy Selection Engine Ready!")
print("The bot will now learn which strategy is most profitable for each market scenario.")
