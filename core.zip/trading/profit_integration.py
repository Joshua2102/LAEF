# === Integration with Existing LAEF System ===

# Replace your current trading engine with this:

def create_profit_prediction_trading_system(portfolio, custom_config=None):
    """Create the profit-prediction trading system"""
    
    # This replaces the old unified trading engine
    return ProfitPredictionTradingEngine(portfolio, custom_config)

# Example usage in live trading:
class LAEFLiveTraderWithProfitPrediction(LAEFLiveTrader):
    """Enhanced live trader with profit prediction"""
    
    def __init__(self, paper_trading: bool = True):
        super().__init__(paper_trading)
        
        # Replace the trading engine with profit prediction engine
        self.trading_engine = ProfitPredictionTradingEngine(self.portfolio)
        
        print("🧠 LAEF Live Trader with Profit Prediction Engine activated!")
        print("The bot will now predict which strategy will be most profitable for each scenario.")
    
    def _process_symbol_live(self, symbol: str) -> bool:
        """Enhanced symbol processing with profit prediction"""
        
        try:
            # Get market data (same as before)
            df = fetch_stock_data(symbol, interval="5m", period="2d")
            if df is None or len(df) < 50:
                return False
            
            # Extract current market info
            current_price = df['close'].iloc[-1]
            indicators = extract_raw_indicators(df.tail(50))
            q_value = self.agent.predict_q_value(create_state_vector(df.tail(50)))
            ml_confidence = abs(q_value - 0.5) * 2.0
            
            # THE MAGIC HAPPENS HERE:
            # Instead of using one strategy, predict which will be most profitable
            action, confidence, reasoning, action_data = self.trading_engine.evaluate_trade_decision(
                symbol=symbol,
                q_value=q_value,
                ml_confidence=ml_confidence,
                indicators=indicators,
                current_price=current_price,
                timestamp=datetime.now()
            )
            
            # Log the profit prediction decision
            selected_strategy = action_data.get('selected_strategy', 'unknown')
            predicted_profit = action_data.get('predicted_profit', 0)
            
            print(f"🧠 {symbol}: Selected {selected_strategy} (predicted profit: {predicted_profit:.4f})")
            print(f"🎯 Decision: {action.upper()} | Confidence: {confidence:.2f}")
            print(f"💭 Reasoning: {reasoning}")
            
            # Execute the trade (same as before)
            action_taken = False
            if action == 'buy' and action_data:
                action_taken = self._execute_buy(symbol, current_price, action_data, datetime.now())
            elif action == 'sell' and action_data:
                action_taken = self._execute_sell(symbol, current_price, action_data, datetime.now())
            
            return action_taken
            
        except Exception as e:
            logging.error(f"[PROFIT LIVE] Failed to process {symbol}: {e}")
            return False

# Example backtesting with profit prediction:
class LAEFBacktesterWithProfitPrediction(LAEFBacktester):
    """Enhanced backtester that learns from every prediction"""
    
    def __init__(self, initial_cash=100000, custom_config=None):
        super().__init__(initial_cash, custom_config)
        
        # Replace with profit prediction engine
        self.profit_engine = ProfitPredictionTradingEngine(self.portfolio, custom_config)
        
        print("🧠 LAEF Backtester with Profit Prediction activated!")
        print("The bot will learn which strategy works best in each market scenario.")
    
    def simulate_ai_trading(self, df, symbol):
        """Enhanced simulation that learns from every prediction"""
        
        trades = []
        decisions = []
        learning_events = []
        
        for i in range(50, len(df)):
            current_data = df.iloc[:i+1]
            current_price = current_data['close'].iloc[-1]
            timestamp = current_data.index[-1]
            
            # Get market indicators
            indicators = get_latest_indicators(current_data)
            q_value, ml_confidence = self._get_real_ai_signals(current_data, indicators)
            
            # PROFIT PREDICTION DECISION
            action, confidence, reasoning, action_data = self.profit_engine.evaluate_trade_decision(
                symbol, q_value, ml_confidence, indicators, current_price, timestamp
            )
            
            # Record the decision with prediction info
            selected_strategy = action_data.get('selected_strategy', 'unknown')
            predicted_profit = action_data.get('predicted_profit', 0)
            
            decisions.append({
                'date': timestamp,
                'symbol': symbol,
                'decision': action,
                'confidence': confidence,
                'selected_strategy': selected_strategy,
                'predicted_profit': predicted_profit,
                'reasoning': reasoning,
                'q_value': q_value,
                'ml_confidence': ml_confidence,
                'price': current_price
            })
            
            # Execute trades and track outcomes
            if action == 'buy' and action_data.get('can_buy', False):
                # Execute buy
                shares = action_data['shares']
                success = self.portfolio.buy(symbol, current_price, shares, timestamp)
                
                if success:
                    trades.append({
                        'date': timestamp,
                        'action': 'BUY',
                        'strategy': selected_strategy,
                        'predicted_profit': predicted_profit,
                        'price': current_price,
                        'quantity': shares
                    })
            
            elif action == 'sell' and self.portfolio.has_position(symbol):
                # Execute sell and learn from the outcome
                shares = action_data.get('shares', 0)
                success, realized_pnl, sell_reason = self.portfolio.sell(symbol, current_price, shares, timestamp=timestamp)
                
                if success:
                    # Calculate actual profit percentage
                    entry_price = self.portfolio.get_average_cost_basis(symbol) if hasattr(self.portfolio, 'get_average_cost_basis') else current_price
                    actual_profit_pct = (current_price - entry_price) / entry_price if entry_price > 0 else 0
                    
                    trades.append({
                        'date': timestamp,
                        'action': 'SELL',
                        'strategy': selected_strategy,
                        'predicted_profit': predicted_profit,
                        'actual_profit': actual_profit_pct,
                        'price': current_price,
                        'quantity': shares,
                        'pnl': realized_pnl
                    })
                    
                    # THE LEARNING HAPPENS HERE:
                    # Record the actual outcome vs prediction for learning
                    self.profit_engine.record_trade_outcome(
                        symbol=symbol,
                        entry_price=entry_price,
                        exit_price=current_price,
                        quantity=shares,
                        entry_time=timestamp
                    )
                    
                    # Track learning event
                    prediction_error = abs(actual_profit_pct - predicted_profit)
                    learning_events.append({
                        'timestamp': timestamp,
                        'strategy': selected_strategy,
                        'predicted_profit': predicted_profit,
                        'actual_profit': actual_profit_pct,
                        'error': prediction_error,
                        'was_accurate': prediction_error < 0.001  # Within 0.1%
                    })
                    
                    print(f"📊 LEARNING: {selected_strategy} predicted {predicted_profit:.4f}, "
                          f"actual {actual_profit_pct:.4f}, error {prediction_error:.4f}")
        
        # Return enhanced results with learning data
        final_price = df['close'].iloc[-1]
        final_value = self.portfolio.get_total_portfolio_value({symbol: final_price})
        
        return {
            'final_value': final_value,
            'trades': trades,
            'decisions': decisions,
            'learning_events': learning_events,
            'learning_stats': self.profit_engine.profit_engine.get_learning_stats(),
            'cash': self.portfolio.get_available_cash(),
            'positions': self.portfolio.get_position_quantity(symbol)
        }

# Show learning progress:
def show_learning_progress(profit_engine: ProfitPredictionEngine):
    """Display how well the bot is learning"""
    
    stats = profit_engine.get_learning_stats()
    
    print("\n🧠 BOT LEARNING PROGRESS")
    print("=" * 50)
    
    print("Strategy Prediction Accuracy:")
    for strategy, rates in stats['strategy_success_rates'].items():
        accuracy = rates['accuracy'] * 100
        avg_error = rates['avg_error'] * 100
        total = rates['total_predictions']
        
        print(f"  {strategy}: {accuracy:.1f}% accurate "
              f"({total} predictions, avg error {avg_error:.2f}%)")
    
    print(f"\nTrained Models: {len(stats['trained_models'])}")
    for model in stats['trained_models']:
        print(f"  ✅ {model}")
    
    print(f"\nMemory: {stats['total_scenarios_remembered']} scenarios remembered")
    print(f"Database: {stats['database_records']['scenarios']} scenarios, "
          f"{stats['database_records']['predictions']} predictions stored")
    
    print("\n🎯 The bot gets smarter with every trade!")

# Example of running with profit prediction:
if __name__ == "__main__":
    print("🚀 Starting LAEF with Profit Prediction Engine")
    
    # For backtesting:
    backtester = LAEFBacktesterWithProfitPrediction(initial_cash=100000)
    results = backtester.run_backtest(['AAPL', 'TSLA', 'MSFT'], days=90)
    
    # Show learning progress
    show_learning_progress(backtester.profit_engine.profit_engine)
    
    # For live trading:
    # trader = LAEFLiveTraderWithProfitPrediction(paper_trading=True)
    # trader.start_trading()

print("\n🧠 PROFIT PREDICTION SYSTEM READY!")
print("The bot will now:")
print("  1. Predict which strategy will be most profitable")
print("  2. Execute trades with the best strategy")
print("  3. Learn from every outcome")
print("  4. Get smarter over time")
print("  5. Build a knowledge base of what works when")
