#!/usr/bin/env python3
"""
Fixed LAEF Backtester - Replaces broken backtester_unified.py
Uses working backtesting code from laef_unified_system.py
"""

import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from dotenv import load_dotenv
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest
from alpaca.data.timeframe import TimeFrame
from core.ai_momentum_scalping_engine import AIMomentumScalpingEngine
from core.laef_ai_trading_engine import LAEFAITradingEngine
from core.fifo_portfolio import FIFOPortfolio
from core.indicators_unified import calculate_all_indicators, get_latest_indicators
from core.agent_unified import LAEFAgent
from config import STATE_FEATURES
import numpy as np
import warnings
warnings.filterwarnings('ignore')

# Load environment variables
load_dotenv()

class LAEFBacktester:
    """Fixed backtester using working Alpaca integration"""
    
    def __init__(self, initial_cash=100000, custom_config=None, strategy='laef_ai'):
        self.api_key = os.getenv('ALPACA_API_KEY')
        self.secret_key = os.getenv('ALPACA_SECRET_KEY')
        
        if not self.api_key or not self.secret_key:
            raise ValueError("Alpaca API credentials not found")
        
        self.data_client = StockHistoricalDataClient(self.api_key, self.secret_key)
        self.initial_cash = initial_cash
        self.strategy = strategy
        
        # Initialize portfolio
        self.portfolio = FIFOPortfolio(initial_cash)
        
        # Initialize the appropriate trading engine based on strategy
        if strategy == 'laef_ai':
            # Pure LAEF AI with dynamic parameters
            self.config = custom_config or {}
            self.trading_engine = LAEFAITradingEngine(self.portfolio, custom_config=self.config)
            print("\nStrategy: LAEF AI/ML Multi-Strategy")
            print("Mode: Pure Dynamic - All parameters determined by neural network")
            print("No fixed thresholds or static parameters")
        elif strategy == 'ai_momentum_scalping':
            # AI Momentum Scalping with constrained parameters
            self.config = self._get_scalping_constrained_config(custom_config, initial_cash)
            self.trading_engine = AIMomentumScalpingEngine(self.portfolio, custom_config=self.config)
            print("\nStrategy: AI Momentum Scalping")
            print("Mode: Fixed micro-scalping with constrained parameters")
            print("Loading trading parameters...")
            print(f"Conservative mode: {self.config.get('risk_per_trade', 0.025):.1%} risk per trade")
            print(f"Profit target: {self.config.get('profit_target', 0.001)*100:.1%}")
            print(f"Stop loss: {self.config.get('stop_loss', 0.0006)*100:.1%}")
        else:
            # Default to LAEF AI
            self.config = custom_config or {}
            self.trading_engine = LAEFAITradingEngine(self.portfolio, custom_config=self.config)
            print(f"\nStrategy: Unknown '{strategy}', defaulting to LAEF AI")
            print("Mode: Pure Dynamic - All parameters determined by neural network")
        
        # Slippage configuration (basis points)
        self.slippage_bps = self.config.get('slippage_bps', 5)  # 5 basis points default
        self.use_slippage = self.config.get('use_slippage', True)
        
        # Initialize LAEF Agent for real Q-values and ML predictions
        try:
            self.laef_agent = LAEFAgent(pretrained=True)
            print("LAEF Agent loaded successfully - using real trained models")
        except Exception as e:
            print(f"Warning: Could not load LAEF Agent: {e}")
            print("Falling back to technical analysis-based signals")
            self.laef_agent = None
        
        # Fix stop loss format if needed
        if self.config.get('stop_loss_pct', 0) > 0.5:
            # Convert from percentage format (0.96) to loss format (0.04)
            self.config['stop_loss'] = 1.0 - self.config['stop_loss_pct']
        else:
            # Already in loss format or use the stop_loss_pct value
            self.config['stop_loss'] = self.config.get('stop_loss_pct', 0.96)
        
        if strategy == 'ai_momentum_scalping' and custom_config:
            print("Applying custom configuration with scalping constraints...")
            print(f"Scalping Configuration Applied:")
            print(f"  - Profit Target: {self.config.get('profit_target', 0.001)*100:.3f}% (micro-scalping)")
            print(f"  - Stop Loss: {self.config.get('stop_loss', 0.0006)*100:.3f}% (tight risk control)")
            print(f"  - Max Position: {self.config.get('max_position', 0.06):.1%} (frequent trading)")
            print(f"  - Q-Buy/Sell: {self.config.get('q_buy', 0.25):.2f}/{self.config.get('q_sell', 0.15):.2f} (scalping thresholds)")

    def _get_scalping_constrained_config(self, custom_config, initial_cash):
        """
        Get config constrained to AI Momentum Scalping appropriate ranges.
        User inputs are validated and adjusted to work with scalping strategy.
        """
        # AI Momentum Scalping base defaults
        scalping_config = {
            'initial_cash': initial_cash,
            'risk_per_trade': 0.025,           # 2.5% per trade (scalping appropriate)
            'max_position': 0.06,              # 6% max position (frequent trading)
            'profit_target': 0.0012,           # 0.12% micro target (12 basis points)
            'stop_loss': 0.0006,               # 0.06% micro stop (6 basis points)
            'q_buy': 0.25,                     # Lower for more opportunities
            'q_sell': 0.15,                    # Quick exit threshold
            'ml_profit_peak': 0.25,            # ML confidence threshold
            'momentum_threshold': 1.0,         # Momentum filter
            'volume_confirmation_min': 1.3,    # Volume confirmation
            'max_hold_minutes': 45,            # Quick exits
            'rsi_oversold': 25,                # Scalping RSI levels
            'rsi_overbought': 75,
            # Scalping engine specific parameters
            'momentum_multiplier': 1.5,
            'momentum_acceleration_min': 0.3,
            'micro_profit_target': 0.12,       # Match profit_target but in %
            'micro_stop_loss': 0.06,           # Match stop_loss but in %
            'trailing_micro_stop': 0.04,
            'ai_scalp_position_pct': 0.025,
            'max_concurrent_scalps': 4,
            'cooldown_seconds': 30
        }
        
        if custom_config is None:
            print("Using default AI Momentum Scalping configuration")
            return scalping_config
        
        print("Applying custom configuration with scalping constraints...")
        
        # Apply custom config with scalping constraints
        constrained_config = scalping_config.copy()
        adjustments_made = []
        
        # Constrain profit target to scalping range (0.05% to 0.5%)
        if 'sell_profit_pct' in custom_config or 'profit_target' in custom_config:
            user_profit = custom_config.get('sell_profit_pct', custom_config.get('profit_target', 0.04))
            if user_profit > 0.005:  # 0.5% max for scalping
                constrained_config['profit_target'] = 0.005
                constrained_config['micro_profit_target'] = 0.5
                adjustments_made.append(f"Profit target constrained from {user_profit:.2%} to 0.5% (scalping max)")
            elif user_profit < 0.0005:  # 0.05% min
                constrained_config['profit_target'] = 0.0005
                constrained_config['micro_profit_target'] = 0.05
                adjustments_made.append(f"Profit target raised from {user_profit:.2%} to 0.05% (scalping min)")
            else:
                constrained_config['profit_target'] = user_profit
                constrained_config['micro_profit_target'] = user_profit * 100
        
        # Constrain stop loss to scalping range (0.03% to 0.2%)
        if 'stop_loss_pct' in custom_config or 'stop_loss' in custom_config:
            user_stop = custom_config.get('stop_loss_pct', custom_config.get('stop_loss', 0.96))
            # Convert from percentage format to loss format if needed
            if user_stop > 0.5:  # Percentage format (e.g., 0.96 = 96% of price = 4% loss)
                user_stop_loss = 1.0 - user_stop
            else:
                user_stop_loss = user_stop
            
            if user_stop_loss > 0.002:  # 0.2% max loss for scalping
                constrained_config['stop_loss'] = 0.002
                constrained_config['micro_stop_loss'] = 0.2
                adjustments_made.append(f"Stop loss constrained from {user_stop_loss:.2%} to 0.2% (scalping max)")
            elif user_stop_loss < 0.0003:  # 0.03% min
                constrained_config['stop_loss'] = 0.0003
                constrained_config['micro_stop_loss'] = 0.03
                adjustments_made.append(f"Stop loss raised from {user_stop_loss:.2%} to 0.03% (scalping min)")
            else:
                constrained_config['stop_loss'] = user_stop_loss
                constrained_config['micro_stop_loss'] = user_stop_loss * 100
        
        # Constrain position size to scalping range (1% to 10%)
        if 'max_position_size' in custom_config or 'max_position' in custom_config:
            user_position = custom_config.get('max_position_size', custom_config.get('max_position', 0.15))
            if user_position > 0.10:  # 10% max for scalping
                constrained_config['max_position'] = 0.10
                adjustments_made.append(f"Position size constrained from {user_position:.1%} to 10% (scalping max)")
            elif user_position < 0.01:  # 1% min
                constrained_config['max_position'] = 0.01
                adjustments_made.append(f"Position size raised from {user_position:.1%} to 1% (scalping min)")
            else:
                constrained_config['max_position'] = user_position
        
        # Constrain Q-buy to scalping range (0.15 to 0.45)
        if 'q_buy' in custom_config:
            user_q_buy = custom_config['q_buy']
            if user_q_buy > 0.45:  # Too high for scalping (would miss opportunities)
                constrained_config['q_buy'] = 0.45
                adjustments_made.append(f"Q-buy threshold lowered from {user_q_buy:.2f} to 0.45 (scalping needs more opportunities)")
            elif user_q_buy < 0.15:  # Too low (would overtrade)
                constrained_config['q_buy'] = 0.15
                adjustments_made.append(f"Q-buy threshold raised from {user_q_buy:.2f} to 0.15 (scalping quality filter)")
            else:
                constrained_config['q_buy'] = user_q_buy
        
        # Constrain Q-sell to scalping range (0.05 to 0.25)
        if 'q_sell' in custom_config:
            user_q_sell = custom_config['q_sell']
            if user_q_sell > 0.25:  # Too high for quick scalping exits
                constrained_config['q_sell'] = 0.25
                adjustments_made.append(f"Q-sell threshold lowered from {user_q_sell:.2f} to 0.25 (scalping needs quick exits)")
            elif user_q_sell < 0.05:  # Too low
                constrained_config['q_sell'] = 0.05
                adjustments_made.append(f"Q-sell threshold raised from {user_q_sell:.2f} to 0.05 (minimum quality filter)")
            else:
                constrained_config['q_sell'] = user_q_sell
        
        # Constrain risk per trade to scalping range (1% to 5%)
        if 'max_risk_per_trade' in custom_config or 'risk_per_trade' in custom_config:
            user_risk = custom_config.get('max_risk_per_trade', custom_config.get('risk_per_trade', 0.025))
            if user_risk > 0.05:  # 5% max for frequent scalping
                constrained_config['risk_per_trade'] = 0.05
                adjustments_made.append(f"Risk per trade constrained from {user_risk:.1%} to 5% (scalping max)")
            elif user_risk < 0.01:  # 1% min
                constrained_config['risk_per_trade'] = 0.01
                adjustments_made.append(f"Risk per trade raised from {user_risk:.1%} to 1% (scalping min)")
            else:
                constrained_config['risk_per_trade'] = user_risk
        
        # Apply other scalping-compatible settings
        if 'ml_profit_peak' in custom_config:
            # Keep ML profit peak in reasonable range for scalping
            user_ml = custom_config['ml_profit_peak']
            constrained_config['ml_profit_peak'] = max(0.15, min(0.50, user_ml))
            if user_ml != constrained_config['ml_profit_peak']:
                adjustments_made.append(f"ML profit peak adjusted from {user_ml:.2f} to {constrained_config['ml_profit_peak']:.2f}")
        
        # RSI levels - allow more flexibility but warn if extreme
        if 'rsi_oversold' in custom_config:
            user_rsi_oversold = custom_config['rsi_oversold']
            if user_rsi_oversold > 35:
                constrained_config['rsi_oversold'] = 35
                adjustments_made.append(f"RSI oversold lowered from {user_rsi_oversold} to 35 (scalping opportunities)")
            else:
                constrained_config['rsi_oversold'] = user_rsi_oversold
        
        if 'rsi_overbought' in custom_config:
            user_rsi_overbought = custom_config['rsi_overbought']
            if user_rsi_overbought < 65:
                constrained_config['rsi_overbought'] = 65
                adjustments_made.append(f"RSI overbought raised from {user_rsi_overbought} to 65 (scalping opportunities)")
            else:
                constrained_config['rsi_overbought'] = user_rsi_overbought
        
        # Apply remaining custom settings that don't conflict with scalping
        safe_passthrough_keys = ['initial_cash', 'start_date', 'end_date']
        for key in safe_passthrough_keys:
            if key in custom_config:
                constrained_config[key] = custom_config[key]
        
        # Report adjustments
        if adjustments_made:
            print("\nSCALPING CONSTRAINTS APPLIED:")
            for adjustment in adjustments_made:
                print(f"  • {adjustment}")
            print("\nReason: AI Momentum Scalping requires tight parameters for micro-profit targets")
            print("Your strategy is optimized for frequent, small-profit trades with quick exits.\n")
        else:
            print("Custom configuration is compatible with AI Momentum Scalping strategy")
        
        return constrained_config

    def get_historical_data(self, symbol, days=365):
        """Get historical data for a symbol with fallback to synthetic data"""
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            
            request_params = StockBarsRequest(
                symbol_or_symbols=symbol,
                timeframe=TimeFrame.Day,
                start=start_date,
                end=end_date
            )
            
            bars = self.data_client.get_stock_bars(request_params)
            
            if symbol in bars.data:
                data = []
                for bar in bars.data[symbol]:
                    data.append({
                        'timestamp': bar.timestamp,
                        'open': bar.open,
                        'high': bar.high,
                        'low': bar.low,
                        'close': bar.close,
                        'volume': bar.volume
                    })
                
                df = pd.DataFrame(data)
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                df.set_index('timestamp', inplace=True)
                return df
            
        except Exception as e:
            print(f"Error getting data for {symbol}: {e}")
            print(f"  Falling back to synthetic data for {symbol}")
            return self._generate_synthetic_data(symbol, days)
    
    def _generate_synthetic_data(self, symbol, days):
        """Generate synthetic market data when real data is unavailable"""
        try:
            # Generate realistic synthetic price data
            np.random.seed(hash(symbol) % 2**32)  # Reproducible per symbol
            
            # Base prices for different symbols
            base_prices = {
                'AAPL': 150, 'MSFT': 300, 'GOOGL': 2500, 'TSLA': 800, 
                'NVDA': 400, 'META': 200, 'AMZN': 3000, 'NFLX': 400
            }
            base_price = base_prices.get(symbol, 100)
            
            # Generate price series with realistic volatility
            dates = pd.date_range(start=datetime.now() - timedelta(days=days), 
                                 end=datetime.now(), freq='D')
            
            # Generate returns with realistic characteristics
            returns = np.random.normal(0.0005, 0.02, len(dates))  # Small positive drift, 2% vol
            prices = [base_price]
            
            for ret in returns[1:]:
                new_price = prices[-1] * (1 + ret)
                prices.append(max(new_price, 1.0))  # Ensure positive prices
            
            # Generate OHLCV data
            data = []
            for i, (date, close) in enumerate(zip(dates, prices)):
                # Generate realistic intraday range
                daily_vol = abs(np.random.normal(0, 0.01))  # Daily volatility
                high = close * (1 + daily_vol / 2)
                low = close * (1 - daily_vol / 2)
                open_price = low + (high - low) * np.random.random()
                
                # Ensure OHLC relationship is valid
                high = max(high, open_price, close)
                low = min(low, open_price, close)
                
                volume = int(np.random.lognormal(15, 1))  # Realistic volume
                
                data.append({
                    'timestamp': date,
                    'open': round(open_price, 2),
                    'high': round(high, 2),
                    'low': round(low, 2),
                    'close': round(close, 2),
                    'volume': volume
                })
            
            df = pd.DataFrame(data)
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df.set_index('timestamp', inplace=True)
            
            print(f"  Generated {len(df)} days of synthetic data for {symbol}")
            return df
            
        except Exception as e:
            print(f"Error generating synthetic data for {symbol}: {e}")
            return None

    def calculate_indicators(self, df):
        """Calculate technical indicators"""
        if df is None or len(df) < 50:
            return None
        
        # RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs))
        
        # Moving averages
        df['sma_20'] = df['close'].rolling(20).mean()
        df['sma_50'] = df['close'].rolling(50).mean()
        df['ema_12'] = df['close'].ewm(span=12).mean()
        df['ema_26'] = df['close'].ewm(span=26).mean()
        
        # MACD
        df['macd'] = df['ema_12'] - df['ema_26']
        df['macd_signal'] = df['macd'].ewm(span=9).mean()
        
        # Volatility and momentum
        df['volatility'] = df['close'].rolling(20).std()
        df['momentum'] = df['close'].pct_change(periods=10)
        df['volume_sma'] = df['volume'].rolling(20).mean()
        df['volume_ratio'] = df['volume'] / df['volume_sma']
        
        return df
    
    def _create_state_vector(self, indicators):
        """Create state vector for LAEF AI neural network"""
        state = []
        
        # Price features
        state.append(indicators.get('rsi', 50) / 100.0)
        state.append(indicators.get('macd', 0))
        state.append(indicators.get('macd_signal', 0))
        
        # Volume features
        state.append(indicators.get('volume_ratio', 1.0))
        state.append(indicators.get('obv', 0) / 1e6)  # Normalize OBV
        
        # Momentum features
        state.append(indicators.get('momentum_score', 0))
        state.append(indicators.get('momentum_strength', 0))
        state.append(indicators.get('price_acceleration', 0))
        
        # Volatility features
        state.append(indicators.get('atr', 0) / indicators.get('close', 1))
        state.append(indicators.get('bb_position', 0.5))
        
        # Moving average features
        state.append(indicators.get('sma_ratio', 1.0))
        state.append(indicators.get('ema_ratio', 1.0))
        
        # Pattern features
        state.append(indicators.get('support_distance', 0))
        state.append(indicators.get('resistance_distance', 0))
        
        # Market microstructure
        state.append(indicators.get('spread', 0))
        state.append(indicators.get('bid_ask_imbalance', 0))
        state.append(indicators.get('trade_intensity', 0))
        
        # Pad to STATE_SIZE if needed
        while len(state) < STATE_FEATURES:
            state.append(0.0)
        
        return np.array(state[:STATE_FEATURES], dtype=np.float32)

    def simulate_ai_trading(self, df, symbol):
        """Simulate trading using the selected trading engine"""
        try:
            if df is None or len(df) < 50:
                return None
            
            # Calculate all indicators (including momentum data)
            df_with_indicators = calculate_all_indicators(df)
            
            trades = []
            decisions = []
            portfolio_values = []  # Track portfolio value over time
            
            # Simulate trading day by day
            for i in range(50, len(df_with_indicators)):  # Start after indicators are stable
                current_data = df_with_indicators.iloc[:i+1]  # All data up to current point
                current_price = current_data['close'].iloc[-1]
                timestamp = current_data.index[-1]
                
                # Get indicators for current point
                indicators = get_latest_indicators(current_data)
                
                # Get real Q-value and ML confidence from trained LAEF models
                q_value, ml_confidence = self._get_real_ai_signals(current_data, indicators)
                
                # Get trading engine decision based on strategy
                if self.strategy == 'laef_ai':
                    # For pure LAEF AI, create state vector and use dynamic evaluation
                    state = self._create_state_vector(indicators)
                    decision, confidence, reason, action_data = self.trading_engine.evaluate_trade_decision(
                        symbol, state, indicators, current_price, ml_confidence, timestamp
                    )
                else:
                    # For AI Momentum Scalping, use the existing interface
                    decision, confidence, reason, action_data = self.trading_engine.evaluate_trade_decision(
                        symbol, q_value, ml_confidence, indicators, current_price, timestamp
                    )
                
                # Record decision
                decisions.append({
                    'date': timestamp,
                    'symbol': symbol,
                    'decision': decision,
                    'confidence': confidence,
                    'reason': reason,
                    'q_value': q_value,
                    'ml_confidence': ml_confidence,
                    'price': current_price
                })
                
                # Execute trade if decision is buy/sell
                if decision == 'buy' and action_data.get('can_buy', False):
                    shares = action_data['shares']
                    
                    # Apply slippage to buy price (pay more when buying)
                    execution_price = current_price
                    if self.use_slippage:
                        slippage_factor = 1 + (self.slippage_bps / 10000)  # Convert basis points
                        execution_price = current_price * slippage_factor
                    
                    cost = shares * execution_price
                    success = self.portfolio.buy(symbol, execution_price, shares, timestamp)
                    if success:
                        trades.append({
                            'date': timestamp,
                            'action': 'BUY',
                            'symbol': symbol,
                            'price': execution_price,
                            'actual_price': current_price,
                            'slippage': execution_price - current_price,
                            'quantity': shares,
                            'cost': cost
                        })
                
                elif decision == 'sell' and self.portfolio.has_position(symbol):
                    shares = action_data.get('shares', 0)
                    # Get entry time for duration calculation
                    position_info = self.portfolio.get_position_info(symbol) if hasattr(self.portfolio, 'get_position_info') else None
                    entry_time = position_info.get('entry_time', timestamp) if position_info else timestamp
                    
                    # Apply slippage to sell price (receive less when selling)
                    execution_price = current_price
                    if self.use_slippage:
                        slippage_factor = 1 - (self.slippage_bps / 10000)  # Convert basis points
                        execution_price = current_price * slippage_factor
                    
                    success, realized_pnl, sell_reason = self.portfolio.sell(symbol, execution_price, shares, timestamp=timestamp)
                    if success:
                        trades.append({
                            'date': timestamp,
                            'action': 'SELL',
                            'symbol': symbol,
                            'price': execution_price,
                            'actual_price': current_price,
                            'slippage': current_price - execution_price,
                            'quantity': shares,
                            'proceeds': shares * execution_price,
                            'pnl': realized_pnl,
                            'entry_time': entry_time,
                            'duration': (timestamp - entry_time).total_seconds() / 60 if entry_time != timestamp else 0  # minutes
                        })
            
                # Track portfolio value
                portfolio_value = self.portfolio.get_total_portfolio_value({symbol: current_price})
                portfolio_values.append({
                    'date': timestamp,
                    'value': portfolio_value,
                    'price': current_price
                })
            
            # Final portfolio value
            final_price = df_with_indicators['close'].iloc[-1]
            final_value = self.portfolio.get_total_portfolio_value({symbol: final_price})
            
            # Calculate advanced metrics
            metrics = self._calculate_advanced_metrics(trades, portfolio_values, self.initial_cash)
            
            return {
                'final_value': final_value,
                'trades': trades,
                'decisions': decisions,
                'cash': self.portfolio.get_available_cash(),
                'positions': self.portfolio.get_position_quantity(symbol),
                'portfolio_values': portfolio_values,
                'metrics': metrics
            }
            
        except Exception as e:
            print(f"Error in AI trading simulation for {symbol}: {e}")
            return None

    def _get_real_ai_signals(self, df, indicators):
        """Get real Q-value and ML confidence from trained LAEF models"""
        try:
            if self.laef_agent is None:
                # Fallback to technical analysis if LAEF agent not available
                return self._generate_fallback_signals(df)
            
            # Prepare state vector for LAEF agent
            state = self._prepare_state_vector(indicators)
            
            if state is None:
                return 0.35, 0.35  # Neutral fallback
            
            # Get Q-values from trained model
            q_values = self.laef_agent.predict_q_values(state)
            
            # Extract individual Q-values: [hold, buy, sell]
            q_hold = q_values[0] if len(q_values) > 0 else 0.35
            q_buy = q_values[1] if len(q_values) > 1 else 0.35
            q_sell = q_values[2] if len(q_values) > 2 else 0.35
            
            # Convert Q-values to decision values (higher buy vs sell)
            q_value = max(0, min(1, (q_buy - q_sell + 1) / 2))  # Normalize to 0-1
            
            # ML confidence estimation (based on Q-value certainty and momentum)
            q_certainty = max(abs(q_buy - q_hold), abs(q_sell - q_hold))
            momentum_factor = indicators.get('momentum_score', 0) / 10.0
            
            ml_confidence = max(0, min(1, q_certainty * 0.7 + abs(momentum_factor) * 0.3))
            
            return float(q_value), float(ml_confidence)
            
        except Exception as e:
            print(f"Error getting real AI signals: {e}")
            return self._generate_fallback_signals(df)
    
    def _prepare_state_vector(self, indicators):
        """Prepare state vector for LAEF agent from indicators"""
        try:
            # Create state vector using STATE_FEATURES from config
            state = []
            
            for feature in STATE_FEATURES:
                if feature in indicators:
                    value = indicators[feature]
                    # Handle NaN/inf values
                    if np.isnan(value) or np.isinf(value):
                        value = 0.0
                    state.append(float(value))
                else:
                    # Missing feature - use default
                    state.append(0.0)
            
            # Ensure we have exactly the right number of features
            while len(state) < len(STATE_FEATURES):
                state.append(0.0)
            
            state = state[:len(STATE_FEATURES)]  # Truncate if too long
            
            return np.array(state, dtype=np.float32)
            
        except Exception as e:
            print(f"Error preparing state vector: {e}")
            return None
    
    def _generate_fallback_signals(self, df):
        """Generate technical analysis-based signals when LAEF agent not available"""
        try:
            current_price = df['close'].iloc[-1]
            sma_20 = df['sma20'].iloc[-1] if 'sma20' in df.columns else current_price
            sma_50 = df['sma50'].iloc[-1] if 'sma50' in df.columns else current_price
            rsi = df['rsi'].iloc[-1] if 'rsi' in df.columns else 50
            macd = df['macd'].iloc[-1] if 'macd' in df.columns else 0
            
            # Generate Q-value based on trend and momentum
            q_base = 0.35  # Neutral starting point
            
            # Trend component
            if current_price > sma_20 > sma_50:
                q_base += 0.15  # Uptrend
            elif current_price < sma_20 < sma_50:
                q_base -= 0.15  # Downtrend
            
            # RSI component
            if rsi < 30:
                q_base += 0.1  # Oversold
            elif rsi > 70:
                q_base -= 0.1  # Overbought
            
            # MACD component
            if macd > 0:
                q_base += 0.05
            else:
                q_base -= 0.05
            
            q_value = max(0, min(1, q_base))
            
            # Generate ML confidence based on momentum
            recent_change = (current_price / df['close'].iloc[-5] - 1) if len(df) >= 5 else 0
            ml_base = 0.35 + (abs(recent_change) * 2)  # Higher confidence with more momentum
            ml_confidence = max(0, min(1, ml_base))
            
            return q_value, ml_confidence
            
        except Exception as e:
            print(f"Error generating fallback signals: {e}")
            return 0.35, 0.35
    
    def _calculate_advanced_metrics(self, trades, portfolio_values, initial_cash):
        """Calculate advanced performance metrics"""
        try:
            if not portfolio_values:
                return {}
            
            # Convert to DataFrame for easier calculations
            pv_df = pd.DataFrame(portfolio_values)
            pv_df['date'] = pd.to_datetime(pv_df['date'])
            pv_df.set_index('date', inplace=True)
            pv_df.sort_index(inplace=True)
            
            # Calculate returns
            pv_df['returns'] = pv_df['value'].pct_change().fillna(0)
            pv_df['cumulative_returns'] = (1 + pv_df['returns']).cumprod() - 1
            
            # Total return
            total_return = (pv_df['value'].iloc[-1] - initial_cash) / initial_cash
            
            # Annualized return (assuming 252 trading days)
            days_in_backtest = (pv_df.index[-1] - pv_df.index[0]).days
            years = days_in_backtest / 365.25
            annualized_return = ((1 + total_return) ** (1 / years) - 1) if years > 0 else 0
            
            # Sharpe Ratio (risk-free rate = 0.02)
            risk_free_rate = 0.02 / 252  # Daily risk-free rate
            excess_returns = pv_df['returns'] - risk_free_rate
            sharpe_ratio = np.sqrt(252) * excess_returns.mean() / excess_returns.std() if excess_returns.std() > 0 else 0
            
            # Sortino Ratio (downside deviation)
            downside_returns = excess_returns[excess_returns < 0]
            downside_std = downside_returns.std() if len(downside_returns) > 0 else 0
            sortino_ratio = np.sqrt(252) * excess_returns.mean() / downside_std if downside_std > 0 else 0
            
            # Maximum Drawdown
            cumulative = (1 + pv_df['returns']).cumprod()
            running_max = cumulative.expanding().max()
            drawdown = (cumulative - running_max) / running_max
            max_drawdown = drawdown.min()
            
            # Find drawdown periods
            drawdown_start = drawdown[drawdown == max_drawdown].index[0]
            peak_idx = pv_df.index.get_loc(drawdown_start)
            peak_date = pv_df.index[max(0, peak_idx - 1)]
            recovery_mask = (pv_df.index > drawdown_start) & (cumulative >= running_max[drawdown_start])
            recovery_date = pv_df.index[recovery_mask][0] if recovery_mask.any() else None
            
            # Trade Statistics
            if trades:
                trades_df = pd.DataFrame(trades)
                
                # Separate wins and losses
                sell_trades = trades_df[trades_df['action'] == 'SELL']
                if not sell_trades.empty and 'pnl' in sell_trades.columns:
                    winning_trades = sell_trades[sell_trades['pnl'] > 0]
                    losing_trades = sell_trades[sell_trades['pnl'] <= 0]
                    
                    avg_win = winning_trades['pnl'].mean() if not winning_trades.empty else 0
                    avg_loss = abs(losing_trades['pnl'].mean()) if not losing_trades.empty else 0
                    win_rate = len(winning_trades) / len(sell_trades) if len(sell_trades) > 0 else 0
                    
                    # Profit Factor
                    total_wins = winning_trades['pnl'].sum() if not winning_trades.empty else 0
                    total_losses = abs(losing_trades['pnl'].sum()) if not losing_trades.empty else 0
                    profit_factor = total_wins / total_losses if total_losses > 0 else float('inf')
                    
                    # Trade Duration Statistics
                    if 'duration' in sell_trades.columns:
                        avg_duration = sell_trades['duration'].mean()
                        median_duration = sell_trades['duration'].median()
                        max_duration = sell_trades['duration'].max()
                        min_duration = sell_trades['duration'].min()
                    else:
                        avg_duration = median_duration = max_duration = min_duration = 0
                    
                    # Expectancy
                    expectancy = (win_rate * avg_win) - ((1 - win_rate) * avg_loss)
                else:
                    avg_win = avg_loss = win_rate = profit_factor = expectancy = 0
                    avg_duration = median_duration = max_duration = min_duration = 0
                
                # Commission calculation (assuming $0.01 per share or 0.1% of trade value)
                commission_per_share = 0.01
                commission_rate = 0.001  # 0.1%
                
                total_shares_traded = trades_df['quantity'].sum()
                total_value_traded = sum(trade['quantity'] * trade['price'] for trade in trades)
                
                commission_by_shares = total_shares_traded * commission_per_share
                commission_by_value = total_value_traded * commission_rate
                estimated_commission = min(commission_by_shares, commission_by_value)  # Use lower estimate
                
                # Calculate total slippage cost
                total_slippage = trades_df['slippage'].sum() * trades_df['quantity'].sum() if 'slippage' in trades_df.columns else 0
            else:
                avg_win = avg_loss = win_rate = profit_factor = expectancy = 0
                avg_duration = median_duration = max_duration = min_duration = 0
                estimated_commission = 0
                total_slippage = 0
            
            metrics = {
                'total_return': total_return,
                'annualized_return': annualized_return,
                'sharpe_ratio': sharpe_ratio,
                'sortino_ratio': sortino_ratio,
                'max_drawdown': max_drawdown,
                'max_drawdown_duration': (recovery_date - peak_date).days if recovery_date else None,
                'drawdown_start': drawdown_start.strftime('%Y-%m-%d'),
                'average_win': avg_win,
                'average_loss': avg_loss,
                'win_rate': win_rate,
                'profit_factor': profit_factor,
                'expectancy': expectancy,
                'avg_trade_duration': avg_duration,
                'median_trade_duration': median_duration,
                'max_trade_duration': max_duration,
                'min_trade_duration': min_duration,
                'estimated_commission': estimated_commission,
                'total_slippage_cost': total_slippage,
                'days_tested': days_in_backtest,
                'total_trades': len(trades)
            }
            
            return metrics
            
        except Exception as e:
            print(f"Error calculating advanced metrics: {e}")
            return {}

    def generate_ml_signals(self, df):
        """Generate ML trading signals"""
        if df is None:
            return None
        
        signals = []
        
        for i in range(50, len(df)):
            row = df.iloc[i]
            
            # ML Score calculation
            ml_score = 0.5
            
            # RSI component
            if row['rsi'] < self.config['rsi_oversold']:
                ml_score += 0.2
            elif row['rsi'] > self.config['rsi_overbought']:
                ml_score -= 0.2
            
            # Trend analysis
            if row['close'] > row['sma_20'] > row['sma_50']:
                ml_score += 0.15
            elif row['close'] < row['sma_20'] < row['sma_50']:
                ml_score -= 0.15
            
            # MACD momentum
            if row['macd'] > row['macd_signal']:
                ml_score += 0.1
            else:
                ml_score -= 0.1
            
            # Volume and momentum
            if row['volume_ratio'] > 1.5:
                ml_score += 0.05
            if row['momentum'] > 0.02:
                ml_score += 0.1
            elif row['momentum'] < -0.02:
                ml_score -= 0.1
            
            # Clamp score
            ml_score = max(0, min(1, ml_score))
            
            # Generate signal
            if ml_score >= self.config['q_buy']:
                signal = 'BUY'
            elif ml_score <= self.config['q_sell']:
                signal = 'SELL'
            else:
                signal = 'HOLD'
            
            signals.append({
                'date': row.name,
                'price': row['close'],
                'ml_score': ml_score,
                'signal': signal,
                'rsi': row['rsi'],
                'macd': row['macd']
            })
        
        return pd.DataFrame(signals)

    def simulate_trading(self, signals, symbol):
        """Simulate trading based on signals"""
        if signals is None or len(signals) == 0:
            return None
        
        cash = self.config['initial_cash']
        position = 0
        position_price = 0
        trades = []
        
        for _, signal in signals.iterrows():
            current_price = signal['price']
            ml_score = signal['ml_score']
            action = signal['signal']
            
            # Buy logic
            if action == 'BUY' and position == 0 and ml_score >= self.config['q_buy']:
                position_size = min(
                    cash * self.config['risk_per_trade'] / current_price,
                    cash * self.config['max_position'] / current_price
                )
                
                position = int(position_size)
                if position > 0:
                    cost = position * current_price
                    cash -= cost
                    position_price = current_price
                    trades.append({
                        'date': signal['date'],
                        'action': 'BUY',
                        'symbol': symbol,
                        'price': current_price,
                        'quantity': position,
                        'ml_score': ml_score,
                        'rsi': signal.get('rsi', 50),
                        'price_position': 0.5  # Will be calculated if we have price range data
                    })
            
            # Sell logic
            elif position > 0:
                profit_pct = (current_price - position_price) / position_price
                
                # Determine sell trigger
                sell_trigger = None
                if profit_pct >= self.config['profit_target']:
                    sell_trigger = 'profit_target'
                elif profit_pct <= -self.config['stop_loss']:
                    sell_trigger = 'stop_loss'
                elif action == 'SELL' and ml_score <= self.config['q_sell']:
                    sell_trigger = 'ml_signal'
                
                should_sell = sell_trigger is not None
                
                if should_sell:
                    proceeds = position * current_price
                    cash += proceeds
                    trades.append({
                        'date': signal['date'],
                        'action': 'SELL',
                        'symbol': symbol,
                        'price': current_price,
                        'quantity': position,
                        'profit_pct': profit_pct,
                        'ml_score': ml_score,
                        'rsi': signal.get('rsi', 50),
                        'sell_trigger': sell_trigger
                    })
                    position = 0
                    position_price = 0
        
        # Final portfolio value
        final_value = cash + (position * signals.iloc[-1]['price'])
        
        return {
            'final_value': final_value,
            'trades': trades,
            'cash': cash,
            'position': position
        }

    def run_backtest(self, symbols=None, limit_symbols=None, use_smart_selection=True, analysis_mode='ml_focused', days=365):
        """Run backtest with specified parameters"""
        
        # Default symbols if none provided
        if symbols is None:
            symbols = ["AAPL", "MSFT", "GOOGL", "TSLA", "NVDA", "META", "AMZN", "NFLX"]
        
        # Limit symbols if specified
        if limit_symbols and limit_symbols < len(symbols):
            symbols = symbols[:limit_symbols]
        
        print(f"Running backtest on {len(symbols)} symbols: {', '.join(symbols)}")
        
        # Calculate date range
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        results = {
            'selection_method': 'smart' if use_smart_selection else 'traditional',
            'analysis_mode': analysis_mode,
            'symbols_processed': [],
            'symbol_results': {},
            'performance': {},
            'config': self.config,
            'start_date': start_date,
            'end_date': end_date,
            'days': days
        }
        
        all_trades = []
        symbol_results = []
        
        for symbol in symbols:
            print(f"Processing {symbol}...")
            
            # Get data (6 months default)
            df = self.get_historical_data(symbol, days=180)
            if df is None:
                continue
            
            # Calculate indicators
            df = self.calculate_indicators(df)
            if df is None:
                continue
            
            # Use AI Momentum Scalping Engine for decisions
            trading_result = self.simulate_ai_trading(df, symbol)
            if trading_result is None:
                continue
            
            # Calculate metrics
            buy_trades = [t for t in trading_result['trades'] if t['action'] == 'BUY']
            sell_trades = [t for t in trading_result['trades'] if t['action'] == 'SELL']
            winning_trades = [t for t in sell_trades if t.get('pnl', 0) > 0]
            
            # Calculate total return based on final portfolio value
            symbol_final_value = trading_result['final_value']
            total_return = (symbol_final_value - self.config['initial_cash']) / self.config['initial_cash']
            win_rate = len(winning_trades) / len(sell_trades) if sell_trades else 0
            
            # Calculate average AI scores from decisions
            decisions = trading_result.get('decisions', [])
            avg_q_value = np.mean([d['q_value'] for d in decisions]) if decisions else 0.35
            avg_ml_score = np.mean([d['ml_confidence'] for d in decisions]) if decisions else 0.35
            
            # Get advanced metrics from the trading result
            advanced_metrics = trading_result.get('metrics', {})
            
            symbol_result = {
                'symbol': symbol,
                'final_value': symbol_final_value,
                'total_return': total_return,
                'total_trades': len(buy_trades),
                'winning_trades': len(winning_trades),
                'losing_trades': len(sell_trades) - len(winning_trades),
                'win_rate': win_rate,
                'avg_q_value': avg_q_value,
                'avg_ml_score': avg_ml_score,
                'total_decisions': len(decisions),
                'sharpe_ratio': advanced_metrics.get('sharpe_ratio', 0),
                'sortino_ratio': advanced_metrics.get('sortino_ratio', 0),
                'max_drawdown': advanced_metrics.get('max_drawdown', 0),
                'profit_factor': advanced_metrics.get('profit_factor', 0),
                'expectancy': advanced_metrics.get('expectancy', 0),
                'avg_trade_duration': advanced_metrics.get('avg_trade_duration', 0),
                'annualized_return': advanced_metrics.get('annualized_return', 0)
            }
            
            symbol_results.append(symbol_result)
            all_trades.extend(trading_result['trades'])
            results['symbols_processed'].append(symbol)
            results['symbol_results'][symbol] = symbol_result
            
            print(f"  {symbol}: {total_return:.2%} return, {len(buy_trades)} trades, {win_rate:.1%} win rate")
        
        # Calculate overall performance
        if symbol_results:
            avg_return = sum(r['total_return'] for r in symbol_results) / len(symbol_results)
            total_trades = sum(r['total_trades'] for r in symbol_results)
            avg_win_rate = sum(r['win_rate'] for r in symbol_results) / len(symbol_results)
            avg_final_value = sum(r['final_value'] for r in symbol_results) / len(symbol_results)
            
            # Calculate weighted average for risk metrics
            total_value = sum(r['final_value'] for r in symbol_results)
            weighted_sharpe = sum(r['sharpe_ratio'] * r['final_value'] / total_value for r in symbol_results)
            weighted_sortino = sum(r['sortino_ratio'] * r['final_value'] / total_value for r in symbol_results)
            
            # Average other metrics
            avg_max_drawdown = sum(r['max_drawdown'] for r in symbol_results) / len(symbol_results)
            avg_profit_factor = sum(r['profit_factor'] for r in symbol_results if r['profit_factor'] != float('inf')) / len([r for r in symbol_results if r['profit_factor'] != float('inf')]) if any(r['profit_factor'] != float('inf') for r in symbol_results) else 0
            avg_expectancy = sum(r['expectancy'] for r in symbol_results) / len(symbol_results)
            avg_trade_duration = sum(r['avg_trade_duration'] for r in symbol_results) / len(symbol_results)
            avg_annualized_return = sum(r['annualized_return'] for r in symbol_results) / len(symbol_results)
            
            # Calculate total commission estimate based on all trades
            commission_per_trade = 1.0  # $1 per trade (conservative estimate)
            total_commission = len(all_trades) * commission_per_trade
            
            results['performance'] = {
                'final_value': avg_final_value,
                'total_return_pct': avg_return * 100,
                'annualized_return_pct': avg_annualized_return * 100,
                'total_trades': total_trades,
                'win_rate': avg_win_rate * 100,
                'symbols_tested': len(symbol_results),
                'sharpe_ratio': weighted_sharpe,
                'sortino_ratio': weighted_sortino,
                'max_drawdown_pct': avg_max_drawdown * 100,
                'profit_factor': avg_profit_factor,
                'expectancy': avg_expectancy,
                'avg_trade_duration_minutes': avg_trade_duration,
                'total_commission_estimate': total_commission
            }
        
        # Save backtest logs for optimizer
        if results and results.get('symbols_processed'):
            self.save_backtest_logs(results, all_trades)
        
        return results

    def save_backtest_logs(self, results, all_trades):
        """Save backtest logs in format expected by optimizer"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Create decisions log (what optimizer expects)
        decisions_data = []
        trades_data = []
        
        for trade in all_trades:
            if trade['action'] == 'BUY':
                # Create explanation for buy decision
                explanation = self._generate_buy_explanation(trade)
                
                # Create decision record for buy
                decisions_data.append({
                    'timestamp': trade['date'].strftime('%Y-%m-%d %H:%M:%S') if hasattr(trade['date'], 'strftime') else str(trade['date']),
                    'symbol': trade['symbol'],
                    'action': 'BUY',
                    'price': trade['price'],
                    'ml_score': trade.get('ml_score', 0.0),
                    'quantity': trade['quantity'],
                    'decision_reason': f"ML_score_{trade.get('ml_score', 0.0):.3f}",
                    'priority_explanation': explanation
                })
                
                # Create trade record
                trades_data.append({
                    'timestamp': trade['date'].strftime('%Y-%m-%d %H:%M:%S') if hasattr(trade['date'], 'strftime') else str(trade['date']),
                    'symbol': trade['symbol'],
                    'action': 'BUY',
                    'price': trade['price'],
                    'quantity': trade['quantity'],
                    'value': trade['price'] * trade['quantity']
                })
                
            elif trade['action'] == 'SELL':
                # Create explanation for sell decision
                explanation = self._generate_sell_explanation(trade)
                
                # Create decision record for sell
                decisions_data.append({
                    'timestamp': trade['date'].strftime('%Y-%m-%d %H:%M:%S') if hasattr(trade['date'], 'strftime') else str(trade['date']),
                    'symbol': trade['symbol'],
                    'action': 'SELL',
                    'price': trade['price'],
                    'ml_score': trade.get('ml_score', 0.0),
                    'quantity': trade['quantity'],
                    'profit_pct': trade.get('profit_pct', 0),
                    'decision_reason': f"ML_score_{trade.get('ml_score', 0.0):.3f}_profit_{trade.get('profit_pct', 0):.3f}",
                    'priority_explanation': explanation
                })
                
                # Create trade record
                trades_data.append({
                    'timestamp': trade['date'].strftime('%Y-%m-%d %H:%M:%S') if hasattr(trade['date'], 'strftime') else str(trade['date']),
                    'symbol': trade['symbol'],
                    'action': 'SELL',
                    'price': trade['price'],
                    'quantity': trade['quantity'],
                    'value': trade['price'] * trade['quantity'],
                    'profit_pct': trade.get('profit_pct', 0)
                })
        
        # Save to CSV files in expected format
        if decisions_data:
            decisions_df = pd.DataFrame(decisions_data)
            decisions_file = f'logs/backtest_decisions_{timestamp}.csv'
            decisions_df.to_csv(decisions_file, index=False)
            print(f"Decisions saved to: {decisions_file}")
        
        if trades_data:
            trades_df = pd.DataFrame(trades_data)
            trades_file = f'logs/backtest_trades_{timestamp}.csv'
            trades_df.to_csv(trades_file, index=False)
            print(f"Trades saved to: {trades_file}")
        
        # Save summary for optimizer
        summary_file = f'logs/backtest_summary_{timestamp}.txt'
        with open(summary_file, 'w') as f:
            f.write(f"LAEF Backtest Summary - {timestamp}\n")
            f.write("=" * 50 + "\n")
            f.write(f"Analysis Mode: {results.get('analysis_mode', 'ml_focused')}\n")
            f.write(f"Selection Method: {results.get('selection_method', 'smart')}\n")
            f.write(f"Symbols Processed: {len(results.get('symbols_processed', []))}\n")
            f.write(f"Symbols: {', '.join(results.get('symbols_processed', []))}\n")
            
            # Add backtesting date range
            if 'start_date' in results and 'end_date' in results:
                f.write(f"Backtest Period: {results['start_date'].strftime('%Y-%m-%d')} to {results['end_date'].strftime('%Y-%m-%d')}\n")
                f.write(f"Days Analyzed: {results.get('days', 365)}\n")
            f.write("\n")
            
            # Add configuration stats
            if 'config' in results:
                config = results['config']
                f.write("CONFIGURATION PARAMETERS:\n")
                f.write(f"Initial Cash: ${config.get('initial_cash', 100000):,.2f}\n")
                f.write(f"Risk Per Trade: {config.get('risk_per_trade', 0.025):.1%}\n")
                f.write(f"Max Position Size: {config.get('max_position', 0.15):.1%}\n")
                f.write(f"Profit Target: {config.get('profit_target', 0.04):.1%}\n")
                # Calculate actual stop loss percentage
                stop_loss_value = config.get('stop_loss_pct', config.get('stop_loss', 0.96))
                if stop_loss_value > 0.5:
                    # It's in "percentage of price" format (e.g., 0.90 = 90% of price = 10% loss)
                    actual_stop_loss = (1 - stop_loss_value) * 100
                    f.write(f"Stop Loss: {actual_stop_loss:.1f}% (triggers when price drops {actual_stop_loss:.1f}% from entry)\n")
                else:
                    # It's already in loss percentage format
                    actual_stop_loss = stop_loss_value * 100
                    f.write(f"Stop Loss: {actual_stop_loss:.1f}%\n")
                f.write(f"Trailing Stop: {config.get('trailing_stop_pct', 0.06):.1%} (sells if profit drops this much from peak)\n")
                f.write(f"Q-Buy Threshold: {config.get('q_buy', 0.55):.2f}\n")
                f.write(f"Q-Sell Threshold: {config.get('q_sell', 0.35):.2f}\n")
                f.write(f"ML Profit Peak: {config.get('ml_profit_peak', 0.55):.2f}\n")
                f.write(f"RSI Oversold: {config.get('rsi_oversold', 30)}\n")
                f.write(f"RSI Overbought: {config.get('rsi_overbought', 60)}\n\n")
            
            if 'performance' in results:
                perf = results['performance']
                f.write("PERFORMANCE METRICS:\n")
                f.write(f"Final Portfolio Value: ${perf.get('final_value', 0):,.2f}\n")
                f.write(f"Total Return: {perf.get('total_return_pct', 0):+.2f}%\n")
                f.write(f"Annualized Return: {perf.get('annualized_return_pct', 0):+.2f}%\n")
                f.write(f"Sharpe Ratio: {perf.get('sharpe_ratio', 0):.3f}\n")
                f.write(f"Sortino Ratio: {perf.get('sortino_ratio', 0):.3f}\n")
                f.write(f"Max Drawdown: {perf.get('max_drawdown_pct', 0):.2f}%\n")
                f.write(f"Win Rate: {perf.get('win_rate', 0):.1f}%\n")
                f.write(f"Profit Factor: {perf.get('profit_factor', 0):.2f}\n")
                f.write(f"Expectancy: ${perf.get('expectancy', 0):.2f}\n")
                f.write(f"Avg Trade Duration: {perf.get('avg_trade_duration_minutes', 0):.1f} minutes\n")
                f.write(f"Total Trades: {perf.get('total_trades', 0)}\n")
                f.write(f"Estimated Commission: ${perf.get('total_commission_estimate', 0):,.2f}\n")
                f.write(f"Symbols Tested: {perf.get('symbols_tested', 0)}\n\n")
            
            # Individual symbol results
            f.write("INDIVIDUAL SYMBOL RESULTS:\n")
            for symbol, result in results.get('symbol_results', {}).items():
                f.write(f"\n{symbol}:\n")
                f.write(f"  Return: {result['total_return']:.2%} (Annualized: {result.get('annualized_return', 0):.2%})\n")
                f.write(f"  Trades: {result['total_trades']} (Win Rate: {result['win_rate']:.1%})\n")
                f.write(f"  Sharpe: {result.get('sharpe_ratio', 0):.3f}, Sortino: {result.get('sortino_ratio', 0):.3f}\n")
                f.write(f"  Max Drawdown: {result.get('max_drawdown', 0):.2%}\n")
                f.write(f"  Avg Trade Duration: {result.get('avg_trade_duration', 0):.1f} min\n")
        
        print(f"Summary saved to: {summary_file}")
    
    def _generate_buy_explanation(self, trade):
        """Generate human-readable explanation for buy decision"""
        ml_score = trade.get('ml_score', 0)
        rsi = trade.get('rsi', 50)
        price_position = trade.get('price_position', 0.5)
        
        explanation_parts = []
        
        # ML Score is the primary driver - explain what this means
        if ml_score >= self.config['q_buy']:
            strength = "strong" if ml_score >= 0.7 else "moderate"
            explanation_parts.append(f"ML model shows {strength} buy signal (score: {ml_score:.2f} vs required {self.config['q_buy']:.2f})")
            
            # Explain WHY the ML score is high in layman's terms
            if ml_score >= 0.7:
                explanation_parts.append("The AI detected multiple positive patterns: upward price momentum, strong trading volume, and favorable technical indicators all align")
            elif ml_score >= 0.6:
                explanation_parts.append("The AI found several bullish signals: price is trending up, buying pressure is increasing, and technical indicators are positive")
            else:
                explanation_parts.append("The AI identified enough positive signals to warrant a buy: moderate upward momentum with improving market conditions")
        
        # RSI context - explain what RSI means
        if rsi is not None and rsi < self.config['rsi_oversold']:
            explanation_parts.append(f"RSI at {rsi:.0f} indicates the stock is oversold (below {self.config['rsi_oversold']}), meaning it may have dropped too far too fast and could bounce back")
        elif rsi is not None and rsi < 40:
            explanation_parts.append(f"RSI at {rsi:.0f} suggests the stock has been declining but isn't yet oversold - there's room for recovery")
        elif rsi is not None and rsi > 60:
            explanation_parts.append(f"RSI at {rsi:.0f} shows strong momentum - the stock is rising with good buying pressure")
        elif rsi is not None:
            explanation_parts.append(f"RSI at {rsi:.0f} is neutral - the stock isn't overbought or oversold")
        
        # Price position - make it relatable
        if price_position < 0.3:
            explanation_parts.append("The stock is trading near its recent lows, offering a potential bargain entry point")
        elif price_position > 0.7:
            explanation_parts.append("The stock is near recent highs, riding strong upward momentum")
        else:
            explanation_parts.append("The stock is in the middle of its recent trading range")
        
        # Risk management - explain the strategy
        explanation_parts.append(f"Position sized at {self.config['risk_per_trade']:.1%} of portfolio to limit risk - this means if the trade goes wrong, you only lose {self.config['risk_per_trade']:.1%} of your total capital")
        
        # Add a summary of the decision logic
        explanation_parts.append(f"SUMMARY: Buying because the AI confidence level ({ml_score:.1%}) exceeds the minimum threshold ({self.config['q_buy']:.1%}), indicating favorable market conditions")
        
        return " | ".join(explanation_parts)
    
    def _generate_sell_explanation(self, trade):
        """Generate human-readable explanation for sell decision"""
        ml_score = trade.get('ml_score', 0)
        profit_pct = trade.get('profit_pct', 0)
        rsi = trade.get('rsi', 50)
        sell_trigger = trade.get('sell_trigger', 'ml_signal')
        
        explanation_parts = []
        
        # Determine primary sell reason based on actual trigger - explain in layman's terms
        if sell_trigger == 'profit_target':
            primary_reason = f"PROFIT TARGET HIT: The stock gained {profit_pct:.1%}, reaching our target of {self.config['profit_target']:.1%}"
            explanation_parts.append(primary_reason)
            explanation_parts.append("This is a disciplined exit - we set a profit goal when we bought, and now we're taking those profits off the table")
            explanation_parts.append("Think of it like setting a goal to make $X on a trade and sticking to it, rather than getting greedy")
            
        elif sell_trigger == 'stop_loss':
            primary_reason = f"STOP LOSS TRIGGERED: The stock fell {-profit_pct:.1%}, hitting our maximum acceptable loss of {self.config['stop_loss']:.1%}"
            explanation_parts.append(primary_reason)
            explanation_parts.append("This is risk management in action - we're cutting our losses before they get worse")
            explanation_parts.append("Like having a safety net, we decided beforehand the most we're willing to lose, and we're sticking to that plan")
            
        elif sell_trigger == 'ml_signal':
            primary_reason = f"AI SELL SIGNAL: The AI's confidence dropped to {ml_score:.2f} (below the sell threshold of {self.config['q_sell']:.2f})"
            explanation_parts.append(primary_reason)
            
            # Explain what the AI is seeing
            if ml_score <= 0.2:
                explanation_parts.append("The AI detected strong negative signals: declining momentum, weakening volume, and bearish technical patterns")
            elif ml_score <= 0.3:
                explanation_parts.append("The AI found concerning patterns: price weakness, reduced buying interest, and deteriorating market conditions")
            else:
                explanation_parts.append("The AI identified enough warning signs to exit: momentum is fading and technical indicators are turning negative")
        
        # Secondary factors - explain RSI in context
        if rsi is not None and rsi > self.config['rsi_overbought']:
            explanation_parts.append(f"Supporting evidence: RSI at {rsi:.0f} shows the stock is overbought (above {self.config['rsi_overbought']}), meaning it may have risen too far too fast and could pull back")
        elif rsi is not None and rsi > 70:
            explanation_parts.append(f"Supporting evidence: RSI at {rsi:.0f} indicates strong upward momentum, but we're taking profits based on our rules")
        elif rsi is not None and rsi < 40:
            explanation_parts.append(f"Supporting evidence: RSI at {rsi:.0f} confirms weakening momentum - selling pressure is building")
        elif rsi is not None:
            explanation_parts.append(f"Supporting evidence: RSI at {rsi:.0f} is neutral, but other factors triggered the sell")
        
        # Context about what DIDN'T trigger (helps understand the decision hierarchy)
        if sell_trigger != 'profit_target' and profit_pct > 0:
            explanation_parts.append(f"Note: Currently at {profit_pct:.1%} profit (target was {self.config['profit_target']:.1%}), but selling for other reasons")
        if sell_trigger != 'stop_loss' and profit_pct < 0:
            explanation_parts.append(f"Note: Currently at {profit_pct:.1%} loss (stop loss is at -{self.config['stop_loss']:.1%}), but selling based on AI signals before it gets worse")
        if sell_trigger != 'ml_signal' and ml_score < self.config['q_sell']:
            explanation_parts.append(f"Note: AI score is low at {ml_score:.2f}, but we're selling based on our profit/loss rules")
        
        # Explain the outcome and lesson
        if profit_pct > 0:
            explanation_parts.append(f"OUTCOME: Secured a {profit_pct:.1%} profit on this trade")
            if profit_pct > self.config['profit_target']:
                explanation_parts.append("This exceeded our target - sometimes patience pays off!")
            else:
                explanation_parts.append("While below our ideal target, taking any profit is better than watching it turn into a loss")
        else:
            explanation_parts.append(f"OUTCOME: Limited our loss to {profit_pct:.1%}")
            explanation_parts.append("Losses are part of trading - the key is keeping them small and manageable")
        
        # Trading wisdom
        if sell_trigger == 'profit_target':
            explanation_parts.append("LESSON: Disciplined profit-taking helps lock in gains and prevents round trips")
        elif sell_trigger == 'stop_loss':
            explanation_parts.append("LESSON: Stop losses protect capital - live to trade another day")
        else:
            explanation_parts.append("LESSON: Following AI signals helps remove emotion from trading decisions")
        
        return " | ".join(explanation_parts)

# Compatibility function for existing main.py
def create_backtester(*args, **kwargs):
    """Create backtester instance for compatibility"""
    return LAEFBacktester(*args, **kwargs)